package com.pnote.mgr.note.service;

import com.github.pagehelper.PageInfo;

import com.pnote.mgr.note.domain.NoteBook;
import com.pnote.mgr.note.domain.NoteBookSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface NoteBookService extends CrudServiceInterface<NoteBook> {

    PageInfo<NoteBook> findPage(NoteBookSch sch);
}