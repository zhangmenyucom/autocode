package com.pnote.mgr.note.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class NoteArticle implements Serializable {
	private Long articleId;
	private Long bookId;
	private Long directoryId;
	private String articleName;
	private String content;
	private byte deleteFlag;
	private Long creatorId;
	private Date createTime;
	private Date updateTime;
}