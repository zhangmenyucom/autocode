package com.pnote.mgr.note.dao;

import org.durcframework.core.dao.BaseDao;
import com.pnote.mgr.note.domain.NoteBook;

public interface NoteBookDao extends BaseDao<NoteBook> {
}