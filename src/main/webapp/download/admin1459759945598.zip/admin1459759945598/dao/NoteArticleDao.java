package com.pnote.mgr.note.dao;

import org.durcframework.core.dao.BaseDao;
import com.pnote.mgr.note.domain.NoteArticle;

public interface NoteArticleDao extends BaseDao<NoteArticle> {
}