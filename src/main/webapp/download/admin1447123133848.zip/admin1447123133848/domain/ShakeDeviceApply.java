package com.weimob.o2o.mgr.shake.domain;

public class ShakeDeviceApply {
	private long shakeDeviceApplyId;
	private int quanttity;
	private String applyReason;
	private String comment;
	private String poiId;
	private String applyId;
	private int auditStatus;
	private String auditComment;
	private String applyTime;
	private String auditTime;
	private long merchantId;
	private String createTime;
	private String updateTime;

	public void setShakeDeviceApplyId(long shakeDeviceApplyId){
		this.shakeDeviceApplyId = shakeDeviceApplyId;
	}

	public long getShakeDeviceApplyId(){
		return this.shakeDeviceApplyId;
	}

	public void setQuanttity(int quanttity){
		this.quanttity = quanttity;
	}

	public int getQuanttity(){
		return this.quanttity;
	}

	public void setApplyReason(String applyReason){
		this.applyReason = applyReason;
	}

	public String getApplyReason(){
		return this.applyReason;
	}

	public void setComment(String comment){
		this.comment = comment;
	}

	public String getComment(){
		return this.comment;
	}

	public void setPoiId(String poiId){
		this.poiId = poiId;
	}

	public String getPoiId(){
		return this.poiId;
	}

	public void setApplyId(String applyId){
		this.applyId = applyId;
	}

	public String getApplyId(){
		return this.applyId;
	}

	public void setAuditStatus(int auditStatus){
		this.auditStatus = auditStatus;
	}

	public int getAuditStatus(){
		return this.auditStatus;
	}

	public void setAuditComment(String auditComment){
		this.auditComment = auditComment;
	}

	public String getAuditComment(){
		return this.auditComment;
	}

	public void setApplyTime(String applyTime){
		this.applyTime = applyTime;
	}

	public String getApplyTime(){
		return this.applyTime;
	}

	public void setAuditTime(String auditTime){
		this.auditTime = auditTime;
	}

	public String getAuditTime(){
		return this.auditTime;
	}

	public void setMerchantId(long merchantId){
		this.merchantId = merchantId;
	}

	public long getMerchantId(){
		return this.merchantId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}