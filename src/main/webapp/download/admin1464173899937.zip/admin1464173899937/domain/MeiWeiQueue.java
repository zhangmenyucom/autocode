package com.weimob.o2o.mgr.meiwei.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MeiWeiQueue implements Serializable {
	private Long id;
	private Long merchantId;
	private Long storeId;
	private String meiWeiStoreId;
	private Long coutomId;
	private String openId;
	private String phone;
	private String meiWeiOrderId;
	private byte status;
	private String qName;
	private String qAttr;
	private String num;
	private String waitTime;
	private Date updateTime;
	private Date createTime;
}