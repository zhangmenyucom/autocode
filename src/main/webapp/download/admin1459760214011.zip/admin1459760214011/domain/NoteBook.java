package com.pnote.mgr.note.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class NoteBook implements Serializable {
	private Long bookId;
	private String name;
	private byte publicFlag;
	private byte deleteFlag;
	private Long creatorId;
	private Date createTime;
	private Date updateTime;
}