package com.pnote.mgr.note.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class NoteDirectory implements Serializable {
	private Long directoryId;
	private String name;
	private Integer level;
	private Integer order;
	private Long bookId;
	private Long parentId;
	private Integer deleteFlag;
	private Long creatorId;
	private Date createTime;
	private Date updateTime;
}