package com.pnote.mgr.note.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class NoteDirectorySch extends SearchEntity{

    private Long directoryIdSch;
    private String nameSch;
    private Integer levelSch;
    private Integer orderSch;
    private Long bookIdSch;
    private Long parentIdSch;
    private Integer deleteFlagSch;
    private Long creatorIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setDirectoryIdSch(Long directoryIdSch){
        this.directoryIdSch = directoryIdSch;
    }
    
    @ValueField(column = "directory_id")
    public Long getDirectoryIdSch(){
        return this.directoryIdSch;
    }

    public void setNameSch(String nameSch){
        this.nameSch = nameSch;
    }
    
    @ValueField(column = "name")
    public String getNameSch(){
        return this.nameSch;
    }

    public void setLevelSch(Integer levelSch){
        this.levelSch = levelSch;
    }
    
    @ValueField(column = "level")
    public Integer getLevelSch(){
        return this.levelSch;
    }

    public void setOrderSch(Integer orderSch){
        this.orderSch = orderSch;
    }
    
    @ValueField(column = "order")
    public Integer getOrderSch(){
        return this.orderSch;
    }

    public void setBookIdSch(Long bookIdSch){
        this.bookIdSch = bookIdSch;
    }
    
    @ValueField(column = "book_id")
    public Long getBookIdSch(){
        return this.bookIdSch;
    }

    public void setParentIdSch(Long parentIdSch){
        this.parentIdSch = parentIdSch;
    }
    
    @ValueField(column = "parent_id")
    public Long getParentIdSch(){
        return this.parentIdSch;
    }

    public void setDeleteFlagSch(Integer deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Integer getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setCreatorIdSch(Long creatorIdSch){
        this.creatorIdSch = creatorIdSch;
    }
    
    @ValueField(column = "creator_id")
    public Long getCreatorIdSch(){
        return this.creatorIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}