package com.pnote.mgr.note.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class NoteBookSch extends SearchEntity{

    private Long bookIdSch;
    private String nameSch;
    private Byte publicFlagSch;
    private Byte deleteFlagSch;
    private Long creatorIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setBookIdSch(Long bookIdSch){
        this.bookIdSch = bookIdSch;
    }
    
    @ValueField(column = "book_id")
    public Long getBookIdSch(){
        return this.bookIdSch;
    }

    public void setNameSch(String nameSch){
        this.nameSch = nameSch;
    }
    
    @ValueField(column = "name")
    public String getNameSch(){
        return this.nameSch;
    }

    public void setPublicFlagSch(Byte publicFlagSch){
        this.publicFlagSch = publicFlagSch;
    }
    
    @ValueField(column = "public_flag")
    public Byte getPublicFlagSch(){
        return this.publicFlagSch;
    }

    public void setDeleteFlagSch(Byte deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Byte getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setCreatorIdSch(Long creatorIdSch){
        this.creatorIdSch = creatorIdSch;
    }
    
    @ValueField(column = "creator_id")
    public Long getCreatorIdSch(){
        return this.creatorIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}