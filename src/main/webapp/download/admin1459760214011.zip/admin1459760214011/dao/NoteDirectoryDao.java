package com.pnote.mgr.note.dao;

import org.durcframework.core.dao.BaseDao;
import com.pnote.mgr.note.domain.NoteDirectory;

public interface NoteDirectoryDao extends BaseDao<NoteDirectory> {
}