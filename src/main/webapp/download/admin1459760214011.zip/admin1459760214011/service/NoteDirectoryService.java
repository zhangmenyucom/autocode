package com.pnote.mgr.note.service;

import com.github.pagehelper.PageInfo;

import com.pnote.mgr.note.domain.NoteDirectory;
import com.pnote.mgr.note.domain.sch.NoteDirectorySch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface NoteDirectoryService extends CrudServiceInterface<NoteDirectory> {

    PageInfo<NoteDirectory> findPage(NoteDirectorySch sch);
}