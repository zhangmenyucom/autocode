package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStatistics implements Serializable {
	private Long wifiStatistics;
	private Long aid;
	private Long merchantId;
	private Long storeId;
	private Date statisDate;
	private Long wechatStatisTime;
	private Integer wechatTotalUser;
	private Integer wechatHomePageUv;
	private Integer wechatNewFans;
	private Integer wechatTotalFans;
	private Integer wechatWxConnectUser;
	private Integer wechatConnectMsgUser;
	private Date createTime;
	private Date updateTime;
	private Long createAccountId;
	private Long updateAccountId;
}