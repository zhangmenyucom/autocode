package com.ayuan.blog.service;

import com.ayuan.blog.domain.Tag;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface TagService extends CrudServiceInterface<Tag> {

}