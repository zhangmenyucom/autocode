package com.ayuan.blog.service;

import com.ayuan.blog.domain.ArticleTag;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ArticleTagService extends CrudServiceInterface<ArticleTag> {

}