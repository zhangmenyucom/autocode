package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.TagService;
import com.ayuan.blog.dao.TagDao;
import com.ayuan.blog.domain.Tag;
import org.springframework.stereotype.Service;
    
@Service
public class TagServiceImpl 
        extends CrudService<Tag, TagDao> 
        implements TagService {

}