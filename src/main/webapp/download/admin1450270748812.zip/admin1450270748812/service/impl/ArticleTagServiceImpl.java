package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.ArticleTagService;
import com.ayuan.blog.dao.ArticleTagDao;
import com.ayuan.blog.domain.ArticleTag;
import org.springframework.stereotype.Service;
    
@Service
public class ArticleTagServiceImpl 
        extends CrudService<ArticleTag, ArticleTagDao> 
        implements ArticleTagService {

}