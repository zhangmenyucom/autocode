package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ArticleTagSch extends SearchEntity{

    private Integer idSch;
    private Integer tagIdSch;
    private Integer articleIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setIdSch(Integer idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Integer getIdSch(){
        return this.idSch;
    }

    public void setTagIdSch(Integer tagIdSch){
        this.tagIdSch = tagIdSch;
    }
    
    @ValueField(column = "tag_id")
    public Integer getTagIdSch(){
        return this.tagIdSch;
    }

    public void setArticleIdSch(Integer articleIdSch){
        this.articleIdSch = articleIdSch;
    }
    
    @ValueField(column = "article_id")
    public Integer getArticleIdSch(){
        return this.articleIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}