package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.ArticleTag;

public interface ArticleTagDao extends BaseDao<ArticleTag> {
}