package com.ayuan.blog.service;

import com.github.pagehelper.PageInfo;

import com.ayuan.blog.domain.Focus;
import com.ayuan.blog.domain.sch.FocusSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface FocusService extends CrudServiceInterface<Focus> {

    PageInfo<Focus> findPage(FocusSch sch);
}