package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class FocusSch extends SearchEntity{

    private Long idSch;
    private Long userIdSch;
    private Long focusedUserIdSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setUserIdSch(Long userIdSch){
        this.userIdSch = userIdSch;
    }
    
    @ValueField(column = "user_id")
    public Long getUserIdSch(){
        return this.userIdSch;
    }

    public void setFocusedUserIdSch(Long focusedUserIdSch){
        this.focusedUserIdSch = focusedUserIdSch;
    }
    
    @ValueField(column = "focused_user_id")
    public Long getFocusedUserIdSch(){
        return this.focusedUserIdSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}