package com.ayuan.blog.service;

import com.github.pagehelper.PageInfo;

import com.ayuan.blog.domain.WxSignInLog;
import com.ayuan.blog.domain.sch.WxSignInLogSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WxSignInLogService extends CrudServiceInterface<WxSignInLog> {

    PageInfo<WxSignInLog> findPage(WxSignInLogSch sch);
}