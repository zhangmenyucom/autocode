package com.ayuan.blog.service;

import com.github.pagehelper.PageInfo;

import com.ayuan.blog.domain.WxUser;
import com.ayuan.blog.domain.sch.WxUserSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WxUserService extends CrudServiceInterface<WxUser> {

    PageInfo<WxUser> findPage(WxUserSch sch);
}