package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WxSignInLog implements Serializable {
	private Long signInLogId;
	private Long wxUserId;
	private String comment;
	private Date signInDate;
	private Date signInTime;
	private Date updateTime;
	private Date createTime;
}