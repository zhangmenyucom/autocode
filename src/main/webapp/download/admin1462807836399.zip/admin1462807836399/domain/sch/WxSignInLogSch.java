package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WxSignInLogSch extends SearchEntity{

    private Long signInLogIdSch;
    private Long wxUserIdSch;
    private String commentSch;
    private Date signInDateSch;
    private Date signInTimeSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setSignInLogIdSch(Long signInLogIdSch){
        this.signInLogIdSch = signInLogIdSch;
    }
    
    @ValueField(column = "sign_in_log_id")
    public Long getSignInLogIdSch(){
        return this.signInLogIdSch;
    }

    public void setWxUserIdSch(Long wxUserIdSch){
        this.wxUserIdSch = wxUserIdSch;
    }
    
    @ValueField(column = "wx_user_id")
    public Long getWxUserIdSch(){
        return this.wxUserIdSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setSignInDateSch(Date signInDateSch){
        this.signInDateSch = signInDateSch;
    }
    
    @ValueField(column = "sign_in_date")
    public Date getSignInDateSch(){
        return this.signInDateSch;
    }

    public void setSignInTimeSch(Date signInTimeSch){
        this.signInTimeSch = signInTimeSch;
    }
    
    @ValueField(column = "sign_in_time")
    public Date getSignInTimeSch(){
        return this.signInTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}