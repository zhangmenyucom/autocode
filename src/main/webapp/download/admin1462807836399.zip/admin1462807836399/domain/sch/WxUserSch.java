package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WxUserSch extends SearchEntity{

    private Long wxUserIdSch;
    private String openIdSch;
    private String nicknameSch;
    private Date updateTimeSch;

    public void setWxUserIdSch(Long wxUserIdSch){
        this.wxUserIdSch = wxUserIdSch;
    }
    
    @ValueField(column = "wx_user_id")
    public Long getWxUserIdSch(){
        return this.wxUserIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setNicknameSch(String nicknameSch){
        this.nicknameSch = nicknameSch;
    }
    
    @ValueField(column = "nickname")
    public String getNicknameSch(){
        return this.nicknameSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}