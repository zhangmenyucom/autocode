package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WxUser implements Serializable {
	private Long wxUserId;
	private String openId;
	private String nickname;
	private Date updateTime;
}