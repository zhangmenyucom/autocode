package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.WxSignInLog;

public interface WxSignInLogDao extends BaseDao<WxSignInLog> {
}