package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.WxUser;

public interface WxUserDao extends BaseDao<WxUser> {
}