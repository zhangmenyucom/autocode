package com.weimob.o2o.mgr.wifi.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreProduceDevice;

public interface WifiStoreProduceDeviceDao extends BaseDao<WifiStoreProduceDevice> {
}