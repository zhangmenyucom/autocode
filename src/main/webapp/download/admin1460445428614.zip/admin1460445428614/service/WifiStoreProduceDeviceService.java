package com.weimob.o2o.mgr.wifi.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.wifi.domain.WifiStoreProduceDevice;
import com.weimob.o2o.mgr.wifi.domain.sch.WifiStoreProduceDeviceSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiStoreProduceDeviceService extends CrudServiceInterface<WifiStoreProduceDevice> {

    PageInfo<WifiStoreProduceDevice> findPage(WifiStoreProduceDeviceSch sch);
}