package com.weimob.o2o.activity.mgr.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.weimob.o2o.activity.mgr.service.PayRightsConfigService;
import com.weimob.o2o.activity.mgr.dao.PayRightsConfigDao;
import com.weimob.o2o.activity.mgr.domain.PayRightsConfig;
import com.weimob.o2o.activity.mgr.domain.sch.PayRightsConfigSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class PayRightsConfigServiceImpl 
        extends CrudService<PayRightsConfig, PayRightsConfigDao> 
        implements PayRightsConfigService {

    @Override
    public PageInfo<PayRightsConfig> findPage(PayRightsConfigSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<PayRightsConfig> list = this.getDao().find(query);

        PageInfo<PayRightsConfig> page = new PageInfo<>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}