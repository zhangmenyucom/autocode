package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketModelPaySenceConfig;
import com.weimob.o2o.activity.mgr.domain.sch.MarketModelPaySenceConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketModelPaySenceConfigService extends CrudServiceInterface<MarketModelPaySenceConfig> {

    PageInfo<MarketModelPaySenceConfig> findPage(MarketModelPaySenceConfigSch sch);
}