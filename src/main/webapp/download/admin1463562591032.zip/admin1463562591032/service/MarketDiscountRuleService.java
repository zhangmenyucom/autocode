package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketDiscountRule;
import com.weimob.o2o.activity.mgr.domain.sch.MarketDiscountRuleSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketDiscountRuleService extends CrudServiceInterface<MarketDiscountRule> {

    PageInfo<MarketDiscountRule> findPage(MarketDiscountRuleSch sch);
}