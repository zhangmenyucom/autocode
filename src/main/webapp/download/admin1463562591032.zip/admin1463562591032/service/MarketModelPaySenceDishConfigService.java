package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketModelPaySenceDishConfig;
import com.weimob.o2o.activity.mgr.domain.sch.MarketModelPaySenceDishConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketModelPaySenceDishConfigService extends CrudServiceInterface<MarketModelPaySenceDishConfig> {

    PageInfo<MarketModelPaySenceDishConfig> findPage(MarketModelPaySenceDishConfigSch sch);
}