package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.PayRightsConfig;
import com.weimob.o2o.activity.mgr.domain.sch.PayRightsConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface PayRightsConfigService extends CrudServiceInterface<PayRightsConfig> {

    PageInfo<PayRightsConfig> findPage(PayRightsConfigSch sch);
}