package com.weimob.o2o.activity.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MarketModelPaySenceDishConfig implements Serializable {
	private Long id;
	private Long merchantId;
	private Long storeId;
	private byte paySence;
	private Long marketModelPaySenceConfigId;
	private Long dishId;
	private Date updateTime;
	private Date createTime;
}