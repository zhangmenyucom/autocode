package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MarketDiscountRuleSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long activityIdSch;
    private Byte statusSch;
    private Byte typeSch;
    private Long maxAmountSch;
    private Long overAmountSch;
    private Long freeAmountSch;
    private Date startTimeEachDaySch;
    private Date endTimeEachDaySch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setActivityIdSch(Long activityIdSch){
        this.activityIdSch = activityIdSch;
    }
    
    @ValueField(column = "activity_id")
    public Long getActivityIdSch(){
        return this.activityIdSch;
    }

    public void setStatusSch(Byte statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Byte getStatusSch(){
        return this.statusSch;
    }

    public void setTypeSch(Byte typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Byte getTypeSch(){
        return this.typeSch;
    }

    public void setMaxAmountSch(Long maxAmountSch){
        this.maxAmountSch = maxAmountSch;
    }
    
    @ValueField(column = "max_amount")
    public Long getMaxAmountSch(){
        return this.maxAmountSch;
    }

    public void setOverAmountSch(Long overAmountSch){
        this.overAmountSch = overAmountSch;
    }
    
    @ValueField(column = "over_amount")
    public Long getOverAmountSch(){
        return this.overAmountSch;
    }

    public void setFreeAmountSch(Long freeAmountSch){
        this.freeAmountSch = freeAmountSch;
    }
    
    @ValueField(column = "free_amount")
    public Long getFreeAmountSch(){
        return this.freeAmountSch;
    }

    public void setStartTimeEachDaySch(Date startTimeEachDaySch){
        this.startTimeEachDaySch = startTimeEachDaySch;
    }
    
    @ValueField(column = "start_time_each_day")
    public Date getStartTimeEachDaySch(){
        return this.startTimeEachDaySch;
    }

    public void setEndTimeEachDaySch(Date endTimeEachDaySch){
        this.endTimeEachDaySch = endTimeEachDaySch;
    }
    
    @ValueField(column = "end_time_each_day")
    public Date getEndTimeEachDaySch(){
        return this.endTimeEachDaySch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}