package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MarketModelPaySenceDishConfigSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Byte paySenceSch;
    private Long marketModelPaySenceConfigIdSch;
    private Long dishIdSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setPaySenceSch(Byte paySenceSch){
        this.paySenceSch = paySenceSch;
    }
    
    @ValueField(column = "pay_sence")
    public Byte getPaySenceSch(){
        return this.paySenceSch;
    }

    public void setMarketModelPaySenceConfigIdSch(Long marketModelPaySenceConfigIdSch){
        this.marketModelPaySenceConfigIdSch = marketModelPaySenceConfigIdSch;
    }
    
    @ValueField(column = "market_model_pay_sence_config_id")
    public Long getMarketModelPaySenceConfigIdSch(){
        return this.marketModelPaySenceConfigIdSch;
    }

    public void setDishIdSch(Long dishIdSch){
        this.dishIdSch = dishIdSch;
    }
    
    @ValueField(column = "dish_id")
    public Long getDishIdSch(){
        return this.dishIdSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}