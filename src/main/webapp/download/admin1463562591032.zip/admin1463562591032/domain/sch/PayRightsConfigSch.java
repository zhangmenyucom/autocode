package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class PayRightsConfigSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long activityIdSch;
    private Byte cardOpenedSch;
    private Byte memberLevelOpenedSch;
    private Byte memberPointOpenedSch;
    private Byte memberBalanceOpenedSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setActivityIdSch(Long activityIdSch){
        this.activityIdSch = activityIdSch;
    }
    
    @ValueField(column = "activity_id")
    public Long getActivityIdSch(){
        return this.activityIdSch;
    }

    public void setCardOpenedSch(Byte cardOpenedSch){
        this.cardOpenedSch = cardOpenedSch;
    }
    
    @ValueField(column = "card_opened")
    public Byte getCardOpenedSch(){
        return this.cardOpenedSch;
    }

    public void setMemberLevelOpenedSch(Byte memberLevelOpenedSch){
        this.memberLevelOpenedSch = memberLevelOpenedSch;
    }
    
    @ValueField(column = "member_level_opened")
    public Byte getMemberLevelOpenedSch(){
        return this.memberLevelOpenedSch;
    }

    public void setMemberPointOpenedSch(Byte memberPointOpenedSch){
        this.memberPointOpenedSch = memberPointOpenedSch;
    }
    
    @ValueField(column = "member_point_opened")
    public Byte getMemberPointOpenedSch(){
        return this.memberPointOpenedSch;
    }

    public void setMemberBalanceOpenedSch(Byte memberBalanceOpenedSch){
        this.memberBalanceOpenedSch = memberBalanceOpenedSch;
    }
    
    @ValueField(column = "member_balance_opened")
    public Byte getMemberBalanceOpenedSch(){
        return this.memberBalanceOpenedSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}