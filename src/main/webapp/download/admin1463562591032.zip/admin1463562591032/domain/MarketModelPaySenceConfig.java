package com.weimob.o2o.activity.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MarketModelPaySenceConfig implements Serializable {
	private Long id;
	private Long merchantId;
	private Long activityId;
	private Long storeId;
	private byte paySence;
	private byte dishRangeType;
	private Date updateTime;
	private Date createTime;
}