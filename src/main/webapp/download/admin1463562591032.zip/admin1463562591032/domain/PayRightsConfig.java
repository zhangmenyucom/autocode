package com.weimob.o2o.activity.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class PayRightsConfig implements Serializable {
	private Long id;
	private Long merchantId;
	private Long activityId;
	private byte cardOpened;
	private byte memberLevelOpened;
	private byte memberPointOpened;
	private byte memberBalanceOpened;
	private Date updateTime;
	private Date createTime;
}