package com.weimob.o2o.activity.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.activity.mgr.domain.MarketDiscountRule;

public interface MarketDiscountRuleDao extends BaseDao<MarketDiscountRule> {
}