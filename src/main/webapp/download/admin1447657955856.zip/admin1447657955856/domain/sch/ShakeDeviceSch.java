package com.weimob.o2o.mgr.shake.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDeviceSch extends SearchEntity{

    private Long shakeDeviceIdSch;
    private Long deviceIdSch;
    private String uuidSch;
    private String majorSch;
    private String minorSch;
    private String commentSch;
    private Integer statusSch;
    private Long shakeDeviceApplyIdSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setShakeDeviceIdSch(Long shakeDeviceIdSch){
        this.shakeDeviceIdSch = shakeDeviceIdSch;
    }
    
    @ValueField(column = "shake_device_id")
    public Long getShakeDeviceIdSch(){
        return this.shakeDeviceIdSch;
    }

    public void setDeviceIdSch(Long deviceIdSch){
        this.deviceIdSch = deviceIdSch;
    }
    
    @ValueField(column = "device_id")
    public Long getDeviceIdSch(){
        return this.deviceIdSch;
    }

    public void setUuidSch(String uuidSch){
        this.uuidSch = uuidSch;
    }
    
    @ValueField(column = "uuid")
    public String getUuidSch(){
        return this.uuidSch;
    }

    public void setMajorSch(String majorSch){
        this.majorSch = majorSch;
    }
    
    @ValueField(column = "major")
    public String getMajorSch(){
        return this.majorSch;
    }

    public void setMinorSch(String minorSch){
        this.minorSch = minorSch;
    }
    
    @ValueField(column = "minor")
    public String getMinorSch(){
        return this.minorSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setShakeDeviceApplyIdSch(Long shakeDeviceApplyIdSch){
        this.shakeDeviceApplyIdSch = shakeDeviceApplyIdSch;
    }
    
    @ValueField(column = "shake_device_apply_id")
    public Long getShakeDeviceApplyIdSch(){
        return this.shakeDeviceApplyIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}