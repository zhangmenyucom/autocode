package com.weimob.o2o.mgr.material.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MaterialSch extends SearchEntity{

    private Long materialIdSch;
    private String mediaIdSch;
    private String linkIdSch;
    private Integer linkTypeSch;
    private String linkNameSch;
    private Integer linkClassificationSch;

    public void setMaterialIdSch(Long materialIdSch){
        this.materialIdSch = materialIdSch;
    }
    
    @ValueField(column = "material_id")
    public Long getMaterialIdSch(){
        return this.materialIdSch;
    }

    public void setMediaIdSch(String mediaIdSch){
        this.mediaIdSch = mediaIdSch;
    }
    
    @ValueField(column = "media_id")
    public String getMediaIdSch(){
        return this.mediaIdSch;
    }

    public void setLinkIdSch(String linkIdSch){
        this.linkIdSch = linkIdSch;
    }
    
    @ValueField(column = "link_id")
    public String getLinkIdSch(){
        return this.linkIdSch;
    }

    public void setLinkTypeSch(Integer linkTypeSch){
        this.linkTypeSch = linkTypeSch;
    }
    
    @ValueField(column = "link_type")
    public Integer getLinkTypeSch(){
        return this.linkTypeSch;
    }

    public void setLinkNameSch(String linkNameSch){
        this.linkNameSch = linkNameSch;
    }
    
    @ValueField(column = "link_name")
    public String getLinkNameSch(){
        return this.linkNameSch;
    }

    public void setLinkClassificationSch(Integer linkClassificationSch){
        this.linkClassificationSch = linkClassificationSch;
    }
    
    @ValueField(column = "link_classification")
    public Integer getLinkClassificationSch(){
        return this.linkClassificationSch;
    }


}