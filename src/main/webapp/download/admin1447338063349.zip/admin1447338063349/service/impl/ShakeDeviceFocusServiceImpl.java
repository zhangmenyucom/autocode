package com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.shake.service.ShakeDeviceFocusService;
import com.weimob.o2o.mgr.shake.dao.ShakeDeviceFocusDao;
import com.weimob.o2o.mgr.shake.domain.ShakeDeviceFocus;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceFocusServiceImpl 
        extends CrudService<ShakeDeviceFocus, ShakeDeviceFocusDao> 
        implements ShakeDeviceFocusService {

}