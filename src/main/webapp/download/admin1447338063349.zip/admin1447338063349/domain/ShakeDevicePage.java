package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeDevicePage implements Serializable {
	private Long shakeDevicePageId;
	private Long shakeDeviceId;
	private Long shakePageId;
	private Date createTime;
	private Date updateTime;
}