package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeDeviceFocus implements Serializable {
	private Long shakeDeviceFocusId;
	private Long shakeDeviceId;
	private Long shakeFocusId;
}