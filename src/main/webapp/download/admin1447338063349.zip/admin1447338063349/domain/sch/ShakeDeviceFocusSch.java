package com.weimob.o2o.mgr.shake.domain.sch;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDeviceFocusSch extends SearchEntity{

    private Long shakeDeviceFocusIdSch;
    private Long shakeDeviceIdSch;
    private Long shakeFocusIdSch;

    public void setShakeDeviceFocusIdSch(Long shakeDeviceFocusIdSch){
        this.shakeDeviceFocusIdSch = shakeDeviceFocusIdSch;
    }
    
    @ValueField(column = "shake_device_focus_id")
    public Long getShakeDeviceFocusIdSch(){
        return this.shakeDeviceFocusIdSch;
    }

    public void setShakeDeviceIdSch(Long shakeDeviceIdSch){
        this.shakeDeviceIdSch = shakeDeviceIdSch;
    }
    
    @ValueField(column = "shake_device_id")
    public Long getShakeDeviceIdSch(){
        return this.shakeDeviceIdSch;
    }

    public void setShakeFocusIdSch(Long shakeFocusIdSch){
        this.shakeFocusIdSch = shakeFocusIdSch;
    }
    
    @ValueField(column = "shake_focus_id")
    public Long getShakeFocusIdSch(){
        return this.shakeFocusIdSch;
    }


}