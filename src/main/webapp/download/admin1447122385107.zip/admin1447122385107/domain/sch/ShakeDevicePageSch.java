package shakedevicepage.domain.sch;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDevicePageSch extends SearchEntity{

    private Long shakeDevicePageIdSch;
    private Long shakeDeviceIdSch;
    private Long shakePageIdSch;
    private String createTimeSch;
    private String updateTimeSch;

    public void setShakeDevicePageIdSch(Long shakeDevicePageIdSch){
        this.shakeDevicePageIdSch = shakeDevicePageIdSch;
    }
    
    @ValueField(column = "shake_device_page_id")
    public Long getShakeDevicePageIdSch(){
        return this.shakeDevicePageIdSch;
    }

    public void setShakeDeviceIdSch(Long shakeDeviceIdSch){
        this.shakeDeviceIdSch = shakeDeviceIdSch;
    }
    
    @ValueField(column = "shake_device_id")
    public Long getShakeDeviceIdSch(){
        return this.shakeDeviceIdSch;
    }

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setCreateTimeSch(String createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public String getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(String updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public String getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}