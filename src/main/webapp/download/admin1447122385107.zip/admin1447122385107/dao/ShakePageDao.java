package shakepage.dao;

import org.durcframework.core.dao.BaseDao;
import shakepage.domain.ShakePage;

public interface ShakePageDao extends BaseDao<ShakePage> {
}