package shakedevice.dao;

import org.durcframework.core.dao.BaseDao;
import shakedevice.domain.ShakeDevice;

public interface ShakeDeviceDao extends BaseDao<ShakeDevice> {
}