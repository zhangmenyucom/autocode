package shakefocus.dao;

import org.durcframework.core.dao.BaseDao;
import shakefocus.domain.ShakeFocus;

public interface ShakeFocusDao extends BaseDao<ShakeFocus> {
}