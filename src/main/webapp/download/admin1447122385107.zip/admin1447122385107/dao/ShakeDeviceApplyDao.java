package shakedeviceapply.dao;

import org.durcframework.core.dao.BaseDao;
import shakedeviceapply.domain.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends BaseDao<ShakeDeviceApply> {
}