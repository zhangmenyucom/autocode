package shakedevice.service;

public interface ShakeDeviceService extends CrudServiceInterface {

}