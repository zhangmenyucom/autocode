package shakefocus.service.impl;

import org.durcframework.core.service.CrudService;
import shakefocus.service.ShakeFocusService;
import shakefocus.dao.ShakeFocusDao;
import shakefocus.domain.ShakeFocus;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeFocusServiceImpl extends CrudService<ShakeFocus, ShakeFocusDao> implements ShakeFocusService {

}