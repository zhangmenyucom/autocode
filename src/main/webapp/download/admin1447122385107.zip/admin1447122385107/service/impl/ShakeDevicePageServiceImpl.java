package shakedevicepage.service.impl;

import org.durcframework.core.service.CrudService;
import shakedevicepage.service.ShakeDevicePageService;
import shakedevicepage.dao.ShakeDevicePageDao;
import shakedevicepage.domain.ShakeDevicePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDevicePageServiceImpl extends CrudService<ShakeDevicePage, ShakeDevicePageDao> implements ShakeDevicePageService {

}