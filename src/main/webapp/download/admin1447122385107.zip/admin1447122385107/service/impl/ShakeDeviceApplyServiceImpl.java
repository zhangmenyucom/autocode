package shakedeviceapply.service.impl;

import org.durcframework.core.service.CrudService;
import shakedeviceapply.service.ShakeDeviceApplyService;
import shakedeviceapply.dao.ShakeDeviceApplyDao;
import shakedeviceapply.domain.ShakeDeviceApply;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceApplyServiceImpl extends CrudService<ShakeDeviceApply, ShakeDeviceApplyDao> implements ShakeDeviceApplyService {

}