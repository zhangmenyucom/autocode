package shakefocus.service;

public interface ShakeFocusService extends CrudServiceInterface {

}