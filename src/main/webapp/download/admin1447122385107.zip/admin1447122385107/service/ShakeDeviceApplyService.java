package shakedeviceapply.service;

public interface ShakeDeviceApplyService extends CrudServiceInterface {

}