package shakepage.service;

public interface ShakePageService extends CrudServiceInterface {

}