package shakedevicepage.service;

public interface ShakeDevicePageService extends CrudServiceInterface {

}