package com.weimob.o2o.mgr.shake.domain;

public class ShakeDevicePage {
	private Long shakeDevicePageId;
	private Long shakeDeviceId;
	private Long shakePageId;
	private String createTime;
	private String updateTime;

	public void setShakeDevicePageId(Long shakeDevicePageId){
		this.shakeDevicePageId = shakeDevicePageId;
	}

	public Long getShakeDevicePageId(){
		return this.shakeDevicePageId;
	}

	public void setShakeDeviceId(Long shakeDeviceId){
		this.shakeDeviceId = shakeDeviceId;
	}

	public Long getShakeDeviceId(){
		return this.shakeDeviceId;
	}

	public void setShakePageId(Long shakePageId){
		this.shakePageId = shakePageId;
	}

	public Long getShakePageId(){
		return this.shakePageId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}