package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakePage implements Serializable {
	private Long shakePageId;
	private Long merchantId;
	private String pageId;
	private String title;
	private String description;
	private String iconUrl;
	private String pageUrl;
	private Integer pageUrlType;
	private String comment;
	private Long activtyId;
	private Integer type;
	private Date createTime;
	private Date updateTime;
}