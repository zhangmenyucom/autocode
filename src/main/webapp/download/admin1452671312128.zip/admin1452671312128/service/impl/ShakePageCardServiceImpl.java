package com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.shake.service.ShakePageCardService;
import com.weimob.o2o.mgr.shake.dao.ShakePageCardDao;
import com.weimob.o2o.mgr.shake.domain.ShakePageCard;
import org.springframework.stereotype.Service;
    
@Service
public class ShakePageCardServiceImpl 
        extends CrudService<ShakePageCard, ShakePageCardDao> 
        implements ShakePageCardService {

}