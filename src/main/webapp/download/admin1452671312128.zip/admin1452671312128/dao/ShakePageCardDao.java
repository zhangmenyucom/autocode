package com.weimob.o2o.mgr.shake.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.shake.domain.ShakePageCard;

public interface ShakePageCardDao extends BaseDao<ShakePageCard> {
}