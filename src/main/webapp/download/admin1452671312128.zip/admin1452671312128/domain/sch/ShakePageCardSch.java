package com.weimob.o2o.mgr.shake.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakePageCardSch extends SearchEntity{

    private Long shakePageCardIdSch;
    private Long shakePageIdSch;
    private Long cardTemplateIdSch;
    private Long merchantIdSch;
    private Long bidSch;
    private Long cardTypeSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setShakePageCardIdSch(Long shakePageCardIdSch){
        this.shakePageCardIdSch = shakePageCardIdSch;
    }
    
    @ValueField(column = "shake_page_card_id")
    public Long getShakePageCardIdSch(){
        return this.shakePageCardIdSch;
    }

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setCardTemplateIdSch(Long cardTemplateIdSch){
        this.cardTemplateIdSch = cardTemplateIdSch;
    }
    
    @ValueField(column = "card_template_id")
    public Long getCardTemplateIdSch(){
        return this.cardTemplateIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setBidSch(Long bidSch){
        this.bidSch = bidSch;
    }
    
    @ValueField(column = "bid")
    public Long getBidSch(){
        return this.bidSch;
    }

    public void setCardTypeSch(Long cardTypeSch){
        this.cardTypeSch = cardTypeSch;
    }
    
    @ValueField(column = "card_type")
    public Long getCardTypeSch(){
        return this.cardTypeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}