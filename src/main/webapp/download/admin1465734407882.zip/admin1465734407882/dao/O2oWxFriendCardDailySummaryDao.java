package com.weimob.o2oreport.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2oreport.mgr.domain.O2oWxFriendCardDailySummary;

public interface O2oWxFriendCardDailySummaryDao extends BaseDao<O2oWxFriendCardDailySummary> {
}