package com.weimob.o2oreport.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oWxFriendCardDailySummarySch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private String refDateSch;
    private Long viewCntSch;
    private Long viewUserSch;
    private Long receiveCntSch;
    private Long receiveUserSch;
    private Long verifyCntSch;
    private Long verifyUserSch;
    private Long givenCntSch;
    private Long givenUserSch;
    private Long expireCntSch;
    private Long expireUserSch;
    private Date updateTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setRefDateSch(String refDateSch){
        this.refDateSch = refDateSch;
    }
    
    @ValueField(column = "ref_date")
    public String getRefDateSch(){
        return this.refDateSch;
    }

    public void setViewCntSch(Long viewCntSch){
        this.viewCntSch = viewCntSch;
    }
    
    @ValueField(column = "view_cnt")
    public Long getViewCntSch(){
        return this.viewCntSch;
    }

    public void setViewUserSch(Long viewUserSch){
        this.viewUserSch = viewUserSch;
    }
    
    @ValueField(column = "view_user")
    public Long getViewUserSch(){
        return this.viewUserSch;
    }

    public void setReceiveCntSch(Long receiveCntSch){
        this.receiveCntSch = receiveCntSch;
    }
    
    @ValueField(column = "receive_cnt")
    public Long getReceiveCntSch(){
        return this.receiveCntSch;
    }

    public void setReceiveUserSch(Long receiveUserSch){
        this.receiveUserSch = receiveUserSch;
    }
    
    @ValueField(column = "receive_user")
    public Long getReceiveUserSch(){
        return this.receiveUserSch;
    }

    public void setVerifyCntSch(Long verifyCntSch){
        this.verifyCntSch = verifyCntSch;
    }
    
    @ValueField(column = "verify_cnt")
    public Long getVerifyCntSch(){
        return this.verifyCntSch;
    }

    public void setVerifyUserSch(Long verifyUserSch){
        this.verifyUserSch = verifyUserSch;
    }
    
    @ValueField(column = "verify_user")
    public Long getVerifyUserSch(){
        return this.verifyUserSch;
    }

    public void setGivenCntSch(Long givenCntSch){
        this.givenCntSch = givenCntSch;
    }
    
    @ValueField(column = "given_cnt")
    public Long getGivenCntSch(){
        return this.givenCntSch;
    }

    public void setGivenUserSch(Long givenUserSch){
        this.givenUserSch = givenUserSch;
    }
    
    @ValueField(column = "given_user")
    public Long getGivenUserSch(){
        return this.givenUserSch;
    }

    public void setExpireCntSch(Long expireCntSch){
        this.expireCntSch = expireCntSch;
    }
    
    @ValueField(column = "expire_cnt")
    public Long getExpireCntSch(){
        return this.expireCntSch;
    }

    public void setExpireUserSch(Long expireUserSch){
        this.expireUserSch = expireUserSch;
    }
    
    @ValueField(column = "expire_user")
    public Long getExpireUserSch(){
        return this.expireUserSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}