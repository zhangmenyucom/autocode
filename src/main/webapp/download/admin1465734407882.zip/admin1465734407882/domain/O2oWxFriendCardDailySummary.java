package com.weimob.o2oreport.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oWxFriendCardDailySummary implements Serializable {
	private Long id;
	private Long merchantId;
	private String refDate;
	private Long viewCnt;
	private Long viewUser;
	private Long receiveCnt;
	private Long receiveUser;
	private Long verifyCnt;
	private Long verifyUser;
	private Long givenCnt;
	private Long givenUser;
	private Long expireCnt;
	private Long expireUser;
	private Date updateTime;
}