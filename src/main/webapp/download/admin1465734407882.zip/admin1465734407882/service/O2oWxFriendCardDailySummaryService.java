package com.weimob.o2oreport.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2oreport.mgr.domain.O2oWxFriendCardDailySummary;
import com.weimob.o2oreport.mgr.domain.sch.O2oWxFriendCardDailySummarySch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oWxFriendCardDailySummaryService extends CrudServiceInterface<O2oWxFriendCardDailySummary> {

    PageInfo<O2oWxFriendCardDailySummary> findPage(O2oWxFriendCardDailySummarySch sch);
}