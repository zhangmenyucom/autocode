package com.weimob.o2oreport.mgr.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.weimob.o2oreport.mgr.service.O2oWxFriendCardDailySummaryService;
import com.weimob.o2oreport.mgr.dao.O2oWxFriendCardDailySummaryDao;
import com.weimob.o2oreport.mgr.domain.O2oWxFriendCardDailySummary;
import com.weimob.o2oreport.mgr.domain.sch.O2oWxFriendCardDailySummarySch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class O2oWxFriendCardDailySummaryServiceImpl 
        extends CrudService<O2oWxFriendCardDailySummary, O2oWxFriendCardDailySummaryDao> 
        implements O2oWxFriendCardDailySummaryService {

    @Override
    public PageInfo<O2oWxFriendCardDailySummary> findPage(O2oWxFriendCardDailySummarySch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<O2oWxFriendCardDailySummary> list = this.getDao().find(query);

        PageInfo<O2oWxFriendCardDailySummary> page = new PageInfo<O2oWxFriendCardDailySummary>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}