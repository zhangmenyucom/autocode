package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStoreDeviceSch extends SearchEntity{

    private Long wifiStoreDeviceIdSch;
    private Long aidSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private String macAddressSch;
    private Integer macTypeSch;
    private Integer macStatusSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long createAccountIdSch;
    private Long udpateAccountIdSch;

    public void setWifiStoreDeviceIdSch(Long wifiStoreDeviceIdSch){
        this.wifiStoreDeviceIdSch = wifiStoreDeviceIdSch;
    }
    
    @ValueField(column = "wifi_store_device_id")
    public Long getWifiStoreDeviceIdSch(){
        return this.wifiStoreDeviceIdSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setMacAddressSch(String macAddressSch){
        this.macAddressSch = macAddressSch;
    }
    
    @ValueField(column = "mac_address")
    public String getMacAddressSch(){
        return this.macAddressSch;
    }

    public void setMacTypeSch(Integer macTypeSch){
        this.macTypeSch = macTypeSch;
    }
    
    @ValueField(column = "mac_type")
    public Integer getMacTypeSch(){
        return this.macTypeSch;
    }

    public void setMacStatusSch(Integer macStatusSch){
        this.macStatusSch = macStatusSch;
    }
    
    @ValueField(column = "mac_status")
    public Integer getMacStatusSch(){
        return this.macStatusSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateAccountIdSch(Long createAccountIdSch){
        this.createAccountIdSch = createAccountIdSch;
    }
    
    @ValueField(column = "create_account_id")
    public Long getCreateAccountIdSch(){
        return this.createAccountIdSch;
    }

    public void setUdpateAccountIdSch(Long udpateAccountIdSch){
        this.udpateAccountIdSch = udpateAccountIdSch;
    }
    
    @ValueField(column = "udpate_account_id")
    public Long getUdpateAccountIdSch(){
        return this.udpateAccountIdSch;
    }


}