package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStatisticsSch extends SearchEntity{

    private Long wifiStatisticsSch;
    private Long aidSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Date statisDateSch;
    private Long wechatStatisTimeSch;
    private Integer wechatTotalUserSch;
    private Integer wechatHomePageUvSch;
    private Integer wechatNewFansSch;
    private Integer wechatTotalFansSch;
    private Integer wechatWxConnectUserSch;
    private Integer wechatConnectMsgUserSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long createAccountIdSch;
    private Long updateAccountIdSch;

    public void setWifiStatisticsSch(Long wifiStatisticsSch){
        this.wifiStatisticsSch = wifiStatisticsSch;
    }
    
    @ValueField(column = "wifi_statistics")
    public Long getWifiStatisticsSch(){
        return this.wifiStatisticsSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setStatisDateSch(Date statisDateSch){
        this.statisDateSch = statisDateSch;
    }
    
    @ValueField(column = "statis_date")
    public Date getStatisDateSch(){
        return this.statisDateSch;
    }

    public void setWechatStatisTimeSch(Long wechatStatisTimeSch){
        this.wechatStatisTimeSch = wechatStatisTimeSch;
    }
    
    @ValueField(column = "wechat_statis_time")
    public Long getWechatStatisTimeSch(){
        return this.wechatStatisTimeSch;
    }

    public void setWechatTotalUserSch(Integer wechatTotalUserSch){
        this.wechatTotalUserSch = wechatTotalUserSch;
    }
    
    @ValueField(column = "wechat_total_user")
    public Integer getWechatTotalUserSch(){
        return this.wechatTotalUserSch;
    }

    public void setWechatHomePageUvSch(Integer wechatHomePageUvSch){
        this.wechatHomePageUvSch = wechatHomePageUvSch;
    }
    
    @ValueField(column = "wechat_home_page_uv")
    public Integer getWechatHomePageUvSch(){
        return this.wechatHomePageUvSch;
    }

    public void setWechatNewFansSch(Integer wechatNewFansSch){
        this.wechatNewFansSch = wechatNewFansSch;
    }
    
    @ValueField(column = "wechat_new_fans")
    public Integer getWechatNewFansSch(){
        return this.wechatNewFansSch;
    }

    public void setWechatTotalFansSch(Integer wechatTotalFansSch){
        this.wechatTotalFansSch = wechatTotalFansSch;
    }
    
    @ValueField(column = "wechat_total_fans")
    public Integer getWechatTotalFansSch(){
        return this.wechatTotalFansSch;
    }

    public void setWechatWxConnectUserSch(Integer wechatWxConnectUserSch){
        this.wechatWxConnectUserSch = wechatWxConnectUserSch;
    }
    
    @ValueField(column = "wechat_wx_connect_user")
    public Integer getWechatWxConnectUserSch(){
        return this.wechatWxConnectUserSch;
    }

    public void setWechatConnectMsgUserSch(Integer wechatConnectMsgUserSch){
        this.wechatConnectMsgUserSch = wechatConnectMsgUserSch;
    }
    
    @ValueField(column = "wechat_connect_msg_user")
    public Integer getWechatConnectMsgUserSch(){
        return this.wechatConnectMsgUserSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateAccountIdSch(Long createAccountIdSch){
        this.createAccountIdSch = createAccountIdSch;
    }
    
    @ValueField(column = "create_account_id")
    public Long getCreateAccountIdSch(){
        return this.createAccountIdSch;
    }

    public void setUpdateAccountIdSch(Long updateAccountIdSch){
        this.updateAccountIdSch = updateAccountIdSch;
    }
    
    @ValueField(column = "update_account_id")
    public Long getUpdateAccountIdSch(){
        return this.updateAccountIdSch;
    }


}