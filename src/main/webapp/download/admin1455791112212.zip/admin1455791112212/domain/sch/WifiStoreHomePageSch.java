package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStoreHomePageSch extends SearchEntity{

    private Long wifiStoreHomePageIdSch;
    private Long aidSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Integer wechatTemplateTypeSch;
    private String wechatCustomUrlSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long createAccountIdSch;
    private Long updateAccountIdSch;

    public void setWifiStoreHomePageIdSch(Long wifiStoreHomePageIdSch){
        this.wifiStoreHomePageIdSch = wifiStoreHomePageIdSch;
    }
    
    @ValueField(column = "wifi_store_home_page_id")
    public Long getWifiStoreHomePageIdSch(){
        return this.wifiStoreHomePageIdSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setWechatTemplateTypeSch(Integer wechatTemplateTypeSch){
        this.wechatTemplateTypeSch = wechatTemplateTypeSch;
    }
    
    @ValueField(column = "wechat_template_type")
    public Integer getWechatTemplateTypeSch(){
        return this.wechatTemplateTypeSch;
    }

    public void setWechatCustomUrlSch(String wechatCustomUrlSch){
        this.wechatCustomUrlSch = wechatCustomUrlSch;
    }
    
    @ValueField(column = "wechat_custom_url")
    public String getWechatCustomUrlSch(){
        return this.wechatCustomUrlSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateAccountIdSch(Long createAccountIdSch){
        this.createAccountIdSch = createAccountIdSch;
    }
    
    @ValueField(column = "create_account_id")
    public Long getCreateAccountIdSch(){
        return this.createAccountIdSch;
    }

    public void setUpdateAccountIdSch(Long updateAccountIdSch){
        this.updateAccountIdSch = updateAccountIdSch;
    }
    
    @ValueField(column = "update_account_id")
    public Long getUpdateAccountIdSch(){
        return this.updateAccountIdSch;
    }


}