package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiSupplierSch extends SearchEntity{

    private Long wifiSupplierIdSch;
    private String supplierNameSch;
    private String deviceTypesSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long createAccountIdSch;
    private Long updateAccountIdSch;

    public void setWifiSupplierIdSch(Long wifiSupplierIdSch){
        this.wifiSupplierIdSch = wifiSupplierIdSch;
    }
    
    @ValueField(column = "wifi_supplier_id")
    public Long getWifiSupplierIdSch(){
        return this.wifiSupplierIdSch;
    }

    public void setSupplierNameSch(String supplierNameSch){
        this.supplierNameSch = supplierNameSch;
    }
    
    @ValueField(column = "supplier_name")
    public String getSupplierNameSch(){
        return this.supplierNameSch;
    }

    public void setDeviceTypesSch(String deviceTypesSch){
        this.deviceTypesSch = deviceTypesSch;
    }
    
    @ValueField(column = "device_types")
    public String getDeviceTypesSch(){
        return this.deviceTypesSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateAccountIdSch(Long createAccountIdSch){
        this.createAccountIdSch = createAccountIdSch;
    }
    
    @ValueField(column = "create_account_id")
    public Long getCreateAccountIdSch(){
        return this.createAccountIdSch;
    }

    public void setUpdateAccountIdSch(Long updateAccountIdSch){
        this.updateAccountIdSch = updateAccountIdSch;
    }
    
    @ValueField(column = "update_account_id")
    public Long getUpdateAccountIdSch(){
        return this.updateAccountIdSch;
    }


}