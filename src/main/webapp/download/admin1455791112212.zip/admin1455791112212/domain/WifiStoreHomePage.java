package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStoreHomePage implements Serializable {
	private Long wifiStoreHomePageId;
	private Long aid;
	private Long merchantId;
	private Long storeId;
	private Integer wechatTemplateType;
	private String wechatCustomUrl;
	private Date createTime;
	private Date updateTime;
	private Long createAccountId;
	private Long updateAccountId;
}