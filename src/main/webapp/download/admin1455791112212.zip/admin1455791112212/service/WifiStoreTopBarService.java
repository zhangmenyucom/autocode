package com.weimob.o2o.mgr.wifi.service;

import com.weimob.o2o.mgr.wifi.domain.WifiStoreTopBar;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiStoreTopBarService extends CrudServiceInterface<WifiStoreTopBar> {

}