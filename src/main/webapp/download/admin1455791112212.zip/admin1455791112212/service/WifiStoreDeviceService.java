package com.weimob.o2o.mgr.wifi.service;

import com.weimob.o2o.mgr.wifi.domain.WifiStoreDevice;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiStoreDeviceService extends CrudServiceInterface<WifiStoreDevice> {

}