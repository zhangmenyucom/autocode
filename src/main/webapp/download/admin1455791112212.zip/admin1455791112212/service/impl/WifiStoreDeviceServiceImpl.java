package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiStoreDeviceService;
import com.weimob.o2o.mgr.wifi.dao.WifiStoreDeviceDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreDevice;
import org.springframework.stereotype.Service;
    
@Service
public class WifiStoreDeviceServiceImpl 
        extends CrudService<WifiStoreDevice, WifiStoreDeviceDao> 
        implements WifiStoreDeviceService {

}