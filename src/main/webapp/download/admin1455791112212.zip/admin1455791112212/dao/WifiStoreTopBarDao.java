package com.weimob.o2o.mgr.wifi.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreTopBar;

public interface WifiStoreTopBarDao extends BaseDao<WifiStoreTopBar> {
}