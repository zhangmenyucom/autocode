package com.weimob.o2o.mgr.business.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.business.domain.O2oBusinessInfo;

public interface O2oBusinessInfoDao extends BaseDao<O2oBusinessInfo> {
}