package com.weimob.o2o.mgr.business.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.business.domain.O2oBusinessInfo;
import com.weimob.o2o.mgr.business.domain.sch.O2oBusinessInfoSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oBusinessInfoService extends CrudServiceInterface<O2oBusinessInfo> {

    PageInfo<O2oBusinessInfo> findPage(O2oBusinessInfoSch sch);
}