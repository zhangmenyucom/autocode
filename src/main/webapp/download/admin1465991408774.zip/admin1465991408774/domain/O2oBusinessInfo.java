package com.weimob.o2o.mgr.business.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oBusinessInfo implements Serializable {
	private Long id;
	private Long bid;
	private Long aid;
	private Date tryServiceStartTime;
	private Date tryServiceEndTime;
	private Date updateTime;
	private Date createTime;
}