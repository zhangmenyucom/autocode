package com.weimob.o2o.mgr.business.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oBusinessInfoSch extends SearchEntity{

    private Long idSch;
    private Long bidSch;
    private Long aidSch;
    private Date tryServiceStartTimeSch;
    private Date tryServiceEndTimeSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setBidSch(Long bidSch){
        this.bidSch = bidSch;
    }
    
    @ValueField(column = "bid")
    public Long getBidSch(){
        return this.bidSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setTryServiceStartTimeSch(Date tryServiceStartTimeSch){
        this.tryServiceStartTimeSch = tryServiceStartTimeSch;
    }
    
    @ValueField(column = "try_service_start_time")
    public Date getTryServiceStartTimeSch(){
        return this.tryServiceStartTimeSch;
    }

    public void setTryServiceEndTimeSch(Date tryServiceEndTimeSch){
        this.tryServiceEndTimeSch = tryServiceEndTimeSch;
    }
    
    @ValueField(column = "try_service_end_time")
    public Date getTryServiceEndTimeSch(){
        return this.tryServiceEndTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}