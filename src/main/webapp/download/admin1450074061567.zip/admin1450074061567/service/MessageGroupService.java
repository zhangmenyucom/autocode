package com.weimob.o2o.mgr.message.service;

import com.weimob.o2o.mgr.message.domain.MessageGroup;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MessageGroupService extends CrudServiceInterface<MessageGroup> {

}