package com.weimob.o2o.mgr.message.service;

import com.weimob.o2o.mgr.message.domain.MessageGroupUser;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MessageGroupUserService extends CrudServiceInterface<MessageGroupUser> {

}