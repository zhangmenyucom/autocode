package com.weimob.o2o.mgr.message.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.message.domain.MessageGroup;

public interface MessageGroupDao extends BaseDao<MessageGroup> {
}