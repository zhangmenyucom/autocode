package com.weimob.o2o.mgr.shake.service;

import org.durcframework.core.dao.BaseDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeFocusService<Entity, Dao extends BaseDao<Entity>> extends CrudServiceInterface<Entity, Dao> {

}