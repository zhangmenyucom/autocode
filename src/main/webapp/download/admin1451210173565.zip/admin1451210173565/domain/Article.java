package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Article implements Serializable {
	private Integer id;
	private String title;
	private String content;
	private Integer clasfId;
	private Integer deleteFlag;
	private Integer userId;
	private String userName;
	private Date createDate;
	private Date updateDate;
	private Integer viewNumber;
}