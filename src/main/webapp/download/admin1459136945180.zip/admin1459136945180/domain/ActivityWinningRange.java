package com.weimob.o2o.activity.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ActivityWinningRange implements Serializable {
	private Long activityWinningRangeId;
	private Long activityId;
	private Integer winningRangeType;
	private String winningRangeIds;
	private String comment;
	private Date createTime;
	private Date udpateTime;
}