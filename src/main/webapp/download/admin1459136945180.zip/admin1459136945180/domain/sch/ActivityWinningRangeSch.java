package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ActivityWinningRangeSch extends SearchEntity{

    private Long activityWinningRangeIdSch;
    private Long activityIdSch;
    private Integer winningRangeTypeSch;
    private String winningRangeIdsSch;
    private String commentSch;
    private Date createTimeSch;
    private Date udpateTimeSch;

    public void setActivityWinningRangeIdSch(Long activityWinningRangeIdSch){
        this.activityWinningRangeIdSch = activityWinningRangeIdSch;
    }
    
    @ValueField(column = "activity_winning_range_id")
    public Long getActivityWinningRangeIdSch(){
        return this.activityWinningRangeIdSch;
    }

    public void setActivityIdSch(Long activityIdSch){
        this.activityIdSch = activityIdSch;
    }
    
    @ValueField(column = "activity_id")
    public Long getActivityIdSch(){
        return this.activityIdSch;
    }

    public void setWinningRangeTypeSch(Integer winningRangeTypeSch){
        this.winningRangeTypeSch = winningRangeTypeSch;
    }
    
    @ValueField(column = "winning_range_type")
    public Integer getWinningRangeTypeSch(){
        return this.winningRangeTypeSch;
    }

    public void setWinningRangeIdsSch(String winningRangeIdsSch){
        this.winningRangeIdsSch = winningRangeIdsSch;
    }
    
    @ValueField(column = "winning_range_ids")
    public String getWinningRangeIdsSch(){
        return this.winningRangeIdsSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUdpateTimeSch(Date udpateTimeSch){
        this.udpateTimeSch = udpateTimeSch;
    }
    
    @ValueField(column = "udpate_time")
    public Date getUdpateTimeSch(){
        return this.udpateTimeSch;
    }


}