package com.weimob.o2o.activity.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.activity.mgr.domain.ActivityWinningRange;

public interface ActivityWinningRangeDao extends BaseDao<ActivityWinningRange> {
}