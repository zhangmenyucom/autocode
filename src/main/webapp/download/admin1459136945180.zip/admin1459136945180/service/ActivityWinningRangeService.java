package com.weimob.o2o.activity.mgr.service;

import com.weimob.o2o.activity.mgr.domain.ActivityWinningRange;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ActivityWinningRangeService extends CrudServiceInterface<ActivityWinningRange> {

}