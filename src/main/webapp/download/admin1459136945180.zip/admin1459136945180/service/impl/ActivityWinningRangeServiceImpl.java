package com.weimob.o2o.activity.mgr.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.activity.mgr.service.ActivityWinningRangeService;
import com.weimob.o2o.activity.mgr.dao.ActivityWinningRangeDao;
import com.weimob.o2o.activity.mgr.domain.ActivityWinningRange;
import org.springframework.stereotype.Service;
    
@Service
public class ActivityWinningRangeServiceImpl 
        extends CrudService<ActivityWinningRange, ActivityWinningRangeDao> 
        implements ActivityWinningRangeService {

}