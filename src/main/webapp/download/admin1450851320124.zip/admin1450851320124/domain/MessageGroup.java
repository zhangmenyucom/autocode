package com.weimob.o2o.mgr.message.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MessageGroup implements Serializable {
	private Long messageGroupId;
	private Long merchantId;
	private String userConditions;
	private Integer planSendType;
	private Date planSendTime;
	private String msgType;
	private Long mediaId;
	private String wxMediaId;
	private String coverPicUrl;
	private String content;
	private String title;
	private String description;
	private String wxcardCardId;
	private String msgId;
	private String msgDataId;
	private String msgStatus;
	private Long wxCreateTime;
	private Long totalCount;
	private Long filterCount;
	private Long sentCount;
	private Long errorCount;
	private Integer deleteFlag;
	private Date createTime;
	private Date updateTime;
	private Long creataUserId;
	private Long updateUserId;
}