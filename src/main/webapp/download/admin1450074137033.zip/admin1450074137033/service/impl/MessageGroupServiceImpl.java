package com.weimob.o2o.mgr.message.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.message.service.MessageGroupService;
import com.weimob.o2o.mgr.message.dao.MessageGroupDao;
import com.weimob.o2o.mgr.message.domain.MessageGroup;
import org.springframework.stereotype.Service;
    
@Service
public class MessageGroupServiceImpl 
        extends CrudService<MessageGroup, MessageGroupDao> 
        implements MessageGroupService {

}