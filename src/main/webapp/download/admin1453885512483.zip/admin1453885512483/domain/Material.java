package com.weimob.o2o.mgr.material.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Material implements Serializable {
	private Long materialId;
	private Long merchantId;
	private Long aid;
	private String mediaId;
	private String linkId;
	private Integer linkType;
	private String linkName;
	private Integer linkClassification;
	private Date createTime;
	private Date updateTime;
}