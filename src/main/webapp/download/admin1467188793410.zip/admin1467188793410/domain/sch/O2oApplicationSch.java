package com.weimob.o2o.mgr.application.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oApplicationSch extends SearchEntity{

    private Long idSch;
    private Integer typeSch;
    private String nameSch;
    private String descriptionSch;
    private String logoUrlSch;
    private String linkSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setNameSch(String nameSch){
        this.nameSch = nameSch;
    }
    
    @ValueField(column = "name")
    public String getNameSch(){
        return this.nameSch;
    }

    public void setDescriptionSch(String descriptionSch){
        this.descriptionSch = descriptionSch;
    }
    
    @ValueField(column = "description")
    public String getDescriptionSch(){
        return this.descriptionSch;
    }

    public void setLogoUrlSch(String logoUrlSch){
        this.logoUrlSch = logoUrlSch;
    }
    
    @ValueField(column = "logo_url")
    public String getLogoUrlSch(){
        return this.logoUrlSch;
    }

    public void setLinkSch(String linkSch){
        this.linkSch = linkSch;
    }
    
    @ValueField(column = "link")
    public String getLinkSch(){
        return this.linkSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}