package com.weimob.o2o.mgr.application.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oApplicationConfig implements Serializable {
	private Long id;
	private Long merchantId;
	private Long applicationId;
	private Integer type;
	private Integer status;
	private Date updateTime;
	private Date createTime;
}