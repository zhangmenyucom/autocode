package com.weimob.o2o.mgr.employee.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class EmployeeContributionSch extends SearchEntity{

    private Long employeeContributionIdSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Long employeeIdSch;
    private Long businessIdSch;
    private Integer businessTypeSch;
    private BigDecimal businessValueSch;
    private String customerOpenIdSch;
    private String customerNameSch;
    private Long employeeIndexSettingIdSch;
    private BigDecimal planRewardValueSch;
    private Integer rewardStatusSch;
    private BigDecimal rewardValueSch;
    private Integer rewardValueTypeSch;
    private Integer statusSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setEmployeeContributionIdSch(Long employeeContributionIdSch){
        this.employeeContributionIdSch = employeeContributionIdSch;
    }
    
    @ValueField(column = "employee_contribution_id")
    public Long getEmployeeContributionIdSch(){
        return this.employeeContributionIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setEmployeeIdSch(Long employeeIdSch){
        this.employeeIdSch = employeeIdSch;
    }
    
    @ValueField(column = "employee_id")
    public Long getEmployeeIdSch(){
        return this.employeeIdSch;
    }

    public void setBusinessIdSch(Long businessIdSch){
        this.businessIdSch = businessIdSch;
    }
    
    @ValueField(column = "business_id")
    public Long getBusinessIdSch(){
        return this.businessIdSch;
    }

    public void setBusinessTypeSch(Integer businessTypeSch){
        this.businessTypeSch = businessTypeSch;
    }
    
    @ValueField(column = "business_type")
    public Integer getBusinessTypeSch(){
        return this.businessTypeSch;
    }

    public void setBusinessValueSch(BigDecimal businessValueSch){
        this.businessValueSch = businessValueSch;
    }
    
    @ValueField(column = "business_value")
    public BigDecimal getBusinessValueSch(){
        return this.businessValueSch;
    }

    public void setCustomerOpenIdSch(String customerOpenIdSch){
        this.customerOpenIdSch = customerOpenIdSch;
    }
    
    @ValueField(column = "customer_open_id")
    public String getCustomerOpenIdSch(){
        return this.customerOpenIdSch;
    }

    public void setCustomerNameSch(String customerNameSch){
        this.customerNameSch = customerNameSch;
    }
    
    @ValueField(column = "customer_name")
    public String getCustomerNameSch(){
        return this.customerNameSch;
    }

    public void setEmployeeIndexSettingIdSch(Long employeeIndexSettingIdSch){
        this.employeeIndexSettingIdSch = employeeIndexSettingIdSch;
    }
    
    @ValueField(column = "employee_index_setting_id")
    public Long getEmployeeIndexSettingIdSch(){
        return this.employeeIndexSettingIdSch;
    }

    public void setPlanRewardValueSch(BigDecimal planRewardValueSch){
        this.planRewardValueSch = planRewardValueSch;
    }
    
    @ValueField(column = "plan_reward_value")
    public BigDecimal getPlanRewardValueSch(){
        return this.planRewardValueSch;
    }

    public void setRewardStatusSch(Integer rewardStatusSch){
        this.rewardStatusSch = rewardStatusSch;
    }
    
    @ValueField(column = "reward_status")
    public Integer getRewardStatusSch(){
        return this.rewardStatusSch;
    }

    public void setRewardValueSch(BigDecimal rewardValueSch){
        this.rewardValueSch = rewardValueSch;
    }
    
    @ValueField(column = "reward_value")
    public BigDecimal getRewardValueSch(){
        return this.rewardValueSch;
    }

    public void setRewardValueTypeSch(Integer rewardValueTypeSch){
        this.rewardValueTypeSch = rewardValueTypeSch;
    }
    
    @ValueField(column = "reward_value_type")
    public Integer getRewardValueTypeSch(){
        return this.rewardValueTypeSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}