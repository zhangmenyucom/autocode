package com.weimob.o2o.mgr.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.weimob.o2o.mgr.entity.ShakeDevicePage;
import com.weimob.o2o.mgr.entity.ShakeDevicePageSch;
import com.weimob.o2o.mgr.service.ShakeDevicePageService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ShakeDevicePageController extends
		CrudController<ShakeDevicePage, ShakeDevicePageService> {

	@RequestMapping("/addShakeDevicePage.do")
	public @ResponseBody
	MessageResult addShakeDevicePage(ShakeDevicePage entity) {
		return this.save(entity);
	}

	@RequestMapping("/listShakeDevicePage.do")
	public @ResponseBody
	GridResult listShakeDevicePage(ShakeDevicePageSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateShakeDevicePage.do")
	public @ResponseBody
	MessageResult updateShakeDevicePage(ShakeDevicePage entity) {
		return this.update(entity);
	}

	@RequestMapping("/delShakeDevicePage.do")
	public @ResponseBody
	MessageResult delShakeDevicePage(ShakeDevicePage entity) {
		return this.delete(entity);
	}
	
}