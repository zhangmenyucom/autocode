package com.weimob.o2o.mgr.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.weimob.o2o.mgr.entity.ShakeDevice;
import com.weimob.o2o.mgr.entity.ShakeDeviceSch;
import com.weimob.o2o.mgr.service.ShakeDeviceService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ShakeDeviceController extends
		CrudController<ShakeDevice, ShakeDeviceService> {

	@RequestMapping("/addShakeDevice.do")
	public @ResponseBody
	MessageResult addShakeDevice(ShakeDevice entity) {
		return this.save(entity);
	}

	@RequestMapping("/listShakeDevice.do")
	public @ResponseBody
	GridResult listShakeDevice(ShakeDeviceSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateShakeDevice.do")
	public @ResponseBody
	MessageResult updateShakeDevice(ShakeDevice entity) {
		return this.update(entity);
	}

	@RequestMapping("/delShakeDevice.do")
	public @ResponseBody
	MessageResult delShakeDevice(ShakeDevice entity) {
		return this.delete(entity);
	}
	
}