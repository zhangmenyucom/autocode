package com.weimob.o2o.mgr.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import com.weimob.o2o.mgr.entity.ShakeFocus;
import com.weimob.o2o.mgr.entity.ShakeFocusSch;
import com.weimob.o2o.mgr.service.ShakeFocusService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ShakeFocusController extends
		CrudController<ShakeFocus, ShakeFocusService> {

	@RequestMapping("/addShakeFocus.do")
	public @ResponseBody
	MessageResult addShakeFocus(ShakeFocus entity) {
		return this.save(entity);
	}

	@RequestMapping("/listShakeFocus.do")
	public @ResponseBody
	GridResult listShakeFocus(ShakeFocusSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateShakeFocus.do")
	public @ResponseBody
	MessageResult updateShakeFocus(ShakeFocus entity) {
		return this.update(entity);
	}

	@RequestMapping("/delShakeFocus.do")
	public @ResponseBody
	MessageResult delShakeFocus(ShakeFocus entity) {
		return this.delete(entity);
	}
	
}