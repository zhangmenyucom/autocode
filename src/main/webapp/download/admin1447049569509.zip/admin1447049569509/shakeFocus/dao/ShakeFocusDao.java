package com.weimob.o2o.mgr.shakeFocus.dao;

import com.shunwang.business.framework.dao.CrudDao;
import com.weimob.o2o.mgr.shakeFocus.pojo.ShakeFocus;

public interface ShakeFocusDao extends CrudDao<ShakeFocus> {
}