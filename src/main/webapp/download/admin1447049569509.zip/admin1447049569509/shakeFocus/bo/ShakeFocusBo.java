package com.weimob.o2o.mgr.shakeFocus.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import com.weimob.o2o.mgr.shakeFocus.dao.ShakeFocusDao;
import com.weimob.o2o.mgr.shakeFocus.pojo.ShakeFocus;

@Service
public class ShakeFocusBo extends CrudBo<ShakeFocus, ShakeFocusDao> {

}