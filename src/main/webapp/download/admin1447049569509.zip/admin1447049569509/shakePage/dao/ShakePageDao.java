package com.weimob.o2o.mgr.shakePage.dao;

import com.shunwang.business.framework.dao.CrudDao;
import com.weimob.o2o.mgr.shakePage.pojo.ShakePage;

public interface ShakePageDao extends CrudDao<ShakePage> {
}