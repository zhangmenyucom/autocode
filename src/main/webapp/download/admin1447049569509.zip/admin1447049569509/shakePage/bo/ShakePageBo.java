package com.weimob.o2o.mgr.shakePage.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import com.weimob.o2o.mgr.shakePage.dao.ShakePageDao;
import com.weimob.o2o.mgr.shakePage.pojo.ShakePage;

@Service
public class ShakePageBo extends CrudBo<ShakePage, ShakePageDao> {

}