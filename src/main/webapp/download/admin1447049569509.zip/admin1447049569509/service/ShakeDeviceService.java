package com.weimob.o2o.mgr.service;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.dao.ShakeDeviceDao;
import com.weimob.o2o.mgr.entity.ShakeDevice;
import org.springframework.stereotype.Service;

@Service
public class ShakeDeviceService extends CrudService<ShakeDevice, ShakeDeviceDao> {

}