package com.weimob.o2o.mgr.service;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.dao.ShakePageDao;
import com.weimob.o2o.mgr.entity.ShakePage;
import org.springframework.stereotype.Service;

@Service
public class ShakePageService extends CrudService<ShakePage, ShakePageDao> {

}