package com.weimob.o2o.mgr.service;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.dao.ShakeDevicePageDao;
import com.weimob.o2o.mgr.entity.ShakeDevicePage;
import org.springframework.stereotype.Service;

@Service
public class ShakeDevicePageService extends CrudService<ShakeDevicePage, ShakeDevicePageDao> {

}