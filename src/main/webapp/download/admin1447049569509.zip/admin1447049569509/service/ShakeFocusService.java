package com.weimob.o2o.mgr.service;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.dao.ShakeFocusDao;
import com.weimob.o2o.mgr.entity.ShakeFocus;
import org.springframework.stereotype.Service;

@Service
public class ShakeFocusService extends CrudService<ShakeFocus, ShakeFocusDao> {

}