package com.weimob.o2o.mgr.shakeDeviceApply.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import com.weimob.o2o.mgr.shakeDeviceApply.dao.ShakeDeviceApplyDao;
import com.weimob.o2o.mgr.shakeDeviceApply.pojo.ShakeDeviceApply;

@Service
public class ShakeDeviceApplyBo extends CrudBo<ShakeDeviceApply, ShakeDeviceApplyDao> {

}