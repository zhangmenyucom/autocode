package com.weimob.o2o.mgr.shakeDeviceApply.dao;

import com.shunwang.business.framework.dao.CrudDao;
import com.weimob.o2o.mgr.shakeDeviceApply.pojo.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends CrudDao<ShakeDeviceApply> {
}