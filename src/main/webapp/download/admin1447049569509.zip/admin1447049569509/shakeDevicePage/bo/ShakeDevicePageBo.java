package com.weimob.o2o.mgr.shakeDevicePage.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import com.weimob.o2o.mgr.shakeDevicePage.dao.ShakeDevicePageDao;
import com.weimob.o2o.mgr.shakeDevicePage.pojo.ShakeDevicePage;

@Service
public class ShakeDevicePageBo extends CrudBo<ShakeDevicePage, ShakeDevicePageDao> {

}