package com.weimob.o2o.mgr.shakeDevicePage.dao;

import com.shunwang.business.framework.dao.CrudDao;
import com.weimob.o2o.mgr.shakeDevicePage.pojo.ShakeDevicePage;

public interface ShakeDevicePageDao extends CrudDao<ShakeDevicePage> {
}