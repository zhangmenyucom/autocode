package com.weimob.o2o.mgr.shakeDevice.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import com.weimob.o2o.mgr.shakeDevice.dao.ShakeDeviceDao;
import com.weimob.o2o.mgr.shakeDevice.pojo.ShakeDevice;

@Service
public class ShakeDeviceBo extends CrudBo<ShakeDevice, ShakeDeviceDao> {

}