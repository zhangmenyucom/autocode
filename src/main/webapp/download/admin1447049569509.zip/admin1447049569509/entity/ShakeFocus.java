package com.weimob.o2o.mgr.entity;

public class ShakeFocus {
	private int shakeFucusId;
	private String title;
	private String description;
	private String slogan;
	private String backgroundUrl;
	private String shakePageId;

	public void setShakeFucusId(int shakeFucusId){
		this.shakeFucusId = shakeFucusId;
	}

	public int getShakeFucusId(){
		return this.shakeFucusId;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return this.description;
	}

	public void setSlogan(String slogan){
		this.slogan = slogan;
	}

	public String getSlogan(){
		return this.slogan;
	}

	public void setBackgroundUrl(String backgroundUrl){
		this.backgroundUrl = backgroundUrl;
	}

	public String getBackgroundUrl(){
		return this.backgroundUrl;
	}

	public void setShakePageId(String shakePageId){
		this.shakePageId = shakePageId;
	}

	public String getShakePageId(){
		return this.shakePageId;
	}

}