package com.weimob.o2o.mgr.entity;

public class ShakeDevice {
	private int shakeDeviceId;
	private String applyId;
	private String uuid;
	private String major;
	private String minor;
	private String comment;
	private String wxPoiId;
	private int status;
	private int shakeDeviceApplyId;
	private String merchantId;
	private String poiId;

	public void setShakeDeviceId(int shakeDeviceId){
		this.shakeDeviceId = shakeDeviceId;
	}

	public int getShakeDeviceId(){
		return this.shakeDeviceId;
	}

	public void setApplyId(String applyId){
		this.applyId = applyId;
	}

	public String getApplyId(){
		return this.applyId;
	}

	public void setUuid(String uuid){
		this.uuid = uuid;
	}

	public String getUuid(){
		return this.uuid;
	}

	public void setMajor(String major){
		this.major = major;
	}

	public String getMajor(){
		return this.major;
	}

	public void setMinor(String minor){
		this.minor = minor;
	}

	public String getMinor(){
		return this.minor;
	}

	public void setComment(String comment){
		this.comment = comment;
	}

	public String getComment(){
		return this.comment;
	}

	public void setWxPoiId(String wxPoiId){
		this.wxPoiId = wxPoiId;
	}

	public String getWxPoiId(){
		return this.wxPoiId;
	}

	public void setStatus(int status){
		this.status = status;
	}

	public int getStatus(){
		return this.status;
	}

	public void setShakeDeviceApplyId(int shakeDeviceApplyId){
		this.shakeDeviceApplyId = shakeDeviceApplyId;
	}

	public int getShakeDeviceApplyId(){
		return this.shakeDeviceApplyId;
	}

	public void setMerchantId(String merchantId){
		this.merchantId = merchantId;
	}

	public String getMerchantId(){
		return this.merchantId;
	}

	public void setPoiId(String poiId){
		this.poiId = poiId;
	}

	public String getPoiId(){
		return this.poiId;
	}

}