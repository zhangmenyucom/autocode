package com.weimob.o2o.mgr.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDeviceSch extends SearchEntity{

    private Integer shakeDeviceIdSch;
    private String applyIdSch;
    private String uuidSch;
    private String majorSch;
    private String minorSch;
    private String commentSch;
    private String wxPoiIdSch;
    private Integer statusSch;
    private Integer shakeDeviceApplyIdSch;
    private String merchantIdSch;
    private String poiIdSch;

    public void setShakeDeviceIdSch(Integer shakeDeviceIdSch){
        this.shakeDeviceIdSch = shakeDeviceIdSch;
    }
    
    @ValueField(column = "shake_device_id")
    public Integer getShakeDeviceIdSch(){
        return this.shakeDeviceIdSch;
    }

    public void setApplyIdSch(String applyIdSch){
        this.applyIdSch = applyIdSch;
    }
    
    @ValueField(column = "apply_id")
    public String getApplyIdSch(){
        return this.applyIdSch;
    }

    public void setUuidSch(String uuidSch){
        this.uuidSch = uuidSch;
    }
    
    @ValueField(column = "uuid")
    public String getUuidSch(){
        return this.uuidSch;
    }

    public void setMajorSch(String majorSch){
        this.majorSch = majorSch;
    }
    
    @ValueField(column = "major")
    public String getMajorSch(){
        return this.majorSch;
    }

    public void setMinorSch(String minorSch){
        this.minorSch = minorSch;
    }
    
    @ValueField(column = "minor")
    public String getMinorSch(){
        return this.minorSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setWxPoiIdSch(String wxPoiIdSch){
        this.wxPoiIdSch = wxPoiIdSch;
    }
    
    @ValueField(column = "wx_poi_id")
    public String getWxPoiIdSch(){
        return this.wxPoiIdSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setShakeDeviceApplyIdSch(Integer shakeDeviceApplyIdSch){
        this.shakeDeviceApplyIdSch = shakeDeviceApplyIdSch;
    }
    
    @ValueField(column = "shake_device_apply_id")
    public Integer getShakeDeviceApplyIdSch(){
        return this.shakeDeviceApplyIdSch;
    }

    public void setMerchantIdSch(String merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public String getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setPoiIdSch(String poiIdSch){
        this.poiIdSch = poiIdSch;
    }
    
    @ValueField(column = "poi_id")
    public String getPoiIdSch(){
        return this.poiIdSch;
    }


}