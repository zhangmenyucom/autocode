package com.weimob.o2o.mgr.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDevicePageSch extends SearchEntity{

    private Integer shakeDevicePageIdSch;
    private Integer shakeDeviceIdSch;
    private Integer shakePageIdSch;

    public void setShakeDevicePageIdSch(Integer shakeDevicePageIdSch){
        this.shakeDevicePageIdSch = shakeDevicePageIdSch;
    }
    
    @ValueField(column = "shake_device_page_id")
    public Integer getShakeDevicePageIdSch(){
        return this.shakeDevicePageIdSch;
    }

    public void setShakeDeviceIdSch(Integer shakeDeviceIdSch){
        this.shakeDeviceIdSch = shakeDeviceIdSch;
    }
    
    @ValueField(column = "shake_device_id")
    public Integer getShakeDeviceIdSch(){
        return this.shakeDeviceIdSch;
    }

    public void setShakePageIdSch(Integer shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Integer getShakePageIdSch(){
        return this.shakePageIdSch;
    }


}