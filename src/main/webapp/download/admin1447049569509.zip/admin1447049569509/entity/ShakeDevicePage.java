package com.weimob.o2o.mgr.entity;

public class ShakeDevicePage {
	private int shakeDevicePageId;
	private int shakeDeviceId;
	private int shakePageId;

	public void setShakeDevicePageId(int shakeDevicePageId){
		this.shakeDevicePageId = shakeDevicePageId;
	}

	public int getShakeDevicePageId(){
		return this.shakeDevicePageId;
	}

	public void setShakeDeviceId(int shakeDeviceId){
		this.shakeDeviceId = shakeDeviceId;
	}

	public int getShakeDeviceId(){
		return this.shakeDeviceId;
	}

	public void setShakePageId(int shakePageId){
		this.shakePageId = shakePageId;
	}

	public int getShakePageId(){
		return this.shakePageId;
	}

}