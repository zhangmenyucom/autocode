package com.weimob.o2o.mgr.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeFocusSch extends SearchEntity{

    private Integer shakeFucusIdSch;
    private String titleSch;
    private String descriptionSch;
    private String sloganSch;
    private String backgroundUrlSch;
    private String shakePageIdSch;

    public void setShakeFucusIdSch(Integer shakeFucusIdSch){
        this.shakeFucusIdSch = shakeFucusIdSch;
    }
    
    @ValueField(column = "shake_fucus_id")
    public Integer getShakeFucusIdSch(){
        return this.shakeFucusIdSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setDescriptionSch(String descriptionSch){
        this.descriptionSch = descriptionSch;
    }
    
    @ValueField(column = "description")
    public String getDescriptionSch(){
        return this.descriptionSch;
    }

    public void setSloganSch(String sloganSch){
        this.sloganSch = sloganSch;
    }
    
    @ValueField(column = "slogan")
    public String getSloganSch(){
        return this.sloganSch;
    }

    public void setBackgroundUrlSch(String backgroundUrlSch){
        this.backgroundUrlSch = backgroundUrlSch;
    }
    
    @ValueField(column = "background_url")
    public String getBackgroundUrlSch(){
        return this.backgroundUrlSch;
    }

    public void setShakePageIdSch(String shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public String getShakePageIdSch(){
        return this.shakePageIdSch;
    }


}