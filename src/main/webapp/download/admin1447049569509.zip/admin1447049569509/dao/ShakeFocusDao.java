package com.weimob.o2o.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.entity.ShakeFocus;

public interface ShakeFocusDao extends BaseDao<ShakeFocus> {
}