package com.weimob.o2o.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.entity.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends BaseDao<ShakeDeviceApply> {
}