package com.weimob.o2o.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.entity.ShakePage;

public interface ShakePageDao extends BaseDao<ShakePage> {
}