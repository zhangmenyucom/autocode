package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class UserSch extends SearchEntity{

    private Integer idSch;
    private Integer accountIdSch;
    private String userNicknameSch;
    private String userMailSch;

    public void setIdSch(Integer idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Integer getIdSch(){
        return this.idSch;
    }

    public void setAccountIdSch(Integer accountIdSch){
        this.accountIdSch = accountIdSch;
    }
    
    @ValueField(column = "account_id")
    public Integer getAccountIdSch(){
        return this.accountIdSch;
    }

    public void setUserNicknameSch(String userNicknameSch){
        this.userNicknameSch = userNicknameSch;
    }
    
    @ValueField(column = "user_nickname")
    public String getUserNicknameSch(){
        return this.userNicknameSch;
    }

    public void setUserMailSch(String userMailSch){
        this.userMailSch = userMailSch;
    }
    
    @ValueField(column = "user_mail")
    public String getUserMailSch(){
        return this.userMailSch;
    }


}