package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class AccountSch extends SearchEntity{

    private Integer idSch;
    private String accountSch;
    private String passwordSch;
    private Integer typeSch;

    public void setIdSch(Integer idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Integer getIdSch(){
        return this.idSch;
    }

    public void setAccountSch(String accountSch){
        this.accountSch = accountSch;
    }
    
    @ValueField(column = "account")
    public String getAccountSch(){
        return this.accountSch;
    }

    public void setPasswordSch(String passwordSch){
        this.passwordSch = passwordSch;
    }
    
    @ValueField(column = "password")
    public String getPasswordSch(){
        return this.passwordSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }


}