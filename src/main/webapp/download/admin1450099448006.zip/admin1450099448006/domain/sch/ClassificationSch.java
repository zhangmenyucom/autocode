package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ClassificationSch extends SearchEntity{

    private Integer idSch;
    private String clasfNameSch;
    private Date createDateSch;
    private Date updateDateSch;
    private Integer deleteFlagSch;

    public void setIdSch(Integer idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Integer getIdSch(){
        return this.idSch;
    }

    public void setClasfNameSch(String clasfNameSch){
        this.clasfNameSch = clasfNameSch;
    }
    
    @ValueField(column = "clasf_name")
    public String getClasfNameSch(){
        return this.clasfNameSch;
    }

    public void setCreateDateSch(Date createDateSch){
        this.createDateSch = createDateSch;
    }
    
    @ValueField(column = "create_date")
    public Date getCreateDateSch(){
        return this.createDateSch;
    }

    public void setUpdateDateSch(Date updateDateSch){
        this.updateDateSch = updateDateSch;
    }
    
    @ValueField(column = "update_date")
    public Date getUpdateDateSch(){
        return this.updateDateSch;
    }

    public void setDeleteFlagSch(Integer deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Integer getDeleteFlagSch(){
        return this.deleteFlagSch;
    }


}