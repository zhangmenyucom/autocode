package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Classification implements Serializable {
	private Integer id;
	private String clasfName;
	private Date createDate;
	private Date updateDate;
	private Integer deleteFlag;
}