package com.ayuan.blog.service;

import com.ayuan.blog.domain.Classification;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ClassificationService extends CrudServiceInterface<Classification> {

}