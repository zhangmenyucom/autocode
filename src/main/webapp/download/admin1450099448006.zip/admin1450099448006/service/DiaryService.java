package com.ayuan.blog.service;

import com.ayuan.blog.domain.Diary;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface DiaryService extends CrudServiceInterface<Diary> {

}