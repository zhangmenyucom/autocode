package com.ayuan.blog.service;

import com.ayuan.blog.domain.Article;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ArticleService extends CrudServiceInterface<Article> {

}