package com.ayuan.blog.service;

import com.ayuan.blog.domain.User;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface UserService extends CrudServiceInterface<User> {

}