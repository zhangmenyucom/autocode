package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.ArticleService;
import com.ayuan.blog.dao.ArticleDao;
import com.ayuan.blog.domain.Article;
import org.springframework.stereotype.Service;
    
@Service
public class ArticleServiceImpl 
        extends CrudService<Article, ArticleDao> 
        implements ArticleService {

}