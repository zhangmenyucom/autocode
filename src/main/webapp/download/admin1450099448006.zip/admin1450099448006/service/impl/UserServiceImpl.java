package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.UserService;
import com.ayuan.blog.dao.UserDao;
import com.ayuan.blog.domain.User;
import org.springframework.stereotype.Service;
    
@Service
public class UserServiceImpl 
        extends CrudService<User, UserDao> 
        implements UserService {

}