package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.ClassificationService;
import com.ayuan.blog.dao.ClassificationDao;
import com.ayuan.blog.domain.Classification;
import org.springframework.stereotype.Service;
    
@Service
public class ClassificationServiceImpl 
        extends CrudService<Classification, ClassificationDao> 
        implements ClassificationService {

}