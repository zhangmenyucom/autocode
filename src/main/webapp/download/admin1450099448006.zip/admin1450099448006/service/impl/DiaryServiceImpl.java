package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.DiaryService;
import com.ayuan.blog.dao.DiaryDao;
import com.ayuan.blog.domain.Diary;
import org.springframework.stereotype.Service;
    
@Service
public class DiaryServiceImpl 
        extends CrudService<Diary, DiaryDao> 
        implements DiaryService {

}