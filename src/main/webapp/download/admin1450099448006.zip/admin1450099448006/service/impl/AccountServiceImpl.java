package com.ayuan.blog.service.impl;

import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.AccountService;
import com.ayuan.blog.dao.AccountDao;
import com.ayuan.blog.domain.Account;
import org.springframework.stereotype.Service;
    
@Service
public class AccountServiceImpl 
        extends CrudService<Account, AccountDao> 
        implements AccountService {

}