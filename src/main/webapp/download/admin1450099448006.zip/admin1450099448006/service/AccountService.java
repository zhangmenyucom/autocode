package com.ayuan.blog.service;

import com.ayuan.blog.domain.Account;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface AccountService extends CrudServiceInterface<Account> {

}