package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.Diary;

public interface DiaryDao extends BaseDao<Diary> {
}