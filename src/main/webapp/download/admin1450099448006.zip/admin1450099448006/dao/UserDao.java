package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.User;

public interface UserDao extends BaseDao<User> {
}