package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.Account;

public interface AccountDao extends BaseDao<Account> {
}