package com.weimob.o2o.mgr.meiwei.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MeiWeiQueueSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private String meiWeiStoreIdSch;
    private Long customIdSch;
    private String openIdSch;
    private String phoneSch;
    private String meiWeiSerialIdSch;
    private Byte statusSch;
    private String qNameSch;
    private String qAttrSch;
    private String numSch;
    private String noticeSch;
    private String waitTimeSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setMeiWeiStoreIdSch(String meiWeiStoreIdSch){
        this.meiWeiStoreIdSch = meiWeiStoreIdSch;
    }
    
    @ValueField(column = "mei_wei_store_id")
    public String getMeiWeiStoreIdSch(){
        return this.meiWeiStoreIdSch;
    }

    public void setCustomIdSch(Long customIdSch){
        this.customIdSch = customIdSch;
    }
    
    @ValueField(column = "custom_id")
    public Long getCustomIdSch(){
        return this.customIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setPhoneSch(String phoneSch){
        this.phoneSch = phoneSch;
    }
    
    @ValueField(column = "phone")
    public String getPhoneSch(){
        return this.phoneSch;
    }

    public void setMeiWeiSerialIdSch(String meiWeiSerialIdSch){
        this.meiWeiSerialIdSch = meiWeiSerialIdSch;
    }
    
    @ValueField(column = "mei_wei_serial_id")
    public String getMeiWeiSerialIdSch(){
        return this.meiWeiSerialIdSch;
    }

    public void setStatusSch(Byte statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Byte getStatusSch(){
        return this.statusSch;
    }

    public void setQNameSch(String qNameSch){
        this.qNameSch = qNameSch;
    }
    
    @ValueField(column = "q_name")
    public String getQNameSch(){
        return this.qNameSch;
    }

    public void setQAttrSch(String qAttrSch){
        this.qAttrSch = qAttrSch;
    }
    
    @ValueField(column = "q_attr")
    public String getQAttrSch(){
        return this.qAttrSch;
    }

    public void setNumSch(String numSch){
        this.numSch = numSch;
    }
    
    @ValueField(column = "num")
    public String getNumSch(){
        return this.numSch;
    }

    public void setNoticeSch(String noticeSch){
        this.noticeSch = noticeSch;
    }
    
    @ValueField(column = "notice")
    public String getNoticeSch(){
        return this.noticeSch;
    }

    public void setWaitTimeSch(String waitTimeSch){
        this.waitTimeSch = waitTimeSch;
    }
    
    @ValueField(column = "wait_time")
    public String getWaitTimeSch(){
        return this.waitTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}