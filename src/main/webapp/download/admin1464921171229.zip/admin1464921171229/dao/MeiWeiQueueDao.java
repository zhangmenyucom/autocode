package com.weimob.o2o.mgr.meiwei.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.meiwei.domain.MeiWeiQueue;

public interface MeiWeiQueueDao extends BaseDao<MeiWeiQueue> {
}