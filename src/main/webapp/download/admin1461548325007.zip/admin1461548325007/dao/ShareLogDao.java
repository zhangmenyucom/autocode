package com.weimob.o2o.report.other.o2o.share.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.report.other.o2o.share.domain.ShareLog;

public interface ShareLogDao extends BaseDao<ShareLog> {
}