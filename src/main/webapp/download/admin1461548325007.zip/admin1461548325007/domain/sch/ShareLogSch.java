package com.weimob.o2o.report.other.o2o.share.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShareLogSch extends SearchEntity{

    private Long sourceIdSch;
    private Long merchantIdSch;
    private String openIdSch;
    private Long shareSourceIdSch;
    private String sourceSch;
    private Integer typeSch;
    private Date shareTimeSch;

    public void setSourceIdSch(Long sourceIdSch){
        this.sourceIdSch = sourceIdSch;
    }
    
    @ValueField(column = "source_id")
    public Long getSourceIdSch(){
        return this.sourceIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setShareSourceIdSch(Long shareSourceIdSch){
        this.shareSourceIdSch = shareSourceIdSch;
    }
    
    @ValueField(column = "share_source_id")
    public Long getShareSourceIdSch(){
        return this.shareSourceIdSch;
    }

    public void setSourceSch(String sourceSch){
        this.sourceSch = sourceSch;
    }
    
    @ValueField(column = "source")
    public String getSourceSch(){
        return this.sourceSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setShareTimeSch(Date shareTimeSch){
        this.shareTimeSch = shareTimeSch;
    }
    
    @ValueField(column = "share_time")
    public Date getShareTimeSch(){
        return this.shareTimeSch;
    }


}