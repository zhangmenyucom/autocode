package com.weimob.o2o.report.other.o2o.share.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShareLog implements Serializable {
	private Long sourceId;
	private Long merchantId;
	private String openId;
	private Long shareSourceId;
	private String source;
	private Integer type;
	private Date shareTime;
}