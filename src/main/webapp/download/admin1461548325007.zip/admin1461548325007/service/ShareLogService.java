package com.weimob.o2o.report.other.o2o.share.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.report.other.o2o.share.domain.ShareLog;
import com.weimob.o2o.report.other.o2o.share.domain.sch.ShareLogSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShareLogService extends CrudServiceInterface<ShareLog> {

    PageInfo<ShareLog> findPage(ShareLogSch sch);
}