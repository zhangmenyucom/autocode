package shakepage.shakePage.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import shakepage.shakePage.dao.ShakePageDao;
import shakepage.shakePage.pojo.ShakePage;

@Service
public class ShakePageBo extends CrudBo<ShakePage, ShakePageDao> {

}