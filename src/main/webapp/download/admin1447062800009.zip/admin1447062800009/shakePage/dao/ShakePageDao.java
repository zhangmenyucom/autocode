package shakepage.shakePage.dao;

import com.shunwang.business.framework.dao.CrudDao;
import shakepage.shakePage.pojo.ShakePage;

public interface ShakePageDao extends CrudDao<ShakePage> {
}