package shakepage.dao;

import org.durcframework.core.dao.BaseDao;
import shakepage.entity.ShakePage;

public interface ShakePageDao extends BaseDao<ShakePage> {
}