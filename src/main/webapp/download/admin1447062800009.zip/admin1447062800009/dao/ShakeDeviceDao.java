package shakedevice.dao;

import org.durcframework.core.dao.BaseDao;
import shakedevice.entity.ShakeDevice;

public interface ShakeDeviceDao extends BaseDao<ShakeDevice> {
}