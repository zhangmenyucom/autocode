package shakedeviceapply.dao;

import org.durcframework.core.dao.BaseDao;
import shakedeviceapply.entity.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends BaseDao<ShakeDeviceApply> {
}