package shakefocus.dao;

import org.durcframework.core.dao.BaseDao;
import shakefocus.entity.ShakeFocus;

public interface ShakeFocusDao extends BaseDao<ShakeFocus> {
}