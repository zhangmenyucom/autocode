package shakedevicepage.dao;

import org.durcframework.core.dao.BaseDao;
import shakedevicepage.entity.ShakeDevicePage;

public interface ShakeDevicePageDao extends BaseDao<ShakeDevicePage> {
}