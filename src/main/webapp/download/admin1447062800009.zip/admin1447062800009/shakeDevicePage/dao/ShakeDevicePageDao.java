package shakedevicepage.shakeDevicePage.dao;

import com.shunwang.business.framework.dao.CrudDao;
import shakedevicepage.shakeDevicePage.pojo.ShakeDevicePage;

public interface ShakeDevicePageDao extends CrudDao<ShakeDevicePage> {
}