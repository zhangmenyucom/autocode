package shakedevicepage.shakeDevicePage.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import shakedevicepage.shakeDevicePage.dao.ShakeDevicePageDao;
import shakedevicepage.shakeDevicePage.pojo.ShakeDevicePage;

@Service
public class ShakeDevicePageBo extends CrudBo<ShakeDevicePage, ShakeDevicePageDao> {

}