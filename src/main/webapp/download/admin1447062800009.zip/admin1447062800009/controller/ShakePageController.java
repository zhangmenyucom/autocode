package shakepage.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import shakepage.entity.ShakePage;
import shakepage.entity.ShakePageSch;
import shakepage.service.ShakePageService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ShakePageController extends
		CrudController<ShakePage, ShakePageService> {

	@RequestMapping("/addShakePage.do")
	public @ResponseBody
	MessageResult addShakePage(ShakePage entity) {
		return this.save(entity);
	}

	@RequestMapping("/listShakePage.do")
	public @ResponseBody
	GridResult listShakePage(ShakePageSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateShakePage.do")
	public @ResponseBody
	MessageResult updateShakePage(ShakePage entity) {
		return this.update(entity);
	}

	@RequestMapping("/delShakePage.do")
	public @ResponseBody
	MessageResult delShakePage(ShakePage entity) {
		return this.delete(entity);
	}
	
}