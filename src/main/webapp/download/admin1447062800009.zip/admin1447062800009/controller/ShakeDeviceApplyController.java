package shakedeviceapply.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import shakedeviceapply.entity.ShakeDeviceApply;
import shakedeviceapply.entity.ShakeDeviceApplySch;
import shakedeviceapply.service.ShakeDeviceApplyService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class ShakeDeviceApplyController extends
		CrudController<ShakeDeviceApply, ShakeDeviceApplyService> {

	@RequestMapping("/addShakeDeviceApply.do")
	public @ResponseBody
	MessageResult addShakeDeviceApply(ShakeDeviceApply entity) {
		return this.save(entity);
	}

	@RequestMapping("/listShakeDeviceApply.do")
	public @ResponseBody
	GridResult listShakeDeviceApply(ShakeDeviceApplySch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateShakeDeviceApply.do")
	public @ResponseBody
	MessageResult updateShakeDeviceApply(ShakeDeviceApply entity) {
		return this.update(entity);
	}

	@RequestMapping("/delShakeDeviceApply.do")
	public @ResponseBody
	MessageResult delShakeDeviceApply(ShakeDeviceApply entity) {
		return this.delete(entity);
	}
	
}