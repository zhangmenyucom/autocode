package shakepage.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakePageSch extends SearchEntity{

    private Long shakePageIdSch;
    private String pageIdSch;
    private String titleSch;
    private String descriptionSch;
    private String iconUrlSch;
    private String pageUrlSch;
    private String commentSch;
    private Long activtyIdSch;
    private String createTimeSch;
    private String updateTimeSch;

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setPageIdSch(String pageIdSch){
        this.pageIdSch = pageIdSch;
    }
    
    @ValueField(column = "page_id")
    public String getPageIdSch(){
        return this.pageIdSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setDescriptionSch(String descriptionSch){
        this.descriptionSch = descriptionSch;
    }
    
    @ValueField(column = "description")
    public String getDescriptionSch(){
        return this.descriptionSch;
    }

    public void setIconUrlSch(String iconUrlSch){
        this.iconUrlSch = iconUrlSch;
    }
    
    @ValueField(column = "icon_url")
    public String getIconUrlSch(){
        return this.iconUrlSch;
    }

    public void setPageUrlSch(String pageUrlSch){
        this.pageUrlSch = pageUrlSch;
    }
    
    @ValueField(column = "page_url")
    public String getPageUrlSch(){
        return this.pageUrlSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setActivtyIdSch(Long activtyIdSch){
        this.activtyIdSch = activtyIdSch;
    }
    
    @ValueField(column = "activty_id")
    public Long getActivtyIdSch(){
        return this.activtyIdSch;
    }

    public void setCreateTimeSch(String createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public String getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(String updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public String getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}