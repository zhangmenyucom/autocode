package shakedeviceapply.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeDeviceApplySch extends SearchEntity{

    private Long shakeDeviceApplyIdSch;
    private Integer quanttitySch;
    private String applyReasonSch;
    private String commentSch;
    private String poiIdSch;
    private String applyIdSch;
    private Integer auditStatusSch;
    private String auditCommentSch;
    private String applyTimeSch;
    private String auditTimeSch;
    private Long merchantIdSch;
    private String createTimeSch;
    private String updateTimeSch;

    public void setShakeDeviceApplyIdSch(Long shakeDeviceApplyIdSch){
        this.shakeDeviceApplyIdSch = shakeDeviceApplyIdSch;
    }
    
    @ValueField(column = "shake_device_apply_id")
    public Long getShakeDeviceApplyIdSch(){
        return this.shakeDeviceApplyIdSch;
    }

    public void setQuanttitySch(Integer quanttitySch){
        this.quanttitySch = quanttitySch;
    }
    
    @ValueField(column = "quanttity")
    public Integer getQuanttitySch(){
        return this.quanttitySch;
    }

    public void setApplyReasonSch(String applyReasonSch){
        this.applyReasonSch = applyReasonSch;
    }
    
    @ValueField(column = "apply_reason")
    public String getApplyReasonSch(){
        return this.applyReasonSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setPoiIdSch(String poiIdSch){
        this.poiIdSch = poiIdSch;
    }
    
    @ValueField(column = "poi_id")
    public String getPoiIdSch(){
        return this.poiIdSch;
    }

    public void setApplyIdSch(String applyIdSch){
        this.applyIdSch = applyIdSch;
    }
    
    @ValueField(column = "apply_id")
    public String getApplyIdSch(){
        return this.applyIdSch;
    }

    public void setAuditStatusSch(Integer auditStatusSch){
        this.auditStatusSch = auditStatusSch;
    }
    
    @ValueField(column = "audit_status")
    public Integer getAuditStatusSch(){
        return this.auditStatusSch;
    }

    public void setAuditCommentSch(String auditCommentSch){
        this.auditCommentSch = auditCommentSch;
    }
    
    @ValueField(column = "audit_comment")
    public String getAuditCommentSch(){
        return this.auditCommentSch;
    }

    public void setApplyTimeSch(String applyTimeSch){
        this.applyTimeSch = applyTimeSch;
    }
    
    @ValueField(column = "apply_time")
    public String getApplyTimeSch(){
        return this.applyTimeSch;
    }

    public void setAuditTimeSch(String auditTimeSch){
        this.auditTimeSch = auditTimeSch;
    }
    
    @ValueField(column = "audit_time")
    public String getAuditTimeSch(){
        return this.auditTimeSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setCreateTimeSch(String createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public String getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(String updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public String getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}