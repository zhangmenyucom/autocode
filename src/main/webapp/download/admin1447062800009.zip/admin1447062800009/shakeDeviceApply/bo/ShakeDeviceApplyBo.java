package shakedeviceapply.shakeDeviceApply.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import shakedeviceapply.shakeDeviceApply.dao.ShakeDeviceApplyDao;
import shakedeviceapply.shakeDeviceApply.pojo.ShakeDeviceApply;

@Service
public class ShakeDeviceApplyBo extends CrudBo<ShakeDeviceApply, ShakeDeviceApplyDao> {

}