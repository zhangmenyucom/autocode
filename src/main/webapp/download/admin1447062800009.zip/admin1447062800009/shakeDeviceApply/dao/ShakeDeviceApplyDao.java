package shakedeviceapply.shakeDeviceApply.dao;

import com.shunwang.business.framework.dao.CrudDao;
import shakedeviceapply.shakeDeviceApply.pojo.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends CrudDao<ShakeDeviceApply> {
}