package shakedevice.shakeDevice.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import shakedevice.shakeDevice.dao.ShakeDeviceDao;
import shakedevice.shakeDevice.pojo.ShakeDevice;

@Service
public class ShakeDeviceBo extends CrudBo<ShakeDevice, ShakeDeviceDao> {

}