package shakedevice.shakeDevice.dao;

import com.shunwang.business.framework.dao.CrudDao;
import shakedevice.shakeDevice.pojo.ShakeDevice;

public interface ShakeDeviceDao extends CrudDao<ShakeDevice> {
}