package shakefocus.service;

import org.durcframework.core.service.CrudService;
import shakefocus.dao.ShakeFocusDao;
import shakefocus.entity.ShakeFocus;
import org.springframework.stereotype.Service;

@Service
public class ShakeFocusService extends CrudService<ShakeFocus, ShakeFocusDao> {

}