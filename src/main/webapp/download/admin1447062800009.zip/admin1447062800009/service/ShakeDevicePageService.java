package shakedevicepage.service;

import org.durcframework.core.service.CrudService;
import shakedevicepage.dao.ShakeDevicePageDao;
import shakedevicepage.entity.ShakeDevicePage;
import org.springframework.stereotype.Service;

@Service
public class ShakeDevicePageService extends CrudService<ShakeDevicePage, ShakeDevicePageDao> {

}