package shakepage.service;

import org.durcframework.core.service.CrudService;
import shakepage.dao.ShakePageDao;
import shakepage.entity.ShakePage;
import org.springframework.stereotype.Service;

@Service
public class ShakePageService extends CrudService<ShakePage, ShakePageDao> {

}