package shakedevice.service;

import org.durcframework.core.service.CrudService;
import shakedevice.dao.ShakeDeviceDao;
import shakedevice.entity.ShakeDevice;
import org.springframework.stereotype.Service;

@Service
public class ShakeDeviceService extends CrudService<ShakeDevice, ShakeDeviceDao> {

}