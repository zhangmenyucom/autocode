package shakedeviceapply.service;

import org.durcframework.core.service.CrudService;
import shakedeviceapply.dao.ShakeDeviceApplyDao;
import shakedeviceapply.entity.ShakeDeviceApply;
import org.springframework.stereotype.Service;

@Service
public class ShakeDeviceApplyService extends CrudService<ShakeDeviceApply, ShakeDeviceApplyDao> {

}