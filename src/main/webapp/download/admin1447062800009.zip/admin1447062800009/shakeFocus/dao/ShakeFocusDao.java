package shakefocus.shakeFocus.dao;

import com.shunwang.business.framework.dao.CrudDao;
import shakefocus.shakeFocus.pojo.ShakeFocus;

public interface ShakeFocusDao extends CrudDao<ShakeFocus> {
}