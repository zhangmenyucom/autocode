package shakefocus.shakeFocus.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import shakefocus.shakeFocus.dao.ShakeFocusDao;
import shakefocus.shakeFocus.pojo.ShakeFocus;

@Service
public class ShakeFocusBo extends CrudBo<ShakeFocus, ShakeFocusDao> {

}