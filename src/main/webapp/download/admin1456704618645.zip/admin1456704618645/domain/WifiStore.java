package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStore implements Serializable {
	private Long wifiStoreId;
	private Long aid;
	private Long merchantId;
	private Long storeId;
	private Long wifiSupplierId;
	private Integer deviceType;
	private String wechatStoreId;
	private String wechatAppId;
	private String wechatSecretKey;
	private String ssid;
	private Integer type;
	private Integer addedDeviceCount;
	private Integer toBeAddDeviceCount;
	private Date createTime;
	private Date updateTime;
	private Long createAccountId;
	private Long updateAccountId;
}