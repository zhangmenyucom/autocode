package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiStoreDeviceConnectedMacService;
import com.weimob.o2o.mgr.wifi.dao.WifiStoreDeviceConnectedMacDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreDeviceConnectedMac;
import org.springframework.stereotype.Service;
    
@Service
public class WifiStoreDeviceConnectedMacServiceImpl 
        extends CrudService<WifiStoreDeviceConnectedMac, WifiStoreDeviceConnectedMacDao> 
        implements WifiStoreDeviceConnectedMacService {

}