package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStoreDeviceConnectedMacSch extends SearchEntity{

    private Long idSch;
    private Long aidSch;
    private Long storeIdSch;
    private Long wifiStoreDeviceIdSch;
    private String connectedMacSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setWifiStoreDeviceIdSch(Long wifiStoreDeviceIdSch){
        this.wifiStoreDeviceIdSch = wifiStoreDeviceIdSch;
    }
    
    @ValueField(column = "wifi_store_device_id")
    public Long getWifiStoreDeviceIdSch(){
        return this.wifiStoreDeviceIdSch;
    }

    public void setConnectedMacSch(String connectedMacSch){
        this.connectedMacSch = connectedMacSch;
    }
    
    @ValueField(column = "connected_mac")
    public String getConnectedMacSch(){
        return this.connectedMacSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}