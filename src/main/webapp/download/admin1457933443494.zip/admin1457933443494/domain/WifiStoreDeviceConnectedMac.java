package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStoreDeviceConnectedMac implements Serializable {
	private Long id;
	private Long aid;
	private Long storeId;
	private Long wifiStoreDeviceId;
	private String connectedMac;
	private Date createTime;
	private Date updateTime;
}