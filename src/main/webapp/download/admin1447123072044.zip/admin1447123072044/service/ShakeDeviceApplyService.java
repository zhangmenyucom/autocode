package shakedeviceapply.service;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDeviceApplyService extends CrudServiceInterface {

}