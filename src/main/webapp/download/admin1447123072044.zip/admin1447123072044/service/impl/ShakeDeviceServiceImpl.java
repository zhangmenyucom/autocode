package shakedevice.service.impl;

import org.durcframework.core.service.CrudService;
import shakedevice.service.ShakeDeviceService;
import shakedevice.dao.ShakeDeviceDao;
import shakedevice.domain.ShakeDevice;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceServiceImpl extends CrudService<ShakeDevice, ShakeDeviceDao> implements ShakeDeviceService {

}