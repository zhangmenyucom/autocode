package shakepage.service.impl;

import org.durcframework.core.service.CrudService;
import shakepage.service.ShakePageService;
import shakepage.dao.ShakePageDao;
import shakepage.domain.ShakePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakePageServiceImpl extends CrudService<ShakePage, ShakePageDao> implements ShakePageService {

}