package shakepage.service;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakePageService extends CrudServiceInterface {

}