package shakefocus.domain.sch;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeFocusSch extends SearchEntity{

    private Long shakeFucusIdSch;
    private String titleSch;
    private String descriptionSch;
    private String sloganSch;
    private String backgroundUrlSch;
    private Long shakePageIdSch;
    private String createTimeSch;
    private String updateTimeSch;

    public void setShakeFucusIdSch(Long shakeFucusIdSch){
        this.shakeFucusIdSch = shakeFucusIdSch;
    }
    
    @ValueField(column = "shake_fucus_id")
    public Long getShakeFucusIdSch(){
        return this.shakeFucusIdSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setDescriptionSch(String descriptionSch){
        this.descriptionSch = descriptionSch;
    }
    
    @ValueField(column = "description")
    public String getDescriptionSch(){
        return this.descriptionSch;
    }

    public void setSloganSch(String sloganSch){
        this.sloganSch = sloganSch;
    }
    
    @ValueField(column = "slogan")
    public String getSloganSch(){
        return this.sloganSch;
    }

    public void setBackgroundUrlSch(String backgroundUrlSch){
        this.backgroundUrlSch = backgroundUrlSch;
    }
    
    @ValueField(column = "background_url")
    public String getBackgroundUrlSch(){
        return this.backgroundUrlSch;
    }

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setCreateTimeSch(String createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public String getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(String updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public String getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}