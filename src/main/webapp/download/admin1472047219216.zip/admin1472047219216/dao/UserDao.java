package com.example.dao;

import com.example.common.BaseDao;
import com.example.domain.User;

public interface UserDao extends BaseDao<User> {
}