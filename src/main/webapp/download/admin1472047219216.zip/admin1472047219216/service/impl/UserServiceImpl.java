package com.example.service.impl;

import com.example.common.CrudService;
import com.github.pagehelper.PageInfo;
import com.example.service.UserService;
import com.example.dao.UserDao;
import com.example.domain.User;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class UserServiceImpl 
        extends CrudService<User, UserDao> 
        implements UserService {

}