package com.example.service;

import com.example.common.CrudServiceInterface;
import com.github.pagehelper.PageInfo;

import com.example.domain.User;

public interface UserService extends CrudServiceInterface<User> {

}