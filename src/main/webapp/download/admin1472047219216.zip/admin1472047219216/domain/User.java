package com.example.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class User implements Serializable {
	private Integer id;
	private Integer accountId;
	private String userNickname;
	private String userMail;
	private String userLogo;
}