package com.weimob.o2o.mgr.message.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MessageGroupSch extends SearchEntity{

    private Long messageGroupIdSch;
    private Long merchantIdSch;
    private String userConditionsSch;
    private Integer msgTypeSch;
    private Long mediaIdSch;
    private String wxMediaIdSch;
    private String textContentSch;
    private String videoTitleSch;
    private String videoDescriptionSch;
    private String wxcardCardIdSch;
    private String msgIdSch;
    private String msgDataIdSch;
    private String msgStatusSch;
    private Long wxCreateTimeSch;
    private Long totalCountSch;
    private Long filterCountSch;
    private Long sentCountSch;
    private Long errorCountSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long creataUserIdSch;
    private Long updateUserIdSch;

    public void setMessageGroupIdSch(Long messageGroupIdSch){
        this.messageGroupIdSch = messageGroupIdSch;
    }
    
    @ValueField(column = "message_group_id")
    public Long getMessageGroupIdSch(){
        return this.messageGroupIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setUserConditionsSch(String userConditionsSch){
        this.userConditionsSch = userConditionsSch;
    }
    
    @ValueField(column = "user_conditions")
    public String getUserConditionsSch(){
        return this.userConditionsSch;
    }

    public void setMsgTypeSch(Integer msgTypeSch){
        this.msgTypeSch = msgTypeSch;
    }
    
    @ValueField(column = "msg_type")
    public Integer getMsgTypeSch(){
        return this.msgTypeSch;
    }

    public void setMediaIdSch(Long mediaIdSch){
        this.mediaIdSch = mediaIdSch;
    }
    
    @ValueField(column = "media_id")
    public Long getMediaIdSch(){
        return this.mediaIdSch;
    }

    public void setWxMediaIdSch(String wxMediaIdSch){
        this.wxMediaIdSch = wxMediaIdSch;
    }
    
    @ValueField(column = "wx_media_id")
    public String getWxMediaIdSch(){
        return this.wxMediaIdSch;
    }

    public void setTextContentSch(String textContentSch){
        this.textContentSch = textContentSch;
    }
    
    @ValueField(column = "text_content")
    public String getTextContentSch(){
        return this.textContentSch;
    }

    public void setVideoTitleSch(String videoTitleSch){
        this.videoTitleSch = videoTitleSch;
    }
    
    @ValueField(column = "video_title")
    public String getVideoTitleSch(){
        return this.videoTitleSch;
    }

    public void setVideoDescriptionSch(String videoDescriptionSch){
        this.videoDescriptionSch = videoDescriptionSch;
    }
    
    @ValueField(column = "video_description")
    public String getVideoDescriptionSch(){
        return this.videoDescriptionSch;
    }

    public void setWxcardCardIdSch(String wxcardCardIdSch){
        this.wxcardCardIdSch = wxcardCardIdSch;
    }
    
    @ValueField(column = "wxcard_card_id")
    public String getWxcardCardIdSch(){
        return this.wxcardCardIdSch;
    }

    public void setMsgIdSch(String msgIdSch){
        this.msgIdSch = msgIdSch;
    }
    
    @ValueField(column = "msg_id")
    public String getMsgIdSch(){
        return this.msgIdSch;
    }

    public void setMsgDataIdSch(String msgDataIdSch){
        this.msgDataIdSch = msgDataIdSch;
    }
    
    @ValueField(column = "msg_data_id")
    public String getMsgDataIdSch(){
        return this.msgDataIdSch;
    }

    public void setMsgStatusSch(String msgStatusSch){
        this.msgStatusSch = msgStatusSch;
    }
    
    @ValueField(column = "msg_status")
    public String getMsgStatusSch(){
        return this.msgStatusSch;
    }

    public void setWxCreateTimeSch(Long wxCreateTimeSch){
        this.wxCreateTimeSch = wxCreateTimeSch;
    }
    
    @ValueField(column = "wx_create_time")
    public Long getWxCreateTimeSch(){
        return this.wxCreateTimeSch;
    }

    public void setTotalCountSch(Long totalCountSch){
        this.totalCountSch = totalCountSch;
    }
    
    @ValueField(column = "total_count")
    public Long getTotalCountSch(){
        return this.totalCountSch;
    }

    public void setFilterCountSch(Long filterCountSch){
        this.filterCountSch = filterCountSch;
    }
    
    @ValueField(column = "filter_count")
    public Long getFilterCountSch(){
        return this.filterCountSch;
    }

    public void setSentCountSch(Long sentCountSch){
        this.sentCountSch = sentCountSch;
    }
    
    @ValueField(column = "sent_count")
    public Long getSentCountSch(){
        return this.sentCountSch;
    }

    public void setErrorCountSch(Long errorCountSch){
        this.errorCountSch = errorCountSch;
    }
    
    @ValueField(column = "error_count")
    public Long getErrorCountSch(){
        return this.errorCountSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreataUserIdSch(Long creataUserIdSch){
        this.creataUserIdSch = creataUserIdSch;
    }
    
    @ValueField(column = "creata_user_id")
    public Long getCreataUserIdSch(){
        return this.creataUserIdSch;
    }

    public void setUpdateUserIdSch(Long updateUserIdSch){
        this.updateUserIdSch = updateUserIdSch;
    }
    
    @ValueField(column = "update_user_id")
    public Long getUpdateUserIdSch(){
        return this.updateUserIdSch;
    }


}