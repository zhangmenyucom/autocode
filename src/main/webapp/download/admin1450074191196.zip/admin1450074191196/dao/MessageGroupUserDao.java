package com.weimob.o2o.mgr.message.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.message.domain.MessageGroupUser;

public interface MessageGroupUserDao extends BaseDao<MessageGroupUser> {
}