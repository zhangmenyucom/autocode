package com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.shake.service.ShakeDeviceApplyService;
import com.weimob.o2o.mgr.shake.dao.ShakeDeviceApplyDao;
import com.weimob.o2o.mgr.shake.domain.ShakeDeviceApply;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceApplyServiceImpl 
        extends CrudService<ShakeDeviceApply, ShakeDeviceApplyDao> 
        implements ShakeDeviceApplyService {

}