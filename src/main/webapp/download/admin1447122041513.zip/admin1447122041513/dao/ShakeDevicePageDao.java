package com.weimob.o2o.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.entity.ShakeDevicePage;

public interface ShakeDevicePageDao extends BaseDao<ShakeDevicePage> {
}