package com.weimob.o2o.mgr.domain;

public class ShakeDevicePage {
	private long shakeDevicePageId;
	private long shakeDeviceId;
	private long shakePageId;
	private String createTime;
	private String updateTime;

	public void setShakeDevicePageId(long shakeDevicePageId){
		this.shakeDevicePageId = shakeDevicePageId;
	}

	public long getShakeDevicePageId(){
		return this.shakeDevicePageId;
	}

	public void setShakeDeviceId(long shakeDeviceId){
		this.shakeDeviceId = shakeDeviceId;
	}

	public long getShakeDeviceId(){
		return this.shakeDeviceId;
	}

	public void setShakePageId(long shakePageId){
		this.shakePageId = shakePageId;
	}

	public long getShakePageId(){
		return this.shakePageId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}