import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.service.ShakePageService;
import com.weimob.o2o.mgr.dao.ShakePageDao;
import com.weimob.o2o.mgr.domain.ShakePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakePageServiceImpl extends CrudService<ShakePage, ShakePageDao> implements ShakePageService {

}