import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.service.ShakeDeviceApplyService;
import com.weimob.o2o.mgr.dao.ShakeDeviceApplyDao;
import com.weimob.o2o.mgr.domain.ShakeDeviceApply;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceApplyServiceImpl extends CrudService<ShakeDeviceApply, ShakeDeviceApplyDao> implements ShakeDeviceApplyService {

}