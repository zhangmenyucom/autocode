package com.weimob.o2o.mgr.service;

public interface ShakeFocusService extends CrudServiceInterface {

}