package com.weimob.o2o.mgr.business.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.business.domain.BusinessInfo;

public interface BusinessInfoDao extends BaseDao<BusinessInfo> {
}