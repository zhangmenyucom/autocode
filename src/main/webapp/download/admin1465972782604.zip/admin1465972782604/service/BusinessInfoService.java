package com.weimob.o2o.mgr.business.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.business.domain.BusinessInfo;
import com.weimob.o2o.mgr.business.domain.sch.BusinessInfoSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface BusinessInfoService extends CrudServiceInterface<BusinessInfo> {

    PageInfo<BusinessInfo> findPage(BusinessInfoSch sch);
}