package com.weimob.o2o.mgr.shake.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.shake.domain.ShakeDevicePage;

public interface ShakeDevicePageDao extends BaseDao<ShakeDevicePage> {
}