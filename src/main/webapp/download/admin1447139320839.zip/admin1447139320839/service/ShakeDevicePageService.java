package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.shake.domain.ShakeDevicePage;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDevicePageService extends CrudServiceInterface<ShakeDevicePage> {

}