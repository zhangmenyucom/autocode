package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.shake.domain.ShakePage;
import com.weimob.o2o.mgr.shake.dao.ShakePageDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakePageService extends CrudServiceInterface<ShakePage, ShakePageDao> {

}