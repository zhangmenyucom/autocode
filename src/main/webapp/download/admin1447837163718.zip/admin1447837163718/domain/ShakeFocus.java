package com.weimob.common.wechat.shake.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeFocus implements Serializable {
	private Long shakeFocusId;
	private Long merchantId;
	private String title;
	private String description;
	private String slogan;
	private String backgroundUrl;
	private Long shakePageId;
	private Date createTime;
	private Date updateTime;
}