package com.pnote.mgr.note.service;

import com.github.pagehelper.PageInfo;

import com.pnote.mgr.note.domain.NoteBook;
import com.pnote.mgr.note.domain.sch.NoteBookSch;

import com.pnote.mgr.common.service.CrudServiceInterface;

public interface NoteBookService extends CrudServiceInterface<NoteBook> {

    PageInfo<NoteBook> findPage(NoteBookSch sch);
}