package com.pnote.mgr.note.service;

import com.github.pagehelper.PageInfo;

import com.pnote.mgr.note.domain.NoteArticle;
import com.pnote.mgr.note.domain.sch.NoteArticleSch;

import com.pnote.mgr.common.service.CrudServiceInterface;

public interface NoteArticleService extends CrudServiceInterface<NoteArticle> {

    PageInfo<NoteArticle> findPage(NoteArticleSch sch);
}