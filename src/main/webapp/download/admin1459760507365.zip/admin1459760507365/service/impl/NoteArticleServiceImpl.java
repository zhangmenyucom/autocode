package com.pnote.mgr.note.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.pnote.mgr.note.service.NoteArticleService;
import com.pnote.mgr.note.dao.NoteArticleDao;
import com.pnote.mgr.note.domain.NoteArticle;
import com.pnote.mgr.note.domain.sch.NoteArticleSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class NoteArticleServiceImpl 
        extends CrudService<NoteArticle, NoteArticleDao> 
        implements NoteArticleService {

    @Override
    public PageInfo<NoteArticle> findPage(NoteArticleSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<NoteArticle> list = this.getDao().find(query);

        PageInfo<NoteArticle> page = new PageInfo<>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}