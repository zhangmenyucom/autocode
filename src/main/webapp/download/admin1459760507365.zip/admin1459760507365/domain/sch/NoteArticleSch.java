package com.pnote.mgr.note.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class NoteArticleSch extends SearchEntity{

    private Long articleIdSch;
    private Long bookIdSch;
    private Long directoryIdSch;
    private String articleNameSch;
    private String contentSch;
    private Byte deleteFlagSch;
    private Long creatorIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setArticleIdSch(Long articleIdSch){
        this.articleIdSch = articleIdSch;
    }
    
    @ValueField(column = "article_id")
    public Long getArticleIdSch(){
        return this.articleIdSch;
    }

    public void setBookIdSch(Long bookIdSch){
        this.bookIdSch = bookIdSch;
    }
    
    @ValueField(column = "book_id")
    public Long getBookIdSch(){
        return this.bookIdSch;
    }

    public void setDirectoryIdSch(Long directoryIdSch){
        this.directoryIdSch = directoryIdSch;
    }
    
    @ValueField(column = "directory_id")
    public Long getDirectoryIdSch(){
        return this.directoryIdSch;
    }

    public void setArticleNameSch(String articleNameSch){
        this.articleNameSch = articleNameSch;
    }
    
    @ValueField(column = "article_name")
    public String getArticleNameSch(){
        return this.articleNameSch;
    }

    public void setContentSch(String contentSch){
        this.contentSch = contentSch;
    }
    
    @ValueField(column = "content")
    public String getContentSch(){
        return this.contentSch;
    }

    public void setDeleteFlagSch(Byte deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Byte getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setCreatorIdSch(Long creatorIdSch){
        this.creatorIdSch = creatorIdSch;
    }
    
    @ValueField(column = "creator_id")
    public Long getCreatorIdSch(){
        return this.creatorIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}