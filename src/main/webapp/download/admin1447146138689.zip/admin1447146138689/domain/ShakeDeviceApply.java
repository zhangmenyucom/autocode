package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeDeviceApply implements Serializable {
	private Long shakeDeviceApplyId;
	private Integer quanttity;
	private String applyReason;
	private String comment;
	private String poiId;
	private String applyId;
	private Integer auditStatus;
	private String auditComment;
	private String applyTime;
	private String auditTime;
	private Long merchantId;
	private String createTime;
	private String updateTime;
}