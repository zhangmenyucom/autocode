package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeDevice implements Serializable {
	private Long shakeDeviceId;
	private String applyId;
	private String uuid;
	private String major;
	private String minor;
	private String comment;
	private String wxPoiId;
	private Integer status;
	private Long shakeDeviceApplyId;
	private Long merchantId;
	private String poiId;
	private String createTime;
	private String updateTime;
}