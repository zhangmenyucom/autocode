package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeDevicePage implements Serializable {
	private Long shakeDevicePageId;
	private Long shakeDeviceId;
	private Long shakePageId;
	private String createTime;
	private String updateTime;
}