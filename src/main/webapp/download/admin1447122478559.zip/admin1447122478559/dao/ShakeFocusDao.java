package com.weimob.o2o.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.domain.ShakeFocus;

public interface ShakeFocusDao extends BaseDao<ShakeFocus> {
}