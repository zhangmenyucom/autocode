package com.weimob.o2o.mgr.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.service.ShakeDevicePageService;
import com.weimob.o2o.mgr.dao.ShakeDevicePageDao;
import com.weimob.o2o.mgr.domain.ShakeDevicePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDevicePageServiceImpl extends CrudService<ShakeDevicePage, ShakeDevicePageDao> implements ShakeDevicePageService {

}