package com.weimob.o2o.mgr.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.service.ShakeDeviceService;
import com.weimob.o2o.mgr.dao.ShakeDeviceDao;
import com.weimob.o2o.mgr.domain.ShakeDevice;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceServiceImpl extends CrudService<ShakeDevice, ShakeDeviceDao> implements ShakeDeviceService {

}