package com.weimob.o2o.mgr.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.service.ShakeFocusService;
import com.weimob.o2o.mgr.dao.ShakeFocusDao;
import com.weimob.o2o.mgr.domain.ShakeFocus;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeFocusServiceImpl extends CrudService<ShakeFocus, ShakeFocusDao> implements ShakeFocusService {

}