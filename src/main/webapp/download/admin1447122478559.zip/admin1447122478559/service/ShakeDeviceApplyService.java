package com.weimob.o2o.mgr.service;

public interface ShakeDeviceApplyService extends CrudServiceInterface {

}