package com.weimob.o2o.mgr.service;

public interface ShakePageService extends CrudServiceInterface {

}