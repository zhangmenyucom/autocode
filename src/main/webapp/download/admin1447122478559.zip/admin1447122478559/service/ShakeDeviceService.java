package com.weimob.o2o.mgr.service;

public interface ShakeDeviceService extends CrudServiceInterface {

}