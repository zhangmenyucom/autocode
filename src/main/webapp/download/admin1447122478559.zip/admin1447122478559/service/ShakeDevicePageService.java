package com.weimob.o2o.mgr.service;

public interface ShakeDevicePageService extends CrudServiceInterface {

}