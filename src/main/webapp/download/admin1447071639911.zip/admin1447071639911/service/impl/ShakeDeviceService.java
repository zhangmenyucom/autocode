package shakedevice.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import shakedevice.domain.ShakeDevice;
import shakedevice.service.ShakeDeviceService;
import shakedevice.dao.ShakeDeviceMapper;

@Service
public class ShakeDeviceServiceImpl implements ShakeDeviceService  {

    @Autowired
    private ShakeDeviceMapper shakeDeviceMapper;

    @Override
    int deleteByPrimaryKey(long shakeDeviceId){
        return shakeDeviceMapper.deleteByPrimaryKey(shakeDeviceId);
    }

    @Override
    int insert(ShakeDevice record){
        return shakeDeviceMapper.insert(record);
    }

    @Override
    int insertSelective(ShakeDevice record){
        return shakeDeviceMapper.insertSelective(record);
    }

    @Override
    ShakeDevice selectByPrimaryKey(long shakeDeviceId){
        return shakeDeviceMapper.selectByPrimaryKey(shakeDeviceId);
    }

    @Override
    int updateByPrimaryKeySelective(ShakeDevice record){
        return shakeDeviceMapper.updateByPrimaryKeySelective(record);
    }

    @Override
    int updateByPrimaryKey(ShakeDevice record){
        return shakeDeviceMapper.updateByPrimaryKey(record);
    }
}