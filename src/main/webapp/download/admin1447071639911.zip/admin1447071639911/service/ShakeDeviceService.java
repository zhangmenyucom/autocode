package shakedevice.service;

import shakedevice.domain.ShakeDevice;

public interface ShakeDeviceService {
    int deleteByPrimaryKey(long shakeDeviceId);

    int insert(ShakeDevice record);

    int insertSelective(ShakeDevice record);

    ShakeDevice selectByPrimaryKey(long shakeDeviceId);

    int updateByPrimaryKeySelective(ShakeDevice record);

    int updateByPrimaryKey(ShakeDevice record);
}