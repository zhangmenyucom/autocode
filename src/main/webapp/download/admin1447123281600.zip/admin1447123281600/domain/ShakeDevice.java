package com.weimob.o2o.mgr.shake.domain;

public class ShakeDevice {
	private long shakeDeviceId;
	private String applyId;
	private String uuid;
	private String major;
	private String minor;
	private String comment;
	private String wxPoiId;
	private int status;
	private long shakeDeviceApplyId;
	private long merchantId;
	private String poiId;
	private String createTime;
	private String updateTime;

	public void setShakeDeviceId(long shakeDeviceId){
		this.shakeDeviceId = shakeDeviceId;
	}

	public long getShakeDeviceId(){
		return this.shakeDeviceId;
	}

	public void setApplyId(String applyId){
		this.applyId = applyId;
	}

	public String getApplyId(){
		return this.applyId;
	}

	public void setUuid(String uuid){
		this.uuid = uuid;
	}

	public String getUuid(){
		return this.uuid;
	}

	public void setMajor(String major){
		this.major = major;
	}

	public String getMajor(){
		return this.major;
	}

	public void setMinor(String minor){
		this.minor = minor;
	}

	public String getMinor(){
		return this.minor;
	}

	public void setComment(String comment){
		this.comment = comment;
	}

	public String getComment(){
		return this.comment;
	}

	public void setWxPoiId(String wxPoiId){
		this.wxPoiId = wxPoiId;
	}

	public String getWxPoiId(){
		return this.wxPoiId;
	}

	public void setStatus(int status){
		this.status = status;
	}

	public int getStatus(){
		return this.status;
	}

	public void setShakeDeviceApplyId(long shakeDeviceApplyId){
		this.shakeDeviceApplyId = shakeDeviceApplyId;
	}

	public long getShakeDeviceApplyId(){
		return this.shakeDeviceApplyId;
	}

	public void setMerchantId(long merchantId){
		this.merchantId = merchantId;
	}

	public long getMerchantId(){
		return this.merchantId;
	}

	public void setPoiId(String poiId){
		this.poiId = poiId;
	}

	public String getPoiId(){
		return this.poiId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}