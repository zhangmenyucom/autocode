package com.weimob.o2o.mgr.message.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MessageGroupUserSch extends SearchEntity{

    private Long messageGroupUserIdSch;
    private Long merchantIdSch;
    private Long customerIdSch;
    private Long messageGroupIdSch;
    private String openIdSch;
    private Date monthSch;
    private Integer statusSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setMessageGroupUserIdSch(Long messageGroupUserIdSch){
        this.messageGroupUserIdSch = messageGroupUserIdSch;
    }
    
    @ValueField(column = "message_group_user_id")
    public Long getMessageGroupUserIdSch(){
        return this.messageGroupUserIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setCustomerIdSch(Long customerIdSch){
        this.customerIdSch = customerIdSch;
    }
    
    @ValueField(column = "customer_id")
    public Long getCustomerIdSch(){
        return this.customerIdSch;
    }

    public void setMessageGroupIdSch(Long messageGroupIdSch){
        this.messageGroupIdSch = messageGroupIdSch;
    }
    
    @ValueField(column = "message_group_id")
    public Long getMessageGroupIdSch(){
        return this.messageGroupIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setMonthSch(Date monthSch){
        this.monthSch = monthSch;
    }
    
    @ValueField(column = "month")
    public Date getMonthSch(){
        return this.monthSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "createTime")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "updateTime")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}