package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WxUserSch extends SearchEntity{

    private Long wxUserIdSch;
    private String openIdSch;
    private String nicknameSch;
    private Date updateTimeSch;
    private Integer subscribeSch;
    private String openidSch;
    private Integer sexSch;
    private String languageSch;
    private String citySch;
    private String provinceSch;
    private String countrySch;
    private String headImgUrlSch;
    private Long subscribeTimeSch;
    private String unionIdSch;
    private String remarkSch;
    private Integer groupIdSch;

    public void setWxUserIdSch(Long wxUserIdSch){
        this.wxUserIdSch = wxUserIdSch;
    }
    
    @ValueField(column = "wx_user_id")
    public Long getWxUserIdSch(){
        return this.wxUserIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setNicknameSch(String nicknameSch){
        this.nicknameSch = nicknameSch;
    }
    
    @ValueField(column = "nickname")
    public String getNicknameSch(){
        return this.nicknameSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setSubscribeSch(Integer subscribeSch){
        this.subscribeSch = subscribeSch;
    }
    
    @ValueField(column = "subscribe")
    public Integer getSubscribeSch(){
        return this.subscribeSch;
    }

    public void setOpenidSch(String openidSch){
        this.openidSch = openidSch;
    }
    
    @ValueField(column = "openid")
    public String getOpenidSch(){
        return this.openidSch;
    }

    public void setSexSch(Integer sexSch){
        this.sexSch = sexSch;
    }
    
    @ValueField(column = "sex")
    public Integer getSexSch(){
        return this.sexSch;
    }

    public void setLanguageSch(String languageSch){
        this.languageSch = languageSch;
    }
    
    @ValueField(column = "language")
    public String getLanguageSch(){
        return this.languageSch;
    }

    public void setCitySch(String citySch){
        this.citySch = citySch;
    }
    
    @ValueField(column = "city")
    public String getCitySch(){
        return this.citySch;
    }

    public void setProvinceSch(String provinceSch){
        this.provinceSch = provinceSch;
    }
    
    @ValueField(column = "province")
    public String getProvinceSch(){
        return this.provinceSch;
    }

    public void setCountrySch(String countrySch){
        this.countrySch = countrySch;
    }
    
    @ValueField(column = "country")
    public String getCountrySch(){
        return this.countrySch;
    }

    public void setHeadImgUrlSch(String headImgUrlSch){
        this.headImgUrlSch = headImgUrlSch;
    }
    
    @ValueField(column = "headImgUrl")
    public String getHeadImgUrlSch(){
        return this.headImgUrlSch;
    }

    public void setSubscribeTimeSch(Long subscribeTimeSch){
        this.subscribeTimeSch = subscribeTimeSch;
    }
    
    @ValueField(column = "subscribe_time")
    public Long getSubscribeTimeSch(){
        return this.subscribeTimeSch;
    }

    public void setUnionIdSch(String unionIdSch){
        this.unionIdSch = unionIdSch;
    }
    
    @ValueField(column = "unionId")
    public String getUnionIdSch(){
        return this.unionIdSch;
    }

    public void setRemarkSch(String remarkSch){
        this.remarkSch = remarkSch;
    }
    
    @ValueField(column = "remark")
    public String getRemarkSch(){
        return this.remarkSch;
    }

    public void setGroupIdSch(Integer groupIdSch){
        this.groupIdSch = groupIdSch;
    }
    
    @ValueField(column = "groupId")
    public Integer getGroupIdSch(){
        return this.groupIdSch;
    }


}