package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.shake.domain.ShakeAnalysisPage;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeAnalysisPageService extends CrudServiceInterface<ShakeAnalysisPage> {

}