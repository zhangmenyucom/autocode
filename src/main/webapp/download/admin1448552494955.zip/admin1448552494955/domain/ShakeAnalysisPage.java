package com.weimob.o2o.mgr.shake.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class ShakeAnalysisPage implements Serializable {
	private Long shakeAnalysisPage;
	private Long shakePageId;
	private String pageId;
	private Long clickPv;
	private Long clickUv;
	private Long shakePv;
	private Long shakeUv;
	private Date createTime;
	private Date updateTime;
}