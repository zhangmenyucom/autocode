package com.weimob.o2o.mgr.shake.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakeAnalysisPageSch extends SearchEntity{

    private Long shakeAnalysisPageSch;
    private Long shakePageIdSch;
    private String pageIdSch;
    private Long clickPvSch;
    private Long clickUvSch;
    private Long shakePvSch;
    private Long shakeUvSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setShakeAnalysisPageSch(Long shakeAnalysisPageSch){
        this.shakeAnalysisPageSch = shakeAnalysisPageSch;
    }
    
    @ValueField(column = "shake_analysis_page")
    public Long getShakeAnalysisPageSch(){
        return this.shakeAnalysisPageSch;
    }

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setPageIdSch(String pageIdSch){
        this.pageIdSch = pageIdSch;
    }
    
    @ValueField(column = "page_id")
    public String getPageIdSch(){
        return this.pageIdSch;
    }

    public void setClickPvSch(Long clickPvSch){
        this.clickPvSch = clickPvSch;
    }
    
    @ValueField(column = "click_pv")
    public Long getClickPvSch(){
        return this.clickPvSch;
    }

    public void setClickUvSch(Long clickUvSch){
        this.clickUvSch = clickUvSch;
    }
    
    @ValueField(column = "click_uv")
    public Long getClickUvSch(){
        return this.clickUvSch;
    }

    public void setShakePvSch(Long shakePvSch){
        this.shakePvSch = shakePvSch;
    }
    
    @ValueField(column = "shake_pv")
    public Long getShakePvSch(){
        return this.shakePvSch;
    }

    public void setShakeUvSch(Long shakeUvSch){
        this.shakeUvSch = shakeUvSch;
    }
    
    @ValueField(column = "shake_uv")
    public Long getShakeUvSch(){
        return this.shakeUvSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}