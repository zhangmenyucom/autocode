package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDeviceService extends CrudServiceInterface {

}