package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WxUser implements Serializable {
	private Long wxUserId;
	private String nickname;
	private Date updateTime;
	private Integer subscribe;
	private String openid;
	private Integer sex;
	private String language;
	private String city;
	private String province;
	private String country;
	private String headImgUrl;
	private Long subscribeTime;
	private String unionId;
	private String remark;
	private Integer groupId;
}