package com.example.dao;

import org.durcframework.core.dao.BaseDao;
import com.example.domain.Activity;

public interface ActivityDao extends BaseDao<Activity> {
}