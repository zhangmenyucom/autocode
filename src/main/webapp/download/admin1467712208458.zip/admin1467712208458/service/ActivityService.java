package com.example.service;

import com.github.pagehelper.PageInfo;

import com.example.domain.Activity;
import com.example.domain.sch.ActivitySch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ActivityService extends CrudServiceInterface<Activity> {

    PageInfo<Activity> findPage(ActivitySch sch);
}