package com.example.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Activity implements Serializable {
	private Long id;
	private String name;
	private Date startDate;
	private Date endDate;
	private String qrCode;
	private Long merchantId;
	private Integer activityType;
	private String channel;
	private Integer contentType;
	private String activityUrl;
	private Integer status;
	private Integer visitCount;
	private Integer participantCount;
	private Integer needFollow;
	private Date createTime;
	private Date updateTime;
	private Integer isBeUsed;
	private String activityDetail;
}