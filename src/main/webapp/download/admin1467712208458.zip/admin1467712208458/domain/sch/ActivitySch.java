package com.example.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ActivitySch extends SearchEntity{

    private Long idSch;
    private String nameSch;
    private Date startDateSch;
    private Date endDateSch;
    private String qrCodeSch;
    private Long merchantIdSch;
    private Integer activityTypeSch;
    private String channelSch;
    private Integer contentTypeSch;
    private String activityUrlSch;
    private Integer statusSch;
    private Integer visitCountSch;
    private Integer participantCountSch;
    private Integer needFollowSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Integer isBeUsedSch;
    private String activityDetailSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setNameSch(String nameSch){
        this.nameSch = nameSch;
    }
    
    @ValueField(column = "name")
    public String getNameSch(){
        return this.nameSch;
    }

    public void setStartDateSch(Date startDateSch){
        this.startDateSch = startDateSch;
    }
    
    @ValueField(column = "start_date")
    public Date getStartDateSch(){
        return this.startDateSch;
    }

    public void setEndDateSch(Date endDateSch){
        this.endDateSch = endDateSch;
    }
    
    @ValueField(column = "end_date")
    public Date getEndDateSch(){
        return this.endDateSch;
    }

    public void setQrCodeSch(String qrCodeSch){
        this.qrCodeSch = qrCodeSch;
    }
    
    @ValueField(column = "qr_code")
    public String getQrCodeSch(){
        return this.qrCodeSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_Id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setActivityTypeSch(Integer activityTypeSch){
        this.activityTypeSch = activityTypeSch;
    }
    
    @ValueField(column = "activity_type")
    public Integer getActivityTypeSch(){
        return this.activityTypeSch;
    }

    public void setChannelSch(String channelSch){
        this.channelSch = channelSch;
    }
    
    @ValueField(column = "channel")
    public String getChannelSch(){
        return this.channelSch;
    }

    public void setContentTypeSch(Integer contentTypeSch){
        this.contentTypeSch = contentTypeSch;
    }
    
    @ValueField(column = "content_type")
    public Integer getContentTypeSch(){
        return this.contentTypeSch;
    }

    public void setActivityUrlSch(String activityUrlSch){
        this.activityUrlSch = activityUrlSch;
    }
    
    @ValueField(column = "activity_url")
    public String getActivityUrlSch(){
        return this.activityUrlSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setVisitCountSch(Integer visitCountSch){
        this.visitCountSch = visitCountSch;
    }
    
    @ValueField(column = "visit_count")
    public Integer getVisitCountSch(){
        return this.visitCountSch;
    }

    public void setParticipantCountSch(Integer participantCountSch){
        this.participantCountSch = participantCountSch;
    }
    
    @ValueField(column = "participant_count")
    public Integer getParticipantCountSch(){
        return this.participantCountSch;
    }

    public void setNeedFollowSch(Integer needFollowSch){
        this.needFollowSch = needFollowSch;
    }
    
    @ValueField(column = "need_follow")
    public Integer getNeedFollowSch(){
        return this.needFollowSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setIsBeUsedSch(Integer isBeUsedSch){
        this.isBeUsedSch = isBeUsedSch;
    }
    
    @ValueField(column = "is_be_used")
    public Integer getIsBeUsedSch(){
        return this.isBeUsedSch;
    }

    public void setActivityDetailSch(String activityDetailSch){
        this.activityDetailSch = activityDetailSch;
    }
    
    @ValueField(column = "activity_detail")
    public String getActivityDetailSch(){
        return this.activityDetailSch;
    }


}