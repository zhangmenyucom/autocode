package com.pnote.mgr.account.service.impl;

import org.durcframework.core.service.CrudService;
import com.pnote.mgr.account.service.AccountService;
import com.pnote.mgr.account.dao.AccountDao;
import com.pnote.mgr.account.domain.Account;
import org.springframework.stereotype.Service;
    
@Service
public class AccountServiceImpl 
        extends CrudService<Account, AccountDao> 
        implements AccountService {

}