package com.pnote.mgr.account.service;

import com.pnote.mgr.account.domain.Account;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface AccountService extends CrudServiceInterface<Account> {

}