package com.pnote.mgr.account.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Account implements Serializable {
	private Long id;
	private String account;
	private String password;
	private String name;
	private String tel;
	private String mail;
	private Date createTime;
	private Date updateTime;
}