package com.pnote.mgr.account.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class AccountSch extends SearchEntity{

    private Long idSch;
    private String accountSch;
    private String passwordSch;
    private String nameSch;
    private String telSch;
    private String mailSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setAccountSch(String accountSch){
        this.accountSch = accountSch;
    }
    
    @ValueField(column = "account")
    public String getAccountSch(){
        return this.accountSch;
    }

    public void setPasswordSch(String passwordSch){
        this.passwordSch = passwordSch;
    }
    
    @ValueField(column = "password")
    public String getPasswordSch(){
        return this.passwordSch;
    }

    public void setNameSch(String nameSch){
        this.nameSch = nameSch;
    }
    
    @ValueField(column = "name")
    public String getNameSch(){
        return this.nameSch;
    }

    public void setTelSch(String telSch){
        this.telSch = telSch;
    }
    
    @ValueField(column = "tel")
    public String getTelSch(){
        return this.telSch;
    }

    public void setMailSch(String mailSch){
        this.mailSch = mailSch;
    }
    
    @ValueField(column = "mail")
    public String getMailSch(){
        return this.mailSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}