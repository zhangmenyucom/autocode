package com.pnote.mgr.account.dao;

import org.durcframework.core.dao.BaseDao;
import com.pnote.mgr.account.domain.Account;

public interface AccountDao extends BaseDao<Account> {
}