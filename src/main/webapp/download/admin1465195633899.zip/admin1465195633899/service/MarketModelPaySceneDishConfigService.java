package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketModelPaySceneDishConfig;
import com.weimob.o2o.activity.mgr.domain.sch.MarketModelPaySceneDishConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketModelPaySceneDishConfigService extends CrudServiceInterface<MarketModelPaySceneDishConfig> {

    PageInfo<MarketModelPaySceneDishConfig> findPage(MarketModelPaySceneDishConfigSch sch);
}