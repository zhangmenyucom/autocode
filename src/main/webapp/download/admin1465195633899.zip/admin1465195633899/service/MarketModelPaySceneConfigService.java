package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketModelPaySceneConfig;
import com.weimob.o2o.activity.mgr.domain.sch.MarketModelPaySceneConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketModelPaySceneConfigService extends CrudServiceInterface<MarketModelPaySceneConfig> {

    PageInfo<MarketModelPaySceneConfig> findPage(MarketModelPaySceneConfigSch sch);
}