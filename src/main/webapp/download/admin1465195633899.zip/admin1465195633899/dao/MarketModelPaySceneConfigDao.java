package com.weimob.o2o.activity.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.activity.mgr.domain.MarketModelPaySceneConfig;

public interface MarketModelPaySceneConfigDao extends BaseDao<MarketModelPaySceneConfig> {
}