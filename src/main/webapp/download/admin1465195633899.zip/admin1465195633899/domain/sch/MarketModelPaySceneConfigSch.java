package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MarketModelPaySceneConfigSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long activityIdSch;
    private Integer activityTypeSch;
    private Long storeIdSch;
    private Byte paySceneSch;
    private Byte dishRangeTypeSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setActivityIdSch(Long activityIdSch){
        this.activityIdSch = activityIdSch;
    }
    
    @ValueField(column = "activity_id")
    public Long getActivityIdSch(){
        return this.activityIdSch;
    }

    public void setActivityTypeSch(Integer activityTypeSch){
        this.activityTypeSch = activityTypeSch;
    }
    
    @ValueField(column = "activity_type")
    public Integer getActivityTypeSch(){
        return this.activityTypeSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setPaySceneSch(Byte paySceneSch){
        this.paySceneSch = paySceneSch;
    }
    
    @ValueField(column = "pay_scene")
    public Byte getPaySceneSch(){
        return this.paySceneSch;
    }

    public void setDishRangeTypeSch(Byte dishRangeTypeSch){
        this.dishRangeTypeSch = dishRangeTypeSch;
    }
    
    @ValueField(column = "dish_range_type")
    public Byte getDishRangeTypeSch(){
        return this.dishRangeTypeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}