package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDeviceApplyService<Entity, Dao extends BaseDao<Entity>> extends CrudServiceInterface<Entity, Dao> {

}