package com.weimob.o2o.mgr.shake.domain;

public class ShakeFocus {
	private long shakeFucusId;
	private String title;
	private String description;
	private String slogan;
	private String backgroundUrl;
	private long shakePageId;
	private String createTime;
	private String updateTime;

	public void setShakeFucusId(long shakeFucusId){
		this.shakeFucusId = shakeFucusId;
	}

	public long getShakeFucusId(){
		return this.shakeFucusId;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return this.description;
	}

	public void setSlogan(String slogan){
		this.slogan = slogan;
	}

	public String getSlogan(){
		return this.slogan;
	}

	public void setBackgroundUrl(String backgroundUrl){
		this.backgroundUrl = backgroundUrl;
	}

	public String getBackgroundUrl(){
		return this.backgroundUrl;
	}

	public void setShakePageId(long shakePageId){
		this.shakePageId = shakePageId;
	}

	public long getShakePageId(){
		return this.shakePageId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}