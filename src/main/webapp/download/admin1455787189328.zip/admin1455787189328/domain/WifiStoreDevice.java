package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStoreDevice implements Serializable {
	private Long wifiStoreDeviceId;
	private Long aid;
	private Long merchantId;
	private Long storeId;
	private String mac;
	private Integer macType;
	private Integer macStatus;
	private Date createTime;
	private Date updateTime;
	private Long createAccountId;
	private Long udpateAccountId;
}