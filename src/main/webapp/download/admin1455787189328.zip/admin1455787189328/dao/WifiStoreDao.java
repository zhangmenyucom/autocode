package com.weimob.o2o.mgr.wifi.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStore;

public interface WifiStoreDao extends BaseDao<WifiStore> {
}