package com.weimob.o2o.mgr.wifi.service;

import com.weimob.o2o.mgr.wifi.domain.WifiMerchant;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiMerchantService extends CrudServiceInterface<WifiMerchant> {

}