package com.weimob.o2o.mgr.wifi.service;

import com.weimob.o2o.mgr.wifi.domain.WifiStoreHomePage;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiStoreHomePageService extends CrudServiceInterface<WifiStoreHomePage> {

}