package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiStoreHomePageService;
import com.weimob.o2o.mgr.wifi.dao.WifiStoreHomePageDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreHomePage;
import org.springframework.stereotype.Service;
    
@Service
public class WifiStoreHomePageServiceImpl 
        extends CrudService<WifiStoreHomePage, WifiStoreHomePageDao> 
        implements WifiStoreHomePageService {

}