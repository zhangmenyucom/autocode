package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiSupplierService;
import com.weimob.o2o.mgr.wifi.dao.WifiSupplierDao;
import com.weimob.o2o.mgr.wifi.domain.WifiSupplier;
import org.springframework.stereotype.Service;
    
@Service
public class WifiSupplierServiceImpl 
        extends CrudService<WifiSupplier, WifiSupplierDao> 
        implements WifiSupplierService {

}