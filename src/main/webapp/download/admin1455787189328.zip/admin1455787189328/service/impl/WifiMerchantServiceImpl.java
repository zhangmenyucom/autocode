package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiMerchantService;
import com.weimob.o2o.mgr.wifi.dao.WifiMerchantDao;
import com.weimob.o2o.mgr.wifi.domain.WifiMerchant;
import org.springframework.stereotype.Service;
    
@Service
public class WifiMerchantServiceImpl 
        extends CrudService<WifiMerchant, WifiMerchantDao> 
        implements WifiMerchantService {

}