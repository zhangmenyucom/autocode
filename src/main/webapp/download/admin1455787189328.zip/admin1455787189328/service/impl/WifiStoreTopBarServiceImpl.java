package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiStoreTopBarService;
import com.weimob.o2o.mgr.wifi.dao.WifiStoreTopBarDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStoreTopBar;
import org.springframework.stereotype.Service;
    
@Service
public class WifiStoreTopBarServiceImpl 
        extends CrudService<WifiStoreTopBar, WifiStoreTopBarDao> 
        implements WifiStoreTopBarService {

}