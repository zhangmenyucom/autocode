package com.weimob.o2o.mgr.wifi.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.wifi.service.WifiStoreService;
import com.weimob.o2o.mgr.wifi.dao.WifiStoreDao;
import com.weimob.o2o.mgr.wifi.domain.WifiStore;
import org.springframework.stereotype.Service;
    
@Service
public class WifiStoreServiceImpl 
        extends CrudService<WifiStore, WifiStoreDao> 
        implements WifiStoreService {

}