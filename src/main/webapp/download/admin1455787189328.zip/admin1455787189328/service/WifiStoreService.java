package com.weimob.o2o.mgr.wifi.service;

import com.weimob.o2o.mgr.wifi.domain.WifiStore;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WifiStoreService extends CrudServiceInterface<WifiStore> {

}