package com.weimob.o2o.mgr.shake.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ShakePageSch extends SearchEntity{

    private Long shakePageIdSch;
    private Long merchantIdSch;
    private String pageIdSch;
    private String titleSch;
    private String descriptionSch;
    private String iconUrlSch;
    private String pageUrlSch;
    private String commentSch;
    private Long activtyIdSch;
    private Integer typeSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setShakePageIdSch(Long shakePageIdSch){
        this.shakePageIdSch = shakePageIdSch;
    }
    
    @ValueField(column = "shake_page_id")
    public Long getShakePageIdSch(){
        return this.shakePageIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setPageIdSch(String pageIdSch){
        this.pageIdSch = pageIdSch;
    }
    
    @ValueField(column = "page_id")
    public String getPageIdSch(){
        return this.pageIdSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setDescriptionSch(String descriptionSch){
        this.descriptionSch = descriptionSch;
    }
    
    @ValueField(column = "description")
    public String getDescriptionSch(){
        return this.descriptionSch;
    }

    public void setIconUrlSch(String iconUrlSch){
        this.iconUrlSch = iconUrlSch;
    }
    
    @ValueField(column = "icon_url")
    public String getIconUrlSch(){
        return this.iconUrlSch;
    }

    public void setPageUrlSch(String pageUrlSch){
        this.pageUrlSch = pageUrlSch;
    }
    
    @ValueField(column = "page_url")
    public String getPageUrlSch(){
        return this.pageUrlSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setActivtyIdSch(Long activtyIdSch){
        this.activtyIdSch = activtyIdSch;
    }
    
    @ValueField(column = "activty_id")
    public Long getActivtyIdSch(){
        return this.activtyIdSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}