package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ImageSch extends SearchEntity{

    private Long idSch;
    private String imageIdSch;
    private String urlSch;
    private Long accountIdSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setImageIdSch(String imageIdSch){
        this.imageIdSch = imageIdSch;
    }
    
    @ValueField(column = "image_id")
    public String getImageIdSch(){
        return this.imageIdSch;
    }

    public void setUrlSch(String urlSch){
        this.urlSch = urlSch;
    }
    
    @ValueField(column = "url")
    public String getUrlSch(){
        return this.urlSch;
    }

    public void setAccountIdSch(Long accountIdSch){
        this.accountIdSch = accountIdSch;
    }
    
    @ValueField(column = "account_id")
    public Long getAccountIdSch(){
        return this.accountIdSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}