package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Image implements Serializable {
	private Long id;
	private String imageId;
	private String url;
	private Long accountId;
	private Date updateTime;
	private Date createTime;
}