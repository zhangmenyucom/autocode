package com.ayuan.blog.service;

import com.github.pagehelper.PageInfo;

import com.ayuan.blog.domain.Image;
import com.ayuan.blog.domain.sch.ImageSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ImageService extends CrudServiceInterface<Image> {

    PageInfo<Image> findPage(ImageSch sch);
}