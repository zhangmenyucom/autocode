package com.ayuan.blog.dao;

import org.durcframework.core.dao.BaseDao;
import com.ayuan.blog.domain.Image;

public interface ImageDao extends BaseDao<Image> {
}