package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.AgentStoreDevice;

public interface AgentStoreDeviceDao extends BaseDao<AgentStoreDevice> {
}