package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag;

public interface O2oScrmCustomerTagDao extends BaseDao<O2oScrmCustomerTag> {
}