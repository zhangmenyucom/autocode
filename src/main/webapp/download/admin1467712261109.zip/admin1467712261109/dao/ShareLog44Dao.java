package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog44;

public interface ShareLog44Dao extends BaseDao<ShareLog44> {
}