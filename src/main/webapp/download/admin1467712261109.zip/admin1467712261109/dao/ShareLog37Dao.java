package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog37;

public interface ShareLog37Dao extends BaseDao<ShareLog37> {
}