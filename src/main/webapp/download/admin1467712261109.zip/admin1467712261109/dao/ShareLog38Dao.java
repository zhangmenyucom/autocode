package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog38;

public interface ShareLog38Dao extends BaseDao<ShareLog38> {
}