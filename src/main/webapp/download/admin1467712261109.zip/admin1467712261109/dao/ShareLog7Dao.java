package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog7;

public interface ShareLog7Dao extends BaseDao<ShareLog7> {
}