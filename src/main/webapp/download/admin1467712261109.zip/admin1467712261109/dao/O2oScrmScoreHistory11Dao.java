package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory11;

public interface O2oScrmScoreHistory11Dao extends BaseDao<O2oScrmScoreHistory11> {
}