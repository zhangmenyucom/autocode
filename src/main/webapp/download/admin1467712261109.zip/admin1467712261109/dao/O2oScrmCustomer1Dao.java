package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer1;

public interface O2oScrmCustomer1Dao extends BaseDao<O2oScrmCustomer1> {
}