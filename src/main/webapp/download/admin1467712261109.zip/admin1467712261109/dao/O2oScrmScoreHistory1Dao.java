package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory1;

public interface O2oScrmScoreHistory1Dao extends BaseDao<O2oScrmScoreHistory1> {
}