package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.AgentSupplier;

public interface AgentSupplierDao extends BaseDao<AgentSupplier> {
}