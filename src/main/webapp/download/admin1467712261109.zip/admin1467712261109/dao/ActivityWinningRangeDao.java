package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityWinningRange;

public interface ActivityWinningRangeDao extends BaseDao<ActivityWinningRange> {
}