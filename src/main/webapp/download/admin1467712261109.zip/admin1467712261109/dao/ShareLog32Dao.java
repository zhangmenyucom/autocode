package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog32;

public interface ShareLog32Dao extends BaseDao<ShareLog32> {
}