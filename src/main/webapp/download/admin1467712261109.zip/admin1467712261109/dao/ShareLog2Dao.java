package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog2;

public interface ShareLog2Dao extends BaseDao<ShareLog2> {
}