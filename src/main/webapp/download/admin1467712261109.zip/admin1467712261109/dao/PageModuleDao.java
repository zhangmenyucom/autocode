package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.PageModule;

public interface PageModuleDao extends BaseDao<PageModule> {
}