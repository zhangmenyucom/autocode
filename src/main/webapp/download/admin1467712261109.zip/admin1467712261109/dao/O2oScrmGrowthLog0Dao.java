package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog0;

public interface O2oScrmGrowthLog0Dao extends BaseDao<O2oScrmGrowthLog0> {
}