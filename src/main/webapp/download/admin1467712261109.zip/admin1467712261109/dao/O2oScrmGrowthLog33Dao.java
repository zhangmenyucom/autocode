package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog33;

public interface O2oScrmGrowthLog33Dao extends BaseDao<O2oScrmGrowthLog33> {
}