package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog39;

public interface O2oScrmGrowthLog39Dao extends BaseDao<O2oScrmGrowthLog39> {
}