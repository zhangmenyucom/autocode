package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog34;

public interface ShareLog34Dao extends BaseDao<ShareLog34> {
}