package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer7;

public interface O2oScrmCustomer7Dao extends BaseDao<O2oScrmCustomer7> {
}