package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog43;

public interface ShareLog43Dao extends BaseDao<ShareLog43> {
}