package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.DatadicItems;

public interface DatadicItemsDao extends BaseDao<DatadicItems> {
}