package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog8;

public interface ShareLog8Dao extends BaseDao<ShareLog8> {
}