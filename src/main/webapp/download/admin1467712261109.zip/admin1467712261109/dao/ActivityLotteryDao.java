package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityLottery;

public interface ActivityLotteryDao extends BaseDao<ActivityLottery> {
}