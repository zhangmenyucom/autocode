package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog33;

public interface ShareLog33Dao extends BaseDao<ShareLog33> {
}