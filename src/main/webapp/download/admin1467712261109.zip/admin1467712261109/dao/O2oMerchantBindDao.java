package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oMerchantBind;

public interface O2oMerchantBindDao extends BaseDao<O2oMerchantBind> {
}