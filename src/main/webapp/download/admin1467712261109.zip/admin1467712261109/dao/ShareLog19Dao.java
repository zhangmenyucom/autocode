package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog19;

public interface ShareLog19Dao extends BaseDao<ShareLog19> {
}