package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShakeDeviceApply;

public interface ShakeDeviceApplyDao extends BaseDao<ShakeDeviceApply> {
}