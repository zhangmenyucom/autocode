package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog12;

public interface ShareLog12Dao extends BaseDao<ShareLog12> {
}