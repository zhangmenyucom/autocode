package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStoreCardTemplateRelation;

public interface O2oStoreCardTemplateRelationDao extends BaseDao<O2oStoreCardTemplateRelation> {
}