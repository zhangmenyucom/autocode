package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog44;

public interface O2oScrmGrowthLog44Dao extends BaseDao<O2oScrmGrowthLog44> {
}