package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog28;

public interface ShareLog28Dao extends BaseDao<ShareLog28> {
}