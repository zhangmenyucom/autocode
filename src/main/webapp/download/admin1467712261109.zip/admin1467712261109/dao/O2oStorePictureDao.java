package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStorePicture;

public interface O2oStorePictureDao extends BaseDao<O2oStorePicture> {
}