package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oBusinessInfo;

public interface O2oBusinessInfoDao extends BaseDao<O2oBusinessInfo> {
}