package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStoreTerminalExt;

public interface O2oStoreTerminalExtDao extends BaseDao<O2oStoreTerminalExt> {
}