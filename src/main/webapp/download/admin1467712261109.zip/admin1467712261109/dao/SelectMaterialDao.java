package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.SelectMaterial;

public interface SelectMaterialDao extends BaseDao<SelectMaterial> {
}