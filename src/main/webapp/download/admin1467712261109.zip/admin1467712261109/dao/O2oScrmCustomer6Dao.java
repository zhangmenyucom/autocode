package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer6;

public interface O2oScrmCustomer6Dao extends BaseDao<O2oScrmCustomer6> {
}