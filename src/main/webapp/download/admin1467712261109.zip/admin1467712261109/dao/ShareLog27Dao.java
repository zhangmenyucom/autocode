package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog27;

public interface ShareLog27Dao extends BaseDao<ShareLog27> {
}