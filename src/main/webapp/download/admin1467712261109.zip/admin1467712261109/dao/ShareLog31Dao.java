package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog31;

public interface ShareLog31Dao extends BaseDao<ShareLog31> {
}