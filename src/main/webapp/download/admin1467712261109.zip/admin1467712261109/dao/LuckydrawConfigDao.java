package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.LuckydrawConfig;

public interface LuckydrawConfigDao extends BaseDao<LuckydrawConfig> {
}