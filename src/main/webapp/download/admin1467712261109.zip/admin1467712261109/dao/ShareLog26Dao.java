package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog26;

public interface ShareLog26Dao extends BaseDao<ShareLog26> {
}