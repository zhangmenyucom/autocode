package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityLuckydrawConfig;

public interface ActivityLuckydrawConfigDao extends BaseDao<ActivityLuckydrawConfig> {
}