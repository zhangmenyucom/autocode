package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag10;

public interface O2oScrmCustomerTag10Dao extends BaseDao<O2oScrmCustomerTag10> {
}