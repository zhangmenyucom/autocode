package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStoreTerminalSupplier;

public interface O2oStoreTerminalSupplierDao extends BaseDao<O2oStoreTerminalSupplier> {
}