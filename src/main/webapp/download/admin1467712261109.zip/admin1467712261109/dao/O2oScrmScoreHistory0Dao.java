package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory0;

public interface O2oScrmScoreHistory0Dao extends BaseDao<O2oScrmScoreHistory0> {
}