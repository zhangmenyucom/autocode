package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer2;

public interface O2oScrmCustomer2Dao extends BaseDao<O2oScrmCustomer2> {
}