package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog8;

public interface O2oScrmGrowthLog8Dao extends BaseDao<O2oScrmGrowthLog8> {
}