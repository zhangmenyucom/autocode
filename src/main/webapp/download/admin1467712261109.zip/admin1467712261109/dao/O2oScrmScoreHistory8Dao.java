package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory8;

public interface O2oScrmScoreHistory8Dao extends BaseDao<O2oScrmScoreHistory8> {
}