package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog15;

public interface O2oScrmGrowthLog15Dao extends BaseDao<O2oScrmGrowthLog15> {
}