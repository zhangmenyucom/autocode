package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory3;

public interface O2oScrmScoreHistory3Dao extends BaseDao<O2oScrmScoreHistory3> {
}