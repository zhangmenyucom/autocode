package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog38;

public interface O2oScrmGrowthLog38Dao extends BaseDao<O2oScrmGrowthLog38> {
}