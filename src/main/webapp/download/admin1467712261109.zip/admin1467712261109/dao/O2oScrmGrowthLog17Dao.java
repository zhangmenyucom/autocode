package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog17;

public interface O2oScrmGrowthLog17Dao extends BaseDao<O2oScrmGrowthLog17> {
}