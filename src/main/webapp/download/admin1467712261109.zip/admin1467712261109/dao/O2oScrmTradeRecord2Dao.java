package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmTradeRecord2;

public interface O2oScrmTradeRecord2Dao extends BaseDao<O2oScrmTradeRecord2> {
}