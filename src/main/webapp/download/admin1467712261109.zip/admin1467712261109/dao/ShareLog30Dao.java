package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog30;

public interface ShareLog30Dao extends BaseDao<ShareLog30> {
}