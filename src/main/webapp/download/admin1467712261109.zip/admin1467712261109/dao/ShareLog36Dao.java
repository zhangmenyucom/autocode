package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog36;

public interface ShareLog36Dao extends BaseDao<ShareLog36> {
}