package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory;

public interface O2oScrmScoreHistoryDao extends BaseDao<O2oScrmScoreHistory> {
}