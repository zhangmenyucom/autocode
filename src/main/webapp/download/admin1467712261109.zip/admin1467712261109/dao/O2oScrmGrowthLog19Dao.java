package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog19;

public interface O2oScrmGrowthLog19Dao extends BaseDao<O2oScrmGrowthLog19> {
}