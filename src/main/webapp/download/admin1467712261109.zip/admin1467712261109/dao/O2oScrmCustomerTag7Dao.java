package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag7;

public interface O2oScrmCustomerTag7Dao extends BaseDao<O2oScrmCustomerTag7> {
}