package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog41;

public interface ShareLog41Dao extends BaseDao<ShareLog41> {
}