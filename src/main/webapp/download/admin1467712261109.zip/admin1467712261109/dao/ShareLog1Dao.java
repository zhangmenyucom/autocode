package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog1;

public interface ShareLog1Dao extends BaseDao<ShareLog1> {
}