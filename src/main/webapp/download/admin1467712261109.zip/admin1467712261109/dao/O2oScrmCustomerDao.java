package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer;

public interface O2oScrmCustomerDao extends BaseDao<O2oScrmCustomer> {
}