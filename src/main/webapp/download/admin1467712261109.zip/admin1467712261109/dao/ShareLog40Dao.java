package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog40;

public interface ShareLog40Dao extends BaseDao<ShareLog40> {
}