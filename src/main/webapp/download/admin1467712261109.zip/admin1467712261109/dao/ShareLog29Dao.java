package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog29;

public interface ShareLog29Dao extends BaseDao<ShareLog29> {
}