package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog;

public interface O2oScrmGrowthLogDao extends BaseDao<O2oScrmGrowthLog> {
}