package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog15;

public interface ShareLog15Dao extends BaseDao<ShareLog15> {
}