package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog21;

public interface ShareLog21Dao extends BaseDao<ShareLog21> {
}