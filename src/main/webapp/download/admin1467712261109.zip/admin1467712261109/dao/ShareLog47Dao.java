package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog47;

public interface ShareLog47Dao extends BaseDao<ShareLog47> {
}