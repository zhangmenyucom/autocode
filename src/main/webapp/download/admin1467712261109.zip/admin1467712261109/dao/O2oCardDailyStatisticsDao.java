package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oCardDailyStatistics;

public interface O2oCardDailyStatisticsDao extends BaseDao<O2oCardDailyStatistics> {
}