package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag6;

public interface O2oScrmCustomerTag6Dao extends BaseDao<O2oScrmCustomerTag6> {
}