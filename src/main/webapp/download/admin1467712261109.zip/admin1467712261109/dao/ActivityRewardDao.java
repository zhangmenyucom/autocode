package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityReward;

public interface ActivityRewardDao extends BaseDao<ActivityReward> {
}