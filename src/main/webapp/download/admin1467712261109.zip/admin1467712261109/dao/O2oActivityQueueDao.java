package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oActivityQueue;

public interface O2oActivityQueueDao extends BaseDao<O2oActivityQueue> {
}