package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStore;

public interface O2oStoreDao extends BaseDao<O2oStore> {
}