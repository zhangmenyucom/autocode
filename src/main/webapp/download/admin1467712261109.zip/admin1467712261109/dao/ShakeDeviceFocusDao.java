package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShakeDeviceFocus;

public interface ShakeDeviceFocusDao extends BaseDao<ShakeDeviceFocus> {
}