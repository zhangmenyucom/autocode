package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag9;

public interface O2oScrmCustomerTag9Dao extends BaseDao<O2oScrmCustomerTag9> {
}