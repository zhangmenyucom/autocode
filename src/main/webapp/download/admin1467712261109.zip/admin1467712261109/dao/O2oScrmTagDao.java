package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmTag;

public interface O2oScrmTagDao extends BaseDao<O2oScrmTag> {
}