package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog5;

public interface ShareLog5Dao extends BaseDao<ShareLog5> {
}