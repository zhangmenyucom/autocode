package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.AgentStoreSupplier;

public interface AgentStoreSupplierDao extends BaseDao<AgentStoreSupplier> {
}