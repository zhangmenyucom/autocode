package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityPosCardStatistics;

public interface ActivityPosCardStatisticsDao extends BaseDao<ActivityPosCardStatistics> {
}