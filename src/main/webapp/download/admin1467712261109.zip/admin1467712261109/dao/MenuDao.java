package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.Menu;

public interface MenuDao extends BaseDao<Menu> {
}