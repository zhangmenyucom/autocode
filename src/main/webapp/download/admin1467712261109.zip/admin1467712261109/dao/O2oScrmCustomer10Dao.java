package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer10;

public interface O2oScrmCustomer10Dao extends BaseDao<O2oScrmCustomer10> {
}