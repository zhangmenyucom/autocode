package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityCardContent;

public interface ActivityCardContentDao extends BaseDao<ActivityCardContent> {
}