package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog14;

public interface O2oScrmGrowthLog14Dao extends BaseDao<O2oScrmGrowthLog14> {
}