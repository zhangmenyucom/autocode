package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.Page;

public interface PageDao extends BaseDao<Page> {
}