package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer5;

public interface O2oScrmCustomer5Dao extends BaseDao<O2oScrmCustomer5> {
}