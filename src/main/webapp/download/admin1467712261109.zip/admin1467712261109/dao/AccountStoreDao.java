package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.AccountStore;

public interface AccountStoreDao extends BaseDao<AccountStore> {
}