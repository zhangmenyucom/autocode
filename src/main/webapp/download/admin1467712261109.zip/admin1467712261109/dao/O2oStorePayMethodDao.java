package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oStorePayMethod;

public interface O2oStorePayMethodDao extends BaseDao<O2oStorePayMethod> {
}