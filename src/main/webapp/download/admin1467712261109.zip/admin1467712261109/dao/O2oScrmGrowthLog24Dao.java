package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog24;

public interface O2oScrmGrowthLog24Dao extends BaseDao<O2oScrmGrowthLog24> {
}