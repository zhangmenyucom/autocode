package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oMicroPageSingleDailyStatistics;

public interface O2oMicroPageSingleDailyStatisticsDao extends BaseDao<O2oMicroPageSingleDailyStatistics> {
}