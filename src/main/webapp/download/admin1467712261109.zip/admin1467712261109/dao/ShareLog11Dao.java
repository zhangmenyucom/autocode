package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog11;

public interface ShareLog11Dao extends BaseDao<ShareLog11> {
}