package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oMicroPageDailyStatistics;

public interface O2oMicroPageDailyStatisticsDao extends BaseDao<O2oMicroPageDailyStatistics> {
}