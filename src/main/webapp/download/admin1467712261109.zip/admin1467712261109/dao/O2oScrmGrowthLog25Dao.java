package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog25;

public interface O2oScrmGrowthLog25Dao extends BaseDao<O2oScrmGrowthLog25> {
}