package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog14;

public interface ShareLog14Dao extends BaseDao<ShareLog14> {
}