package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog45;

public interface ShareLog45Dao extends BaseDao<ShareLog45> {
}