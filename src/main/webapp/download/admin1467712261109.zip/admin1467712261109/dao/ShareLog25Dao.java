package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog25;

public interface ShareLog25Dao extends BaseDao<ShareLog25> {
}