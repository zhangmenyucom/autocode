package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oCardHourStatistics;

public interface O2oCardHourStatisticsDao extends BaseDao<O2oCardHourStatistics> {
}