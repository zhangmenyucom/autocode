package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomer8;

public interface O2oScrmCustomer8Dao extends BaseDao<O2oScrmCustomer8> {
}