package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.MarketModelPaySceneDishConfig;

public interface MarketModelPaySceneDishConfigDao extends BaseDao<MarketModelPaySceneDishConfig> {
}