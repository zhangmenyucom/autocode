package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog18;

public interface O2oScrmGrowthLog18Dao extends BaseDao<O2oScrmGrowthLog18> {
}