package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory6;

public interface O2oScrmScoreHistory6Dao extends BaseDao<O2oScrmScoreHistory6> {
}