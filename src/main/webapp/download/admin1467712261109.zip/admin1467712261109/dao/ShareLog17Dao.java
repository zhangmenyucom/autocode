package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog17;

public interface ShareLog17Dao extends BaseDao<ShareLog17> {
}