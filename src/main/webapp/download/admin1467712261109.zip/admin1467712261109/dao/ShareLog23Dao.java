package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog23;

public interface ShareLog23Dao extends BaseDao<ShareLog23> {
}