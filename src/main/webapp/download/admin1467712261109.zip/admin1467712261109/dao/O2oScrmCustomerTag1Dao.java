package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag1;

public interface O2oScrmCustomerTag1Dao extends BaseDao<O2oScrmCustomerTag1> {
}