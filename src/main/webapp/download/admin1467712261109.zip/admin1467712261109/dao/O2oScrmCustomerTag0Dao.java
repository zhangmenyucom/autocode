package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmCustomerTag0;

public interface O2oScrmCustomerTag0Dao extends BaseDao<O2oScrmCustomerTag0> {
}