package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oActivityQueueUser;

public interface O2oActivityQueueUserDao extends BaseDao<O2oActivityQueueUser> {
}