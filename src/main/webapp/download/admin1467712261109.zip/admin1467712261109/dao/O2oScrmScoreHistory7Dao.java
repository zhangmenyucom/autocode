package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmScoreHistory7;

public interface O2oScrmScoreHistory7Dao extends BaseDao<O2oScrmScoreHistory7> {
}