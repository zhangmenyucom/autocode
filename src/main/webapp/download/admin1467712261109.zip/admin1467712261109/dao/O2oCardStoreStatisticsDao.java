package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oCardStoreStatistics;

public interface O2oCardStoreStatisticsDao extends BaseDao<O2oCardStoreStatistics> {
}