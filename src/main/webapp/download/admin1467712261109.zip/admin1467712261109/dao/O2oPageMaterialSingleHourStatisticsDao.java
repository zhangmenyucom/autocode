package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oPageMaterialSingleHourStatistics;

public interface O2oPageMaterialSingleHourStatisticsDao extends BaseDao<O2oPageMaterialSingleHourStatistics> {
}