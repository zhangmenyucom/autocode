package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oMicroPageSingleHourStatistics;

public interface O2oMicroPageSingleHourStatisticsDao extends BaseDao<O2oMicroPageSingleHourStatistics> {
}