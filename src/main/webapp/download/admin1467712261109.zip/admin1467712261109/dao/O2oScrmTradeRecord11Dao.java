package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmTradeRecord11;

public interface O2oScrmTradeRecord11Dao extends BaseDao<O2oScrmTradeRecord11> {
}