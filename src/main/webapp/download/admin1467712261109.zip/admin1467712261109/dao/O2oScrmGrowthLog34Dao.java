package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.O2oScrmGrowthLog34;

public interface O2oScrmGrowthLog34Dao extends BaseDao<O2oScrmGrowthLog34> {
}