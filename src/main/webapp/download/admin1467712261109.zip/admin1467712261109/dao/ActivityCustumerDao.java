package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ActivityCustumer;

public interface ActivityCustumerDao extends BaseDao<ActivityCustumer> {
}