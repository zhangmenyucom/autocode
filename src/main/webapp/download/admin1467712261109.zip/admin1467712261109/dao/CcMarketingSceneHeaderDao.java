package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.CcMarketingSceneHeader;

public interface CcMarketingSceneHeaderDao extends BaseDao<CcMarketingSceneHeader> {
}