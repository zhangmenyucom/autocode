package com.test.dao;

import org.durcframework.core.dao.BaseDao;
import com.test.domain.ShareLog18;

public interface ShareLog18Dao extends BaseDao<ShareLog18> {
}