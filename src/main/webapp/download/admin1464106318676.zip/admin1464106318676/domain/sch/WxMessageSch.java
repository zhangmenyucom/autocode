package com.ayuan.blog.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WxMessageSch extends SearchEntity{

    private Long idSch;
    private Long userIdSch;
    private String openIdSch;
    private String msgTypeSch;
    private String contentSch;
    private String msgIdSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setUserIdSch(Long userIdSch){
        this.userIdSch = userIdSch;
    }
    
    @ValueField(column = "user_id")
    public Long getUserIdSch(){
        return this.userIdSch;
    }

    public void setOpenIdSch(String openIdSch){
        this.openIdSch = openIdSch;
    }
    
    @ValueField(column = "open_id")
    public String getOpenIdSch(){
        return this.openIdSch;
    }

    public void setMsgTypeSch(String msgTypeSch){
        this.msgTypeSch = msgTypeSch;
    }
    
    @ValueField(column = "msg_type")
    public String getMsgTypeSch(){
        return this.msgTypeSch;
    }

    public void setContentSch(String contentSch){
        this.contentSch = contentSch;
    }
    
    @ValueField(column = "content")
    public String getContentSch(){
        return this.contentSch;
    }

    public void setMsgIdSch(String msgIdSch){
        this.msgIdSch = msgIdSch;
    }
    
    @ValueField(column = "msg_id")
    public String getMsgIdSch(){
        return this.msgIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}