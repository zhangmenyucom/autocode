package com.ayuan.blog.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WxMessage implements Serializable {
	private Long id;
	private Long userId;
	private String openId;
	private String msgType;
	private String content;
	private String msgId;
	private Date createTime;
}