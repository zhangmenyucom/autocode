package com.ayuan.blog.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.ayuan.blog.service.WxMessageService;
import com.ayuan.blog.dao.WxMessageDao;
import com.ayuan.blog.domain.WxMessage;
import com.ayuan.blog.domain.sch.WxMessageSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class WxMessageServiceImpl 
        extends CrudService<WxMessage, WxMessageDao> 
        implements WxMessageService {

    @Override
    public PageInfo<WxMessage> findPage(WxMessageSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<WxMessage> list = this.getDao().find(query);

        PageInfo<WxMessage> page = new PageInfo<WxMessage>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}