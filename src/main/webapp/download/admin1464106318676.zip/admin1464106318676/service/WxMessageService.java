package com.ayuan.blog.service;

import com.github.pagehelper.PageInfo;

import com.ayuan.blog.domain.WxMessage;
import com.ayuan.blog.domain.sch.WxMessageSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface WxMessageService extends CrudServiceInterface<WxMessage> {

    PageInfo<WxMessage> findPage(WxMessageSch sch);
}