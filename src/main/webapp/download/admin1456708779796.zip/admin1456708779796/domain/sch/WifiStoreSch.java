package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStoreSch extends SearchEntity{

    private Long wifiStoreIdSch;
    private Long aidSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private Long wifiSupplierIdSch;
    private Integer deviceTypeSch;
    private String wechatStoreIdSch;
    private String wechatAppIdSch;
    private String wechatSecretKeySch;
    private String ssidSch;
    private Integer typeSch;
    private Integer addedDeviceCountSch;
    private Integer toBeAddDeviceCountSch;
    private String passwordSch;
    private Date createTimeSch;
    private Date updateTimeSch;
    private Long createAccountIdSch;
    private Long updateAccountIdSch;

    public void setWifiStoreIdSch(Long wifiStoreIdSch){
        this.wifiStoreIdSch = wifiStoreIdSch;
    }
    
    @ValueField(column = "wifi_store_id")
    public Long getWifiStoreIdSch(){
        return this.wifiStoreIdSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setWifiSupplierIdSch(Long wifiSupplierIdSch){
        this.wifiSupplierIdSch = wifiSupplierIdSch;
    }
    
    @ValueField(column = "wifi_supplier_id")
    public Long getWifiSupplierIdSch(){
        return this.wifiSupplierIdSch;
    }

    public void setDeviceTypeSch(Integer deviceTypeSch){
        this.deviceTypeSch = deviceTypeSch;
    }
    
    @ValueField(column = "device_type")
    public Integer getDeviceTypeSch(){
        return this.deviceTypeSch;
    }

    public void setWechatStoreIdSch(String wechatStoreIdSch){
        this.wechatStoreIdSch = wechatStoreIdSch;
    }
    
    @ValueField(column = "wechat_store_id")
    public String getWechatStoreIdSch(){
        return this.wechatStoreIdSch;
    }

    public void setWechatAppIdSch(String wechatAppIdSch){
        this.wechatAppIdSch = wechatAppIdSch;
    }
    
    @ValueField(column = "wechat_app_id")
    public String getWechatAppIdSch(){
        return this.wechatAppIdSch;
    }

    public void setWechatSecretKeySch(String wechatSecretKeySch){
        this.wechatSecretKeySch = wechatSecretKeySch;
    }
    
    @ValueField(column = "wechat_secret_key")
    public String getWechatSecretKeySch(){
        return this.wechatSecretKeySch;
    }

    public void setSsidSch(String ssidSch){
        this.ssidSch = ssidSch;
    }
    
    @ValueField(column = "ssid")
    public String getSsidSch(){
        return this.ssidSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setAddedDeviceCountSch(Integer addedDeviceCountSch){
        this.addedDeviceCountSch = addedDeviceCountSch;
    }
    
    @ValueField(column = "added_device_count")
    public Integer getAddedDeviceCountSch(){
        return this.addedDeviceCountSch;
    }

    public void setToBeAddDeviceCountSch(Integer toBeAddDeviceCountSch){
        this.toBeAddDeviceCountSch = toBeAddDeviceCountSch;
    }
    
    @ValueField(column = "to_be_add_device_count")
    public Integer getToBeAddDeviceCountSch(){
        return this.toBeAddDeviceCountSch;
    }

    public void setPasswordSch(String passwordSch){
        this.passwordSch = passwordSch;
    }
    
    @ValueField(column = "password")
    public String getPasswordSch(){
        return this.passwordSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateAccountIdSch(Long createAccountIdSch){
        this.createAccountIdSch = createAccountIdSch;
    }
    
    @ValueField(column = "create_account_id")
    public Long getCreateAccountIdSch(){
        return this.createAccountIdSch;
    }

    public void setUpdateAccountIdSch(Long updateAccountIdSch){
        this.updateAccountIdSch = updateAccountIdSch;
    }
    
    @ValueField(column = "update_account_id")
    public Long getUpdateAccountIdSch(){
        return this.updateAccountIdSch;
    }


}