package com.weimob.o2o.activity.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MarketTimeSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long activityIdSch;
    private Integer indexSch;
    private String weekdaysSch;
    private String startTimeEachDaySch;
    private String endTimeEachDaySch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setActivityIdSch(Long activityIdSch){
        this.activityIdSch = activityIdSch;
    }
    
    @ValueField(column = "activity_id")
    public Long getActivityIdSch(){
        return this.activityIdSch;
    }

    public void setIndexSch(Integer indexSch){
        this.indexSch = indexSch;
    }
    
    @ValueField(column = "index")
    public Integer getIndexSch(){
        return this.indexSch;
    }

    public void setWeekdaysSch(String weekdaysSch){
        this.weekdaysSch = weekdaysSch;
    }
    
    @ValueField(column = "weekdays")
    public String getWeekdaysSch(){
        return this.weekdaysSch;
    }

    public void setStartTimeEachDaySch(String startTimeEachDaySch){
        this.startTimeEachDaySch = startTimeEachDaySch;
    }
    
    @ValueField(column = "start_time_each_day")
    public String getStartTimeEachDaySch(){
        return this.startTimeEachDaySch;
    }

    public void setEndTimeEachDaySch(String endTimeEachDaySch){
        this.endTimeEachDaySch = endTimeEachDaySch;
    }
    
    @ValueField(column = "end_time_each_day")
    public String getEndTimeEachDaySch(){
        return this.endTimeEachDaySch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}