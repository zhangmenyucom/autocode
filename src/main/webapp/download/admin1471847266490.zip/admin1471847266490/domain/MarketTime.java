package com.weimob.o2o.activity.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MarketTime implements Serializable {
	private Long id;
	private Long merchantId;
	private Long activityId;
	private Integer index;
	private String weekdays;
	private String startTimeEachDay;
	private String endTimeEachDay;
	private Date updateTime;
	private Date createTime;
}