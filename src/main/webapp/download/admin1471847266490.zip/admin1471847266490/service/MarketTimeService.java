package com.weimob.o2o.activity.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.activity.mgr.domain.MarketTime;
import com.weimob.o2o.activity.mgr.domain.sch.MarketTimeSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MarketTimeService extends CrudServiceInterface<MarketTime> {

    PageInfo<MarketTime> findPage(MarketTimeSch sch);
}