package com.weimob.o2o.mgr.agent.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class AgentSupplier implements Serializable {
	private Long agentSupplierId;
	private Integer device;
	private String supplierName;
	private Integer deviceType;
	private String supplierPhone;
	private String comment;
	private Date createTime;
	private Date updateTime;
}