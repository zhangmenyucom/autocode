package com.weimob.o2o.mgr.agent.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class AgentStoreDevice implements Serializable {
	private Long agentStoreDeviceId;
	private Integer device;
	private Long merchantId;
	private Long aid;
	private Long storeId;
	private String deviceAttr1;
	private String deviceAttr2;
	private String deviceAttr3;
	private String deviceAttr4;
	private String deviceAttr5;
	private Date createTime;
	private Date updateTime;
}