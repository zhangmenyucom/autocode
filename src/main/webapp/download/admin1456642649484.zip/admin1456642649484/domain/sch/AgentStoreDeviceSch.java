package com.weimob.o2o.mgr.agent.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class AgentStoreDeviceSch extends SearchEntity{

    private Long agentStoreDeviceIdSch;
    private Integer deviceSch;
    private Long merchantIdSch;
    private Long aidSch;
    private Long storeIdSch;
    private String deviceAttr1Sch;
    private String deviceAttr2Sch;
    private String deviceAttr3Sch;
    private String deviceAttr4Sch;
    private String deviceAttr5Sch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setAgentStoreDeviceIdSch(Long agentStoreDeviceIdSch){
        this.agentStoreDeviceIdSch = agentStoreDeviceIdSch;
    }
    
    @ValueField(column = "agent_store_device_id")
    public Long getAgentStoreDeviceIdSch(){
        return this.agentStoreDeviceIdSch;
    }

    public void setDeviceSch(Integer deviceSch){
        this.deviceSch = deviceSch;
    }
    
    @ValueField(column = "device")
    public Integer getDeviceSch(){
        return this.deviceSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setAidSch(Long aidSch){
        this.aidSch = aidSch;
    }
    
    @ValueField(column = "aid")
    public Long getAidSch(){
        return this.aidSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setDeviceAttr1Sch(String deviceAttr1Sch){
        this.deviceAttr1Sch = deviceAttr1Sch;
    }
    
    @ValueField(column = "device_attr1")
    public String getDeviceAttr1Sch(){
        return this.deviceAttr1Sch;
    }

    public void setDeviceAttr2Sch(String deviceAttr2Sch){
        this.deviceAttr2Sch = deviceAttr2Sch;
    }
    
    @ValueField(column = "device_attr2")
    public String getDeviceAttr2Sch(){
        return this.deviceAttr2Sch;
    }

    public void setDeviceAttr3Sch(String deviceAttr3Sch){
        this.deviceAttr3Sch = deviceAttr3Sch;
    }
    
    @ValueField(column = "device_attr3")
    public String getDeviceAttr3Sch(){
        return this.deviceAttr3Sch;
    }

    public void setDeviceAttr4Sch(String deviceAttr4Sch){
        this.deviceAttr4Sch = deviceAttr4Sch;
    }
    
    @ValueField(column = "device_attr4")
    public String getDeviceAttr4Sch(){
        return this.deviceAttr4Sch;
    }

    public void setDeviceAttr5Sch(String deviceAttr5Sch){
        this.deviceAttr5Sch = deviceAttr5Sch;
    }
    
    @ValueField(column = "device_attr5")
    public String getDeviceAttr5Sch(){
        return this.deviceAttr5Sch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}