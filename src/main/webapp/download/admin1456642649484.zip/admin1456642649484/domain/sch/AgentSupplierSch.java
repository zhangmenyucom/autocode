package com.weimob.o2o.mgr.agent.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class AgentSupplierSch extends SearchEntity{

    private Long agentSupplierIdSch;
    private Integer deviceSch;
    private String supplierNameSch;
    private Integer deviceTypeSch;
    private String supplierPhoneSch;
    private String commentSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setAgentSupplierIdSch(Long agentSupplierIdSch){
        this.agentSupplierIdSch = agentSupplierIdSch;
    }
    
    @ValueField(column = "agent_supplier_id")
    public Long getAgentSupplierIdSch(){
        return this.agentSupplierIdSch;
    }

    public void setDeviceSch(Integer deviceSch){
        this.deviceSch = deviceSch;
    }
    
    @ValueField(column = "device")
    public Integer getDeviceSch(){
        return this.deviceSch;
    }

    public void setSupplierNameSch(String supplierNameSch){
        this.supplierNameSch = supplierNameSch;
    }
    
    @ValueField(column = "supplier_name")
    public String getSupplierNameSch(){
        return this.supplierNameSch;
    }

    public void setDeviceTypeSch(Integer deviceTypeSch){
        this.deviceTypeSch = deviceTypeSch;
    }
    
    @ValueField(column = "device_type")
    public Integer getDeviceTypeSch(){
        return this.deviceTypeSch;
    }

    public void setSupplierPhoneSch(String supplierPhoneSch){
        this.supplierPhoneSch = supplierPhoneSch;
    }
    
    @ValueField(column = "supplier_phone")
    public String getSupplierPhoneSch(){
        return this.supplierPhoneSch;
    }

    public void setCommentSch(String commentSch){
        this.commentSch = commentSch;
    }
    
    @ValueField(column = "comment")
    public String getCommentSch(){
        return this.commentSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}