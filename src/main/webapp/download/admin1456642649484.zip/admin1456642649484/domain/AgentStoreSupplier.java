package com.weimob.o2o.mgr.agent.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class AgentStoreSupplier implements Serializable {
	private Long agentStoreSupplierId;
	private Integer device;
	private Long merchantId;
	private Long aid;
	private Long storeId;
	private Long agentSupplierId;
	private Date createTime;
	private Date updateTime;
}