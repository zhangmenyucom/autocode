package com.weimob.o2o.mgr.agent.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.agent.domain.AgentSupplier;

public interface AgentSupplierDao extends BaseDao<AgentSupplier> {
}