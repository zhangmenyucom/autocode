package com.weimob.o2o.mgr.agent.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.agent.domain.AgentStoreDevice;

public interface AgentStoreDeviceDao extends BaseDao<AgentStoreDevice> {
}