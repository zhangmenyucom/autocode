package com.weimob.o2o.mgr.agent.service;

import com.weimob.o2o.mgr.agent.domain.AgentStoreDevice;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface AgentStoreDeviceService extends CrudServiceInterface<AgentStoreDevice> {

}