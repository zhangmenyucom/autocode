package com.weimob.o2o.mgr.agent.service;

import com.weimob.o2o.mgr.agent.domain.AgentStoreSupplier;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface AgentStoreSupplierService extends CrudServiceInterface<AgentStoreSupplier> {

}