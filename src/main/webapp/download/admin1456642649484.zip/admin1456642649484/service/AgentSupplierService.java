package com.weimob.o2o.mgr.agent.service;

import com.weimob.o2o.mgr.agent.domain.AgentSupplier;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface AgentSupplierService extends CrudServiceInterface<AgentSupplier> {

}