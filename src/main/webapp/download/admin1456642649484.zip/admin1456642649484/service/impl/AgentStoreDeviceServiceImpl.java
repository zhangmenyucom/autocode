package com.weimob.o2o.mgr.agent.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.agent.service.AgentStoreDeviceService;
import com.weimob.o2o.mgr.agent.dao.AgentStoreDeviceDao;
import com.weimob.o2o.mgr.agent.domain.AgentStoreDevice;
import org.springframework.stereotype.Service;
    
@Service
public class AgentStoreDeviceServiceImpl 
        extends CrudService<AgentStoreDevice, AgentStoreDeviceDao> 
        implements AgentStoreDeviceService {

}