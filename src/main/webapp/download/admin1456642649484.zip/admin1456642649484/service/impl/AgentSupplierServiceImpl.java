package com.weimob.o2o.mgr.agent.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.agent.service.AgentSupplierService;
import com.weimob.o2o.mgr.agent.dao.AgentSupplierDao;
import com.weimob.o2o.mgr.agent.domain.AgentSupplier;
import org.springframework.stereotype.Service;
    
@Service
public class AgentSupplierServiceImpl 
        extends CrudService<AgentSupplier, AgentSupplierDao> 
        implements AgentSupplierService {

}