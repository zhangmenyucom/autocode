package com.weimob.o2o.mgr.agent.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.agent.service.AgentStoreSupplierService;
import com.weimob.o2o.mgr.agent.dao.AgentStoreSupplierDao;
import com.weimob.o2o.mgr.agent.domain.AgentStoreSupplier;
import org.springframework.stereotype.Service;
    
@Service
public class AgentStoreSupplierServiceImpl 
        extends CrudService<AgentStoreSupplier, AgentStoreSupplierDao> 
        implements AgentStoreSupplierService {

}