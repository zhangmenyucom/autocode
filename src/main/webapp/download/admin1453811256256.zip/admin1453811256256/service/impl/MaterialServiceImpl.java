package com.weimob.o2o.mgr.material.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.material.service.MaterialService;
import com.weimob.o2o.mgr.material.dao.MaterialDao;
import com.weimob.o2o.mgr.material.domain.Material;
import org.springframework.stereotype.Service;
    
@Service
public class MaterialServiceImpl 
        extends CrudService<Material, MaterialDao> 
        implements MaterialService {

}