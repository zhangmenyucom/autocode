package com.weimob.o2o.mgr.material.service;

import com.weimob.o2o.mgr.material.domain.Material;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MaterialService extends CrudServiceInterface<Material> {

}