package com.weimob.o2o.mgr.material.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.material.domain.Material;

public interface MaterialDao extends BaseDao<Material> {
}