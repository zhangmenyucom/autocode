package menu.entity;

public class Menu {
	private long id;
	private long parentId;
	private String label;
	private String url;
	private long type;
	private String icons;
	private String bgColor;
	private long showOrder;

	public void setId(long id){
		this.id = id;
	}

	public long getId(){
		return this.id;
	}

	public void setParentId(long parentId){
		this.parentId = parentId;
	}

	public long getParentId(){
		return this.parentId;
	}

	public void setLabel(String label){
		this.label = label;
	}

	public String getLabel(){
		return this.label;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUrl(){
		return this.url;
	}

	public void setType(long type){
		this.type = type;
	}

	public long getType(){
		return this.type;
	}

	public void setIcons(String icons){
		this.icons = icons;
	}

	public String getIcons(){
		return this.icons;
	}

	public void setBgColor(String bgColor){
		this.bgColor = bgColor;
	}

	public String getBgColor(){
		return this.bgColor;
	}

	public void setShowOrder(long showOrder){
		this.showOrder = showOrder;
	}

	public long getShowOrder(){
		return this.showOrder;
	}

}