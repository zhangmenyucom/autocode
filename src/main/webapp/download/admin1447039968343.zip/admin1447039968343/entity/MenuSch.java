package menu.entity;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class MenuSch extends SearchEntity{

    private Long idSch;
    private Long parentIdSch;
    private String labelSch;
    private String urlSch;
    private Long typeSch;
    private String iconsSch;
    private String bgColorSch;
    private Long showOrderSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setParentIdSch(Long parentIdSch){
        this.parentIdSch = parentIdSch;
    }
    
    @ValueField(column = "parentId")
    public Long getParentIdSch(){
        return this.parentIdSch;
    }

    public void setLabelSch(String labelSch){
        this.labelSch = labelSch;
    }
    
    @ValueField(column = "label")
    public String getLabelSch(){
        return this.labelSch;
    }

    public void setUrlSch(String urlSch){
        this.urlSch = urlSch;
    }
    
    @ValueField(column = "url")
    public String getUrlSch(){
        return this.urlSch;
    }

    public void setTypeSch(Long typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Long getTypeSch(){
        return this.typeSch;
    }

    public void setIconsSch(String iconsSch){
        this.iconsSch = iconsSch;
    }
    
    @ValueField(column = "icons")
    public String getIconsSch(){
        return this.iconsSch;
    }

    public void setBgColorSch(String bgColorSch){
        this.bgColorSch = bgColorSch;
    }
    
    @ValueField(column = "bgColor")
    public String getBgColorSch(){
        return this.bgColorSch;
    }

    public void setShowOrderSch(Long showOrderSch){
        this.showOrderSch = showOrderSch;
    }
    
    @ValueField(column = "showOrder")
    public Long getShowOrderSch(){
        return this.showOrderSch;
    }


}