package menu.service;

import org.durcframework.core.service.CrudService;
import menu.dao.MenuDao;
import menu.entity.Menu;
import org.springframework.stereotype.Service;

@Service
public class MenuService extends CrudService<Menu, MenuDao> {

}