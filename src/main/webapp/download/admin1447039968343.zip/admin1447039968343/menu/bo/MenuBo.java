package menu.menu.bo;

import org.springframework.stereotype.Service;

import com.shunwang.business.framework.bo.CrudBo;
import menu.menu.dao.MenuDao;
import menu.menu.pojo.Menu;

@Service
public class MenuBo extends CrudBo<Menu, MenuDao> {

}