package menu.menu.dao;

import com.shunwang.business.framework.dao.CrudDao;
import menu.menu.pojo.Menu;

public interface MenuDao extends CrudDao<Menu> {
}