package menu.dao;

import org.durcframework.core.dao.BaseDao;
import menu.entity.Menu;

public interface MenuDao extends BaseDao<Menu> {
}