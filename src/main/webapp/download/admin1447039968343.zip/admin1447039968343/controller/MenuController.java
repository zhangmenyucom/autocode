package menu.controller;

import org.durcframework.core.GridResult;
import org.durcframework.core.MessageResult;
import org.durcframework.core.controller.CrudController;
import menu.entity.Menu;
import menu.entity.MenuSch;
import menu.service.MenuService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MenuController extends
		CrudController<Menu, MenuService> {

	@RequestMapping("/addMenu.do")
	public @ResponseBody
	MessageResult addMenu(Menu entity) {
		return this.save(entity);
	}

	@RequestMapping("/listMenu.do")
	public @ResponseBody
	GridResult listMenu(MenuSch searchEntity) {
		return this.query(searchEntity);
	}

	@RequestMapping("/updateMenu.do")
	public @ResponseBody
	MessageResult updateMenu(Menu entity) {
		return this.update(entity);
	}

	@RequestMapping("/delMenu.do")
	public @ResponseBody
	MessageResult delMenu(Menu entity) {
		return this.delete(entity);
	}
	
}