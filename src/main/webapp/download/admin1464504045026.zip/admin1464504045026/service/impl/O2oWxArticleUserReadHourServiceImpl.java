package com.weimob.o2oreport.mgr.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.weimob.o2oreport.mgr.service.O2oWxArticleUserReadHourService;
import com.weimob.o2oreport.mgr.dao.O2oWxArticleUserReadHourDao;
import com.weimob.o2oreport.mgr.domain.O2oWxArticleUserReadHour;
import com.weimob.o2oreport.mgr.domain.sch.O2oWxArticleUserReadHourSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class O2oWxArticleUserReadHourServiceImpl 
        extends CrudService<O2oWxArticleUserReadHour, O2oWxArticleUserReadHourDao> 
        implements O2oWxArticleUserReadHourService {

    @Override
    public PageInfo<O2oWxArticleUserReadHour> findPage(O2oWxArticleUserReadHourSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<O2oWxArticleUserReadHour> list = this.getDao().find(query);

        PageInfo<O2oWxArticleUserReadHour> page = new PageInfo<O2oWxArticleUserReadHour>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}