package com.weimob.o2oreport.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2oreport.mgr.domain.O2oWxArticleUserReadHour;
import com.weimob.o2oreport.mgr.domain.sch.O2oWxArticleUserReadHourSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oWxArticleUserReadHourService extends CrudServiceInterface<O2oWxArticleUserReadHour> {

    PageInfo<O2oWxArticleUserReadHour> findPage(O2oWxArticleUserReadHourSch sch);
}