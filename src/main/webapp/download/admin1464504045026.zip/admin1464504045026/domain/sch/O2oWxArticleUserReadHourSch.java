package com.weimob.o2oreport.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oWxArticleUserReadHourSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private String refDateSch;
    private Integer refHourSch;
    private Integer userSourceSch;
    private Long intPageReadUserSch;
    private Long intPageReadCountSch;
    private Long oriPageReadUserSch;
    private Long oriPageReadCountSch;
    private Long shareUserSch;
    private Long shareCountSch;
    private Long addToFavUserSch;
    private Long addToFavCountSch;
    private Date updateTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setRefDateSch(String refDateSch){
        this.refDateSch = refDateSch;
    }
    
    @ValueField(column = "ref_date")
    public String getRefDateSch(){
        return this.refDateSch;
    }

    public void setRefHourSch(Integer refHourSch){
        this.refHourSch = refHourSch;
    }
    
    @ValueField(column = "ref_hour")
    public Integer getRefHourSch(){
        return this.refHourSch;
    }

    public void setUserSourceSch(Integer userSourceSch){
        this.userSourceSch = userSourceSch;
    }
    
    @ValueField(column = "user_source")
    public Integer getUserSourceSch(){
        return this.userSourceSch;
    }

    public void setIntPageReadUserSch(Long intPageReadUserSch){
        this.intPageReadUserSch = intPageReadUserSch;
    }
    
    @ValueField(column = "int_page_read_user")
    public Long getIntPageReadUserSch(){
        return this.intPageReadUserSch;
    }

    public void setIntPageReadCountSch(Long intPageReadCountSch){
        this.intPageReadCountSch = intPageReadCountSch;
    }
    
    @ValueField(column = "int_page_read_count")
    public Long getIntPageReadCountSch(){
        return this.intPageReadCountSch;
    }

    public void setOriPageReadUserSch(Long oriPageReadUserSch){
        this.oriPageReadUserSch = oriPageReadUserSch;
    }
    
    @ValueField(column = "ori_page_read_user")
    public Long getOriPageReadUserSch(){
        return this.oriPageReadUserSch;
    }

    public void setOriPageReadCountSch(Long oriPageReadCountSch){
        this.oriPageReadCountSch = oriPageReadCountSch;
    }
    
    @ValueField(column = "ori_page_read_count")
    public Long getOriPageReadCountSch(){
        return this.oriPageReadCountSch;
    }

    public void setShareUserSch(Long shareUserSch){
        this.shareUserSch = shareUserSch;
    }
    
    @ValueField(column = "share_user")
    public Long getShareUserSch(){
        return this.shareUserSch;
    }

    public void setShareCountSch(Long shareCountSch){
        this.shareCountSch = shareCountSch;
    }
    
    @ValueField(column = "share_count")
    public Long getShareCountSch(){
        return this.shareCountSch;
    }

    public void setAddToFavUserSch(Long addToFavUserSch){
        this.addToFavUserSch = addToFavUserSch;
    }
    
    @ValueField(column = "add_to_fav_user")
    public Long getAddToFavUserSch(){
        return this.addToFavUserSch;
    }

    public void setAddToFavCountSch(Long addToFavCountSch){
        this.addToFavCountSch = addToFavCountSch;
    }
    
    @ValueField(column = "add_to_fav_count")
    public Long getAddToFavCountSch(){
        return this.addToFavCountSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}