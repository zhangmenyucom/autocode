package com.weimob.o2oreport.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2oreport.mgr.domain.O2oWxArticleTotal;

public interface O2oWxArticleTotalDao extends BaseDao<O2oWxArticleTotal> {
}