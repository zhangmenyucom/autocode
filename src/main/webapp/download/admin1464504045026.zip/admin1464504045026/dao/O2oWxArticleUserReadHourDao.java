package com.weimob.o2oreport.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2oreport.mgr.domain.O2oWxArticleUserReadHour;

public interface O2oWxArticleUserReadHourDao extends BaseDao<O2oWxArticleUserReadHour> {
}