package com.weimob.o2o.mgr.wifi.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.wifi.domain.WifiSupplier;

public interface WifiSupplierDao extends BaseDao<WifiSupplier> {
}