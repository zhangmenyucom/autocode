package com.weimob.o2oreport.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oWxArticleTotal implements Serializable {
	private Long id;
	private Long merchantId;
	private String refDate;
	private String msgId;
	private String mediaId;
	private String title;
	private String statDate;
	private Long targetUser;
	private Long intPageReadUser;
	private Long intPageReadCount;
	private Long oriPageReadUser;
	private Long oriPageReadCount;
	private Long shareUser;
	private Long shareCount;
	private Long addToFavUser;
	private Long addToFavCount;
	private Long intPageFromSessionReadUser;
	private Long intPageFromSessionReadCount;
	private Long intPageFromHistMsgReadUser;
	private Long intPageFromHistMsgReadCount;
	private Long intPageFromFeedReadUser;
	private Long intPageFromFeedReadCount;
	private Long intPageFromFriendsReadUser;
	private Long intPageFromFriendsReadCount;
	private Long intPageFromOtherReadUser;
	private Long intPageFromOtherReadCount;
	private Long feedShareFromSessionUser;
	private Long feedShareFromSessionCnt;
	private Long feedShareFromFeedUser;
	private Long feedShareFromFeedCnt;
	private Long feedShareFromOtherUser;
	private Long feedShareFromOtherCnt;
	private Date updateTime;
}