package com.weimob.o2oreport.mgr.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oWxArticleUserReadHour implements Serializable {
	private Long id;
	private Long merchantId;
	private String refDate;
	private Integer refHour;
	private Integer userSource;
	private Long intPageReadUser;
	private Long intPageReadCount;
	private Long oriPageReadUser;
	private Long oriPageReadCount;
	private Long shareUser;
	private Long shareCount;
	private Long addToFavUser;
	private Long addToFavCount;
	private Date updateTime;
}