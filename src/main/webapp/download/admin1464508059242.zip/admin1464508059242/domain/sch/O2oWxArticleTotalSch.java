package com.weimob.o2oreport.mgr.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oWxArticleTotalSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private String refDateSch;
    private String msgIdSch;
    private String mediaIdSch;
    private String titleSch;
    private String statDateSch;
    private Long targetUserSch;
    private Long intPageReadUserSch;
    private Long intPageReadCountSch;
    private Long oriPageReadUserSch;
    private Long oriPageReadCountSch;
    private Long shareUserSch;
    private Long shareCountSch;
    private Long addToFavUserSch;
    private Long addToFavCountSch;
    private Long intPageFromSessionReadUserSch;
    private Long intPageFromSessionReadCountSch;
    private Long intPageFromHistMsgReadUserSch;
    private Long intPageFromHistMsgReadCountSch;
    private Long intPageFromFeedReadUserSch;
    private Long intPageFromFeedReadCountSch;
    private Long intPageFromFriendsReadUserSch;
    private Long intPageFromFriendsReadCountSch;
    private Long intPageFromOtherReadUserSch;
    private Long intPageFromOtherReadCountSch;
    private Long feedShareFromSessionUserSch;
    private Long feedShareFromSessionCntSch;
    private Long feedShareFromFeedUserSch;
    private Long feedShareFromFeedCntSch;
    private Long feedShareFromOtherUserSch;
    private Long feedShareFromOtherCntSch;
    private Date updateTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setRefDateSch(String refDateSch){
        this.refDateSch = refDateSch;
    }
    
    @ValueField(column = "ref_date")
    public String getRefDateSch(){
        return this.refDateSch;
    }

    public void setMsgIdSch(String msgIdSch){
        this.msgIdSch = msgIdSch;
    }
    
    @ValueField(column = "msg_id")
    public String getMsgIdSch(){
        return this.msgIdSch;
    }

    public void setMediaIdSch(String mediaIdSch){
        this.mediaIdSch = mediaIdSch;
    }
    
    @ValueField(column = "media_id")
    public String getMediaIdSch(){
        return this.mediaIdSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setStatDateSch(String statDateSch){
        this.statDateSch = statDateSch;
    }
    
    @ValueField(column = "stat_date")
    public String getStatDateSch(){
        return this.statDateSch;
    }

    public void setTargetUserSch(Long targetUserSch){
        this.targetUserSch = targetUserSch;
    }
    
    @ValueField(column = "target_user")
    public Long getTargetUserSch(){
        return this.targetUserSch;
    }

    public void setIntPageReadUserSch(Long intPageReadUserSch){
        this.intPageReadUserSch = intPageReadUserSch;
    }
    
    @ValueField(column = "int_page_read_user")
    public Long getIntPageReadUserSch(){
        return this.intPageReadUserSch;
    }

    public void setIntPageReadCountSch(Long intPageReadCountSch){
        this.intPageReadCountSch = intPageReadCountSch;
    }
    
    @ValueField(column = "int_page_read_count")
    public Long getIntPageReadCountSch(){
        return this.intPageReadCountSch;
    }

    public void setOriPageReadUserSch(Long oriPageReadUserSch){
        this.oriPageReadUserSch = oriPageReadUserSch;
    }
    
    @ValueField(column = "ori_page_read_user")
    public Long getOriPageReadUserSch(){
        return this.oriPageReadUserSch;
    }

    public void setOriPageReadCountSch(Long oriPageReadCountSch){
        this.oriPageReadCountSch = oriPageReadCountSch;
    }
    
    @ValueField(column = "ori_page_read_count")
    public Long getOriPageReadCountSch(){
        return this.oriPageReadCountSch;
    }

    public void setShareUserSch(Long shareUserSch){
        this.shareUserSch = shareUserSch;
    }
    
    @ValueField(column = "share_user")
    public Long getShareUserSch(){
        return this.shareUserSch;
    }

    public void setShareCountSch(Long shareCountSch){
        this.shareCountSch = shareCountSch;
    }
    
    @ValueField(column = "share_count")
    public Long getShareCountSch(){
        return this.shareCountSch;
    }

    public void setAddToFavUserSch(Long addToFavUserSch){
        this.addToFavUserSch = addToFavUserSch;
    }
    
    @ValueField(column = "add_to_fav_user")
    public Long getAddToFavUserSch(){
        return this.addToFavUserSch;
    }

    public void setAddToFavCountSch(Long addToFavCountSch){
        this.addToFavCountSch = addToFavCountSch;
    }
    
    @ValueField(column = "add_to_fav_count")
    public Long getAddToFavCountSch(){
        return this.addToFavCountSch;
    }

    public void setIntPageFromSessionReadUserSch(Long intPageFromSessionReadUserSch){
        this.intPageFromSessionReadUserSch = intPageFromSessionReadUserSch;
    }
    
    @ValueField(column = "int_page_from_session_read_user")
    public Long getIntPageFromSessionReadUserSch(){
        return this.intPageFromSessionReadUserSch;
    }

    public void setIntPageFromSessionReadCountSch(Long intPageFromSessionReadCountSch){
        this.intPageFromSessionReadCountSch = intPageFromSessionReadCountSch;
    }
    
    @ValueField(column = "int_page_from_session_read_count")
    public Long getIntPageFromSessionReadCountSch(){
        return this.intPageFromSessionReadCountSch;
    }

    public void setIntPageFromHistMsgReadUserSch(Long intPageFromHistMsgReadUserSch){
        this.intPageFromHistMsgReadUserSch = intPageFromHistMsgReadUserSch;
    }
    
    @ValueField(column = "int_page_from_hist_msg_read_user")
    public Long getIntPageFromHistMsgReadUserSch(){
        return this.intPageFromHistMsgReadUserSch;
    }

    public void setIntPageFromHistMsgReadCountSch(Long intPageFromHistMsgReadCountSch){
        this.intPageFromHistMsgReadCountSch = intPageFromHistMsgReadCountSch;
    }
    
    @ValueField(column = "int_page_from_hist_msg_read_count")
    public Long getIntPageFromHistMsgReadCountSch(){
        return this.intPageFromHistMsgReadCountSch;
    }

    public void setIntPageFromFeedReadUserSch(Long intPageFromFeedReadUserSch){
        this.intPageFromFeedReadUserSch = intPageFromFeedReadUserSch;
    }
    
    @ValueField(column = "int_page_from_feed_read_user")
    public Long getIntPageFromFeedReadUserSch(){
        return this.intPageFromFeedReadUserSch;
    }

    public void setIntPageFromFeedReadCountSch(Long intPageFromFeedReadCountSch){
        this.intPageFromFeedReadCountSch = intPageFromFeedReadCountSch;
    }
    
    @ValueField(column = "int_page_from_feed_read_count")
    public Long getIntPageFromFeedReadCountSch(){
        return this.intPageFromFeedReadCountSch;
    }

    public void setIntPageFromFriendsReadUserSch(Long intPageFromFriendsReadUserSch){
        this.intPageFromFriendsReadUserSch = intPageFromFriendsReadUserSch;
    }
    
    @ValueField(column = "int_page_from_friends_read_user")
    public Long getIntPageFromFriendsReadUserSch(){
        return this.intPageFromFriendsReadUserSch;
    }

    public void setIntPageFromFriendsReadCountSch(Long intPageFromFriendsReadCountSch){
        this.intPageFromFriendsReadCountSch = intPageFromFriendsReadCountSch;
    }
    
    @ValueField(column = "int_page_from_friends_read_count")
    public Long getIntPageFromFriendsReadCountSch(){
        return this.intPageFromFriendsReadCountSch;
    }

    public void setIntPageFromOtherReadUserSch(Long intPageFromOtherReadUserSch){
        this.intPageFromOtherReadUserSch = intPageFromOtherReadUserSch;
    }
    
    @ValueField(column = "int_page_from_other_read_user")
    public Long getIntPageFromOtherReadUserSch(){
        return this.intPageFromOtherReadUserSch;
    }

    public void setIntPageFromOtherReadCountSch(Long intPageFromOtherReadCountSch){
        this.intPageFromOtherReadCountSch = intPageFromOtherReadCountSch;
    }
    
    @ValueField(column = "int_page_from_other_read_count")
    public Long getIntPageFromOtherReadCountSch(){
        return this.intPageFromOtherReadCountSch;
    }

    public void setFeedShareFromSessionUserSch(Long feedShareFromSessionUserSch){
        this.feedShareFromSessionUserSch = feedShareFromSessionUserSch;
    }
    
    @ValueField(column = "feed_share_from_session_user")
    public Long getFeedShareFromSessionUserSch(){
        return this.feedShareFromSessionUserSch;
    }

    public void setFeedShareFromSessionCntSch(Long feedShareFromSessionCntSch){
        this.feedShareFromSessionCntSch = feedShareFromSessionCntSch;
    }
    
    @ValueField(column = "feed_share_from_session_cnt")
    public Long getFeedShareFromSessionCntSch(){
        return this.feedShareFromSessionCntSch;
    }

    public void setFeedShareFromFeedUserSch(Long feedShareFromFeedUserSch){
        this.feedShareFromFeedUserSch = feedShareFromFeedUserSch;
    }
    
    @ValueField(column = "feed_share_from_feed_user")
    public Long getFeedShareFromFeedUserSch(){
        return this.feedShareFromFeedUserSch;
    }

    public void setFeedShareFromFeedCntSch(Long feedShareFromFeedCntSch){
        this.feedShareFromFeedCntSch = feedShareFromFeedCntSch;
    }
    
    @ValueField(column = "feed_share_from_feed_cnt")
    public Long getFeedShareFromFeedCntSch(){
        return this.feedShareFromFeedCntSch;
    }

    public void setFeedShareFromOtherUserSch(Long feedShareFromOtherUserSch){
        this.feedShareFromOtherUserSch = feedShareFromOtherUserSch;
    }
    
    @ValueField(column = "feed_share_from_other_user")
    public Long getFeedShareFromOtherUserSch(){
        return this.feedShareFromOtherUserSch;
    }

    public void setFeedShareFromOtherCntSch(Long feedShareFromOtherCntSch){
        this.feedShareFromOtherCntSch = feedShareFromOtherCntSch;
    }
    
    @ValueField(column = "feed_share_from_other_cnt")
    public Long getFeedShareFromOtherCntSch(){
        return this.feedShareFromOtherCntSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}