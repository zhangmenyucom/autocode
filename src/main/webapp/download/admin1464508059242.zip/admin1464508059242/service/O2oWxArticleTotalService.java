package com.weimob.o2oreport.mgr.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2oreport.mgr.domain.O2oWxArticleTotal;
import com.weimob.o2oreport.mgr.domain.sch.O2oWxArticleTotalSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oWxArticleTotalService extends CrudServiceInterface<O2oWxArticleTotal> {

    PageInfo<O2oWxArticleTotal> findPage(O2oWxArticleTotalSch sch);
}