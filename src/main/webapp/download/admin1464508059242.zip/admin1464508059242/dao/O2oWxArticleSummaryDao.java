package com.weimob.o2oreport.mgr.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2oreport.mgr.domain.O2oWxArticleSummary;

public interface O2oWxArticleSummaryDao extends BaseDao<O2oWxArticleSummary> {
}