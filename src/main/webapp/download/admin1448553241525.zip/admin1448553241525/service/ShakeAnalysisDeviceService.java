package com.weimob.o2o.mgr.shake.service;

import com.weimob.o2o.mgr.shake.domain.ShakeAnalysisDevice;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeAnalysisDeviceService extends CrudServiceInterface<ShakeAnalysisDevice> {

}