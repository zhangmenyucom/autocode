package com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.shake.service.ShakeAnalysisDeviceService;
import com.weimob.o2o.mgr.shake.dao.ShakeAnalysisDeviceDao;
import com.weimob.o2o.mgr.shake.domain.ShakeAnalysisDevice;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeAnalysisDeviceServiceImpl 
        extends CrudService<ShakeAnalysisDevice, ShakeAnalysisDeviceDao> 
        implements ShakeAnalysisDeviceService {

}