package com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.shake.service.ShakeAnalysisPageService;
import com.weimob.o2o.mgr.shake.dao.ShakeAnalysisPageDao;
import com.weimob.o2o.mgr.shake.domain.ShakeAnalysisPage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeAnalysisPageServiceImpl 
        extends CrudService<ShakeAnalysisPage, ShakeAnalysisPageDao> 
        implements ShakeAnalysisPageService {

}