package  com.weimob.o2o.mgr.shake.service;

import  com.weimob.o2o.mgr.shake.domain.ShakeDeviceApply;
import  com.weimob.o2o.mgr.shake.dao.ShakeDeviceApplyDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDeviceApplyService extends CrudServiceInterface<ShakeDeviceApply> {

}