package  com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import  com.weimob.o2o.mgr.shake.service.ShakeDeviceService;
import  com.weimob.o2o.mgr.shake.dao.ShakeDeviceDao;
import  com.weimob.o2o.mgr.shake.domain.ShakeDevice;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceServiceImpl 
        extends CrudService<ShakeDevice, ShakeDeviceDao> 
        implements ShakeDeviceService {

}