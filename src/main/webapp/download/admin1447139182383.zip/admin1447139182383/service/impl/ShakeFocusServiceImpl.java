package  com.weimob.o2o.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import  com.weimob.o2o.mgr.shake.service.ShakeFocusService;
import  com.weimob.o2o.mgr.shake.dao.ShakeFocusDao;
import  com.weimob.o2o.mgr.shake.domain.ShakeFocus;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeFocusServiceImpl 
        extends CrudService<ShakeFocus, ShakeFocusDao> 
        implements ShakeFocusService {

}