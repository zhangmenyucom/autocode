package  com.weimob.o2o.mgr.shake.domain;

public class ShakePage {
	private Long shakePageId;
	private String pageId;
	private String title;
	private String description;
	private String iconUrl;
	private String pageUrl;
	private String comment;
	private Long activtyId;
	private String createTime;
	private String updateTime;

	public void setShakePageId(Long shakePageId){
		this.shakePageId = shakePageId;
	}

	public Long getShakePageId(){
		return this.shakePageId;
	}

	public void setPageId(String pageId){
		this.pageId = pageId;
	}

	public String getPageId(){
		return this.pageId;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return this.title;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return this.description;
	}

	public void setIconUrl(String iconUrl){
		this.iconUrl = iconUrl;
	}

	public String getIconUrl(){
		return this.iconUrl;
	}

	public void setPageUrl(String pageUrl){
		this.pageUrl = pageUrl;
	}

	public String getPageUrl(){
		return this.pageUrl;
	}

	public void setComment(String comment){
		this.comment = comment;
	}

	public String getComment(){
		return this.comment;
	}

	public void setActivtyId(Long activtyId){
		this.activtyId = activtyId;
	}

	public Long getActivtyId(){
		return this.activtyId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}