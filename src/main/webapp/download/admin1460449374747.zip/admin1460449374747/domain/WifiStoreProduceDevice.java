package com.weimob.o2o.mgr.wifi.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class WifiStoreProduceDevice implements Serializable {
	private Long wifiStoreProduceDeviceId;
	private Long merchantId;
	private Long storeId;
	private String ssid;
	private String password;
	private Date createTime;
	private Date updateTime;
}