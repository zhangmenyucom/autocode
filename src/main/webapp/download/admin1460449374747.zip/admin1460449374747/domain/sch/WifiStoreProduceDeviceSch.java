package com.weimob.o2o.mgr.wifi.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class WifiStoreProduceDeviceSch extends SearchEntity{

    private Long wifiStoreProduceDeviceIdSch;
    private Long merchantIdSch;
    private Long storeIdSch;
    private String ssidSch;
    private String passwordSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setWifiStoreProduceDeviceIdSch(Long wifiStoreProduceDeviceIdSch){
        this.wifiStoreProduceDeviceIdSch = wifiStoreProduceDeviceIdSch;
    }
    
    @ValueField(column = "wifi_store_produce_device_id")
    public Long getWifiStoreProduceDeviceIdSch(){
        return this.wifiStoreProduceDeviceIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setSsidSch(String ssidSch){
        this.ssidSch = ssidSch;
    }
    
    @ValueField(column = "ssid")
    public String getSsidSch(){
        return this.ssidSch;
    }

    public void setPasswordSch(String passwordSch){
        this.passwordSch = passwordSch;
    }
    
    @ValueField(column = "password")
    public String getPasswordSch(){
        return this.passwordSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}