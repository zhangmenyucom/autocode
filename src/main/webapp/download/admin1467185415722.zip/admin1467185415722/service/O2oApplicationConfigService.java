package com.weimob.o2o.mgr.application.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.application.domain.O2oApplicationConfig;
import com.weimob.o2o.mgr.application.domain.sch.O2oApplicationConfigSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oApplicationConfigService extends CrudServiceInterface<O2oApplicationConfig> {

    PageInfo<O2oApplicationConfig> findPage(O2oApplicationConfigSch sch);
}