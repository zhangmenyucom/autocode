package com.weimob.o2o.mgr.application.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.application.domain.O2oApplication;
import com.weimob.o2o.mgr.application.domain.sch.O2oApplicationSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface O2oApplicationService extends CrudServiceInterface<O2oApplication> {

    PageInfo<O2oApplication> findPage(O2oApplicationSch sch);
}