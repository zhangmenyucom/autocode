package com.weimob.o2o.mgr.application.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.application.service.O2oApplicationConfigService;
import com.weimob.o2o.mgr.application.dao.O2oApplicationConfigDao;
import com.weimob.o2o.mgr.application.domain.O2oApplicationConfig;
import com.weimob.o2o.mgr.application.domain.sch.O2oApplicationConfigSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class O2oApplicationConfigServiceImpl 
        extends CrudService<O2oApplicationConfig, O2oApplicationConfigDao> 
        implements O2oApplicationConfigService {

    @Override
    public PageInfo<O2oApplicationConfig> findPage(O2oApplicationConfigSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<O2oApplicationConfig> list = this.getDao().find(query);

        PageInfo<O2oApplicationConfig> page = new PageInfo<O2oApplicationConfig>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}