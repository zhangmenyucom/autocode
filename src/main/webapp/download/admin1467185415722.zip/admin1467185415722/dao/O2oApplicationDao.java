package com.weimob.o2o.mgr.application.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.application.domain.O2oApplication;

public interface O2oApplicationDao extends BaseDao<O2oApplication> {
}