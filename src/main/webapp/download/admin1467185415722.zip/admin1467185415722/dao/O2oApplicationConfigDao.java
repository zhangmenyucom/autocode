package com.weimob.o2o.mgr.application.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.application.domain.O2oApplicationConfig;

public interface O2oApplicationConfigDao extends BaseDao<O2oApplicationConfig> {
}