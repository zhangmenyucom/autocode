package com.weimob.o2o.mgr.application.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class O2oApplicationConfigSch extends SearchEntity{

    private Long idSch;
    private Long merchantIdSch;
    private Long applicationIdSch;
    private Integer typeSch;
    private Integer statusSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setIdSch(Long idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Long getIdSch(){
        return this.idSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setApplicationIdSch(Long applicationIdSch){
        this.applicationIdSch = applicationIdSch;
    }
    
    @ValueField(column = "application_id")
    public Long getApplicationIdSch(){
        return this.applicationIdSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}