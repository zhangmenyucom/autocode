package com.weimob.o2o.mgr.application.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class O2oApplication implements Serializable {
	private Long id;
	private Long merchantId;
	private Integer type;
	private String name;
	private String description;
	private String logoUrl;
	private String link;
	private Date updateTime;
	private Date createTime;
}