package com.weimob.o2o.mgr.meiwei.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.meiwei.domain.MeiWeiQueue;
import com.weimob.o2o.mgr.meiwei.domain.sch.MeiWeiQueueSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface MeiWeiQueueService extends CrudServiceInterface<MeiWeiQueue> {

    PageInfo<MeiWeiQueue> findPage(MeiWeiQueueSch sch);
}