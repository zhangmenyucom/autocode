package com.ayuan.blog.spider.build.service.impl;

import com.example.common.CrudService;
import com.github.pagehelper.PageInfo;
import com.ayuan.blog.spider.build.service.CommunityInfoOriginService;
import com.ayuan.blog.spider.build.dao.CommunityInfoOriginDao;
import com.ayuan.blog.spider.build.domain.CommunityInfoOrigin;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class CommunityInfoOriginServiceImpl 
        extends CrudService<CommunityInfoOrigin, CommunityInfoOriginDao> 
        implements CommunityInfoOriginService {

}