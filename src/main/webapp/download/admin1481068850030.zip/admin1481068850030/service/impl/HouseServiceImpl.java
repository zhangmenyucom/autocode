package com.ayuan.blog.spider.build.service.impl;

import com.example.common.CrudService;
import com.github.pagehelper.PageInfo;
import com.ayuan.blog.spider.build.service.HouseService;
import com.ayuan.blog.spider.build.dao.HouseDao;
import com.ayuan.blog.spider.build.domain.House;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class HouseServiceImpl 
        extends CrudService<House, HouseDao> 
        implements HouseService {

}