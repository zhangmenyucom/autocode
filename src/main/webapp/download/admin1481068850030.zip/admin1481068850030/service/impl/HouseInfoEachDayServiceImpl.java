package com.ayuan.blog.spider.build.service.impl;

import com.example.common.CrudService;
import com.github.pagehelper.PageInfo;
import com.ayuan.blog.spider.build.service.HouseInfoEachDayService;
import com.ayuan.blog.spider.build.dao.HouseInfoEachDayDao;
import com.ayuan.blog.spider.build.domain.HouseInfoEachDay;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class HouseInfoEachDayServiceImpl 
        extends CrudService<HouseInfoEachDay, HouseInfoEachDayDao> 
        implements HouseInfoEachDayService {

}