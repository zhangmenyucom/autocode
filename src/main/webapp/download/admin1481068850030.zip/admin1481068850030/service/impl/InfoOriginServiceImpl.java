package com.ayuan.blog.spider.build.service.impl;

import com.example.common.CrudService;
import com.github.pagehelper.PageInfo;
import com.ayuan.blog.spider.build.service.InfoOriginService;
import com.ayuan.blog.spider.build.dao.InfoOriginDao;
import com.ayuan.blog.spider.build.domain.InfoOrigin;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class InfoOriginServiceImpl 
        extends CrudService<InfoOrigin, InfoOriginDao> 
        implements InfoOriginService {

}