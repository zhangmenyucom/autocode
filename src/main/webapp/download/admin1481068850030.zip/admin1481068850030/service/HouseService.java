package com.ayuan.blog.spider.build.service;

import com.example.common.CrudServiceInterface;
import com.github.pagehelper.PageInfo;

import com.ayuan.blog.spider.build.domain.House;

public interface HouseService extends CrudServiceInterface<House> {

}