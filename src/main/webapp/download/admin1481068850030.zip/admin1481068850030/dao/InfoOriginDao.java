package com.ayuan.blog.spider.build.dao;

import com.example.common.BaseDao;
import com.ayuan.blog.spider.build.domain.InfoOrigin;

public interface InfoOriginDao extends BaseDao<InfoOrigin> {
}