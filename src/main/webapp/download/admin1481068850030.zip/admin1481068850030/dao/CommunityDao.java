package com.ayuan.blog.spider.build.dao;

import com.example.common.BaseDao;
import com.ayuan.blog.spider.build.domain.Community;

public interface CommunityDao extends BaseDao<Community> {
}