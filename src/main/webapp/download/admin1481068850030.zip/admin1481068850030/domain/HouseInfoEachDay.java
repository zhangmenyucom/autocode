package com.ayuan.blog.spider.build.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class HouseInfoEachDay implements Serializable {
	private Long id;
	private Long commnunityId;
	private Long infoOriginId;
	private Long houseId;
	private String statisticDay;
	private String houseName;
	private float totalPrice;
	private String tax;
	private float square;
	private String houseType;
	private String floor;
	private String direction;
	private String function;
	private String decoration;
	private String attribute;
	private Integer buildYear;
	private String communityName;
	private Date createTime;
	private Date udpateTime;
}