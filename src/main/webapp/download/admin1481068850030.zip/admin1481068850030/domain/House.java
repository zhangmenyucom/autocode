package com.ayuan.blog.spider.build.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class House implements Serializable {
	private Long houseId;
	private Long communityId;
	private Long infoOriginId;
	private String houseName;
	private String houseUrl;
	private Date createTime;
	private Date updateTime;
}