package package com.weimob.o2o.mgr.message.service.impl;

import org.durcframework.core.service.CrudService;
import package com.weimob.o2o.mgr.message.service.MessageGroupUserService;
import package com.weimob.o2o.mgr.message.dao.MessageGroupUserDao;
import package com.weimob.o2o.mgr.message.domain.MessageGroupUser;
import org.springframework.stereotype.Service;
    
@Service
public class MessageGroupUserServiceImpl 
        extends CrudService<MessageGroupUser, MessageGroupUserDao> 
        implements MessageGroupUserService {

}