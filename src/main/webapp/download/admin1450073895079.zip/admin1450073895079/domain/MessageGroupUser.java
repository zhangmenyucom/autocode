package package com.weimob.o2o.mgr.message.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MessageGroupUser implements Serializable {
	private Long messageGroupUserId;
	private Long merchantId;
	private Long messageGroupId;
	private String openId;
	private Date month;
	private Date createTime;
	private Date updateTime;
}