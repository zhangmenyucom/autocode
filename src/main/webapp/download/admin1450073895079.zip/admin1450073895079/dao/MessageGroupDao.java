package package com.weimob.o2o.mgr.message.dao;

import org.durcframework.core.dao.BaseDao;
import package com.weimob.o2o.mgr.message.domain.MessageGroup;

public interface MessageGroupDao extends BaseDao<MessageGroup> {
}