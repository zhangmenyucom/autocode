package package com.weimob.o2o.mgr.message.dao;

import org.durcframework.core.dao.BaseDao;
import package com.weimob.o2o.mgr.message.domain.MessageGroupUser;

public interface MessageGroupUserDao extends BaseDao<MessageGroupUser> {
}