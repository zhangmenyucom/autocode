package com.weimob.o2o.mgr.message.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class MessageGroup implements Serializable {
	private Long messageGroupId;
	private Long merchantId;
	private String userConditions;
	private String msgType;
	private Long mediaId;
	private String wxMediaId;
	private String textContent;
	private String videoTitle;
	private String videoDescription;
	private String wxcardCardId;
	private String msgId;
	private String msgDataId;
	private String msgStatus;
	private Long wxCreateTime;
	private Long totalCount;
	private Long filterCount;
	private Long sentCount;
	private Long errorCount;
	private Date createTime;
	private Date updateTime;
	private Long creataUserId;
	private Long updateUserId;
}