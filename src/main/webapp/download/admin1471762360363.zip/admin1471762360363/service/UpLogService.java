package com.example.service;

import com.github.pagehelper.PageInfo;

import com.example.domain.UpLog;
import com.example.domain.sch.UpLogSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface UpLogService extends CrudServiceInterface<UpLog> {

    PageInfo<UpLog> findPage(UpLogSch sch);
}