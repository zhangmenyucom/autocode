package com.example.service;

import com.github.pagehelper.PageInfo;

import com.example.domain.Article;
import com.example.domain.sch.ArticleSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ArticleService extends CrudServiceInterface<Article> {

    PageInfo<Article> findPage(ArticleSch sch);
}