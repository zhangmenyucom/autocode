package com.example.service;

import com.github.pagehelper.PageInfo;

import com.example.domain.Comment;
import com.example.domain.sch.CommentSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface CommentService extends CrudServiceInterface<Comment> {

    PageInfo<Comment> findPage(CommentSch sch);
}