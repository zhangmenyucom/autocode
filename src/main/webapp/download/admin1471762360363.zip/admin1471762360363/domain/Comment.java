package com.example.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Comment implements Serializable {
	private Integer commentId;
	private Integer articleId;
	private Integer commentUserId;
	private String commentUserName;
	private String content;
	private Integer deleteFlag;
	private Date updateTime;
	private Date createTime;
}