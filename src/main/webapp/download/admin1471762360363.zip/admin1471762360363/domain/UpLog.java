package com.example.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class UpLog implements Serializable {
	private Integer upLogId;
	private Integer userId;
	private Integer articleId;
	private Integer deleteFlag;
	private Date createTime;
	private Date updateTime;
}