package com.example.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class ArticleSch extends SearchEntity{

    private Integer idSch;
    private String titleSch;
    private String picUrlSch;
    private String contentSch;
    private Integer clasfIdSch;
    private Integer deleteFlagSch;
    private Integer userIdSch;
    private String userNameSch;
    private Date createDateSch;
    private Date updateDateSch;
    private Integer viewNumberSch;
    private Integer upNumberSch;

    public void setIdSch(Integer idSch){
        this.idSch = idSch;
    }
    
    @ValueField(column = "id")
    public Integer getIdSch(){
        return this.idSch;
    }

    public void setTitleSch(String titleSch){
        this.titleSch = titleSch;
    }
    
    @ValueField(column = "title")
    public String getTitleSch(){
        return this.titleSch;
    }

    public void setPicUrlSch(String picUrlSch){
        this.picUrlSch = picUrlSch;
    }
    
    @ValueField(column = "pic_url")
    public String getPicUrlSch(){
        return this.picUrlSch;
    }

    public void setContentSch(String contentSch){
        this.contentSch = contentSch;
    }
    
    @ValueField(column = "content")
    public String getContentSch(){
        return this.contentSch;
    }

    public void setClasfIdSch(Integer clasfIdSch){
        this.clasfIdSch = clasfIdSch;
    }
    
    @ValueField(column = "clasf_id")
    public Integer getClasfIdSch(){
        return this.clasfIdSch;
    }

    public void setDeleteFlagSch(Integer deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Integer getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setUserIdSch(Integer userIdSch){
        this.userIdSch = userIdSch;
    }
    
    @ValueField(column = "user_id")
    public Integer getUserIdSch(){
        return this.userIdSch;
    }

    public void setUserNameSch(String userNameSch){
        this.userNameSch = userNameSch;
    }
    
    @ValueField(column = "user_name")
    public String getUserNameSch(){
        return this.userNameSch;
    }

    public void setCreateDateSch(Date createDateSch){
        this.createDateSch = createDateSch;
    }
    
    @ValueField(column = "create_date")
    public Date getCreateDateSch(){
        return this.createDateSch;
    }

    public void setUpdateDateSch(Date updateDateSch){
        this.updateDateSch = updateDateSch;
    }
    
    @ValueField(column = "update_date")
    public Date getUpdateDateSch(){
        return this.updateDateSch;
    }

    public void setViewNumberSch(Integer viewNumberSch){
        this.viewNumberSch = viewNumberSch;
    }
    
    @ValueField(column = "view_number")
    public Integer getViewNumberSch(){
        return this.viewNumberSch;
    }

    public void setUpNumberSch(Integer upNumberSch){
        this.upNumberSch = upNumberSch;
    }
    
    @ValueField(column = "up_number")
    public Integer getUpNumberSch(){
        return this.upNumberSch;
    }


}