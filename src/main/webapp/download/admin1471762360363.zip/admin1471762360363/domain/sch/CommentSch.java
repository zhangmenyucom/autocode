package com.example.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class CommentSch extends SearchEntity{

    private Integer commentIdSch;
    private Integer articleIdSch;
    private Integer commentUserIdSch;
    private String commentUserNameSch;
    private String contentSch;
    private Integer deleteFlagSch;
    private Date updateTimeSch;
    private Date createTimeSch;

    public void setCommentIdSch(Integer commentIdSch){
        this.commentIdSch = commentIdSch;
    }
    
    @ValueField(column = "comment_Id")
    public Integer getCommentIdSch(){
        return this.commentIdSch;
    }

    public void setArticleIdSch(Integer articleIdSch){
        this.articleIdSch = articleIdSch;
    }
    
    @ValueField(column = "article_id")
    public Integer getArticleIdSch(){
        return this.articleIdSch;
    }

    public void setCommentUserIdSch(Integer commentUserIdSch){
        this.commentUserIdSch = commentUserIdSch;
    }
    
    @ValueField(column = "comment_user_id")
    public Integer getCommentUserIdSch(){
        return this.commentUserIdSch;
    }

    public void setCommentUserNameSch(String commentUserNameSch){
        this.commentUserNameSch = commentUserNameSch;
    }
    
    @ValueField(column = "comment_user_name")
    public String getCommentUserNameSch(){
        return this.commentUserNameSch;
    }

    public void setContentSch(String contentSch){
        this.contentSch = contentSch;
    }
    
    @ValueField(column = "content")
    public String getContentSch(){
        return this.contentSch;
    }

    public void setDeleteFlagSch(Integer deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Integer getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }


}