package com.example.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class UpLogSch extends SearchEntity{

    private Integer upLogIdSch;
    private Integer userIdSch;
    private Integer articleIdSch;
    private Integer deleteFlagSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setUpLogIdSch(Integer upLogIdSch){
        this.upLogIdSch = upLogIdSch;
    }
    
    @ValueField(column = "up_log_id")
    public Integer getUpLogIdSch(){
        return this.upLogIdSch;
    }

    public void setUserIdSch(Integer userIdSch){
        this.userIdSch = userIdSch;
    }
    
    @ValueField(column = "user_id")
    public Integer getUserIdSch(){
        return this.userIdSch;
    }

    public void setArticleIdSch(Integer articleIdSch){
        this.articleIdSch = articleIdSch;
    }
    
    @ValueField(column = "article_Id")
    public Integer getArticleIdSch(){
        return this.articleIdSch;
    }

    public void setDeleteFlagSch(Integer deleteFlagSch){
        this.deleteFlagSch = deleteFlagSch;
    }
    
    @ValueField(column = "delete_flag")
    public Integer getDeleteFlagSch(){
        return this.deleteFlagSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}