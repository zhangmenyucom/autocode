package com.example.dao;

import org.durcframework.core.dao.BaseDao;
import com.example.domain.UpLog;

public interface UpLogDao extends BaseDao<UpLog> {
}