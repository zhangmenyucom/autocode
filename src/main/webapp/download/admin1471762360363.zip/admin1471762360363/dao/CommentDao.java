package com.example.dao;

import org.durcframework.core.dao.BaseDao;
import com.example.domain.Comment;

public interface CommentDao extends BaseDao<Comment> {
}