package com.example.dao;

import org.durcframework.core.dao.BaseDao;
import com.example.domain.Article;

public interface ArticleDao extends BaseDao<Article> {
}