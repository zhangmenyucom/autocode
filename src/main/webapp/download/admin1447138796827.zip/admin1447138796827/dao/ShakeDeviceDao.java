package com.weimob.cardcenter.mgr.shake.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakeDevice;

public interface ShakeDeviceDao extends BaseDao<ShakeDevice> {
}