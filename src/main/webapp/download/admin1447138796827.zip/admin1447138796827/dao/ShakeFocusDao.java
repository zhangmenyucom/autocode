package com.weimob.cardcenter.mgr.shake.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakeFocus;

public interface ShakeFocusDao extends BaseDao<ShakeFocus> {
}