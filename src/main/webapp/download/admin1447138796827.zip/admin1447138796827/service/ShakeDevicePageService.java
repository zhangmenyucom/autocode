package com.weimob.cardcenter.mgr.shake.service;

import com.weimob.cardcenter.mgr.shake.domain.ShakeDevicePage;
import com.weimob.cardcenter.mgr.shake.dao.ShakeDevicePageDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeDevicePageService extends CrudServiceInterface<ShakeDevicePage, ShakeDevicePageDao> {

}