package com.weimob.cardcenter.mgr.shake.service;

import com.weimob.cardcenter.mgr.shake.domain.ShakeFocus;
import com.weimob.cardcenter.mgr.shake.dao.ShakeFocusDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakeFocusService extends CrudServiceInterface<ShakeFocus, ShakeFocusDao> {

}