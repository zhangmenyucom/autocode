package com.weimob.cardcenter.mgr.shake.service;

import com.weimob.cardcenter.mgr.shake.domain.ShakePage;
import com.weimob.cardcenter.mgr.shake.dao.ShakePageDao;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface ShakePageService extends CrudServiceInterface<ShakePage, ShakePageDao> {

}