package com.weimob.cardcenter.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.cardcenter.mgr.shake.service.ShakeDeviceService;
import com.weimob.cardcenter.mgr.shake.dao.ShakeDeviceDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakeDevice;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceServiceImpl 
        extends CrudService<ShakeDevice, ShakeDeviceDao> 
        implements ShakeDeviceService {

}