package com.weimob.cardcenter.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.cardcenter.mgr.shake.service.ShakePageService;
import com.weimob.cardcenter.mgr.shake.dao.ShakePageDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakePageServiceImpl 
        extends CrudService<ShakePage, ShakePageDao> 
        implements ShakePageService {

}