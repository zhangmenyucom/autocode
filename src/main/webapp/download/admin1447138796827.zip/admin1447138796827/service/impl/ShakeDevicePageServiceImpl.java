package com.weimob.cardcenter.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.cardcenter.mgr.shake.service.ShakeDevicePageService;
import com.weimob.cardcenter.mgr.shake.dao.ShakeDevicePageDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakeDevicePage;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDevicePageServiceImpl 
        extends CrudService<ShakeDevicePage, ShakeDevicePageDao> 
        implements ShakeDevicePageService {

}