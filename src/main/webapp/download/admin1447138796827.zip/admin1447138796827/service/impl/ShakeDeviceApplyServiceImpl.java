package com.weimob.cardcenter.mgr.shake.service.impl;

import org.durcframework.core.service.CrudService;
import com.weimob.cardcenter.mgr.shake.service.ShakeDeviceApplyService;
import com.weimob.cardcenter.mgr.shake.dao.ShakeDeviceApplyDao;
import com.weimob.cardcenter.mgr.shake.domain.ShakeDeviceApply;
import org.springframework.stereotype.Service;
    
@Service
public class ShakeDeviceApplyServiceImpl 
        extends CrudService<ShakeDeviceApply, ShakeDeviceApplyDao> 
        implements ShakeDeviceApplyService {

}