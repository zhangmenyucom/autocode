package com.weimob.cardcenter.mgr.shake.domain;

public class ShakeDeviceApply {
	private Long shakeDeviceApplyId;
	private Integer quanttity;
	private String applyReason;
	private String comment;
	private String poiId;
	private String applyId;
	private Integer auditStatus;
	private String auditComment;
	private String applyTime;
	private String auditTime;
	private Long merchantId;
	private String createTime;
	private String updateTime;

	public void setShakeDeviceApplyId(Long shakeDeviceApplyId){
		this.shakeDeviceApplyId = shakeDeviceApplyId;
	}

	public Long getShakeDeviceApplyId(){
		return this.shakeDeviceApplyId;
	}

	public void setQuanttity(Integer quanttity){
		this.quanttity = quanttity;
	}

	public Integer getQuanttity(){
		return this.quanttity;
	}

	public void setApplyReason(String applyReason){
		this.applyReason = applyReason;
	}

	public String getApplyReason(){
		return this.applyReason;
	}

	public void setComment(String comment){
		this.comment = comment;
	}

	public String getComment(){
		return this.comment;
	}

	public void setPoiId(String poiId){
		this.poiId = poiId;
	}

	public String getPoiId(){
		return this.poiId;
	}

	public void setApplyId(String applyId){
		this.applyId = applyId;
	}

	public String getApplyId(){
		return this.applyId;
	}

	public void setAuditStatus(Integer auditStatus){
		this.auditStatus = auditStatus;
	}

	public Integer getAuditStatus(){
		return this.auditStatus;
	}

	public void setAuditComment(String auditComment){
		this.auditComment = auditComment;
	}

	public String getAuditComment(){
		return this.auditComment;
	}

	public void setApplyTime(String applyTime){
		this.applyTime = applyTime;
	}

	public String getApplyTime(){
		return this.applyTime;
	}

	public void setAuditTime(String auditTime){
		this.auditTime = auditTime;
	}

	public String getAuditTime(){
		return this.auditTime;
	}

	public void setMerchantId(Long merchantId){
		this.merchantId = merchantId;
	}

	public Long getMerchantId(){
		return this.merchantId;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

}