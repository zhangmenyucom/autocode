package com.weimob.o2o.mgr.employee.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class EmployeeIndexSettingStoreSch extends SearchEntity{

    private Long employeeIndexSettingStoreIdSch;
    private Long merchantIdSch;
    private Long employeeIndexSettingIdSch;
    private Long storeIdSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setEmployeeIndexSettingStoreIdSch(Long employeeIndexSettingStoreIdSch){
        this.employeeIndexSettingStoreIdSch = employeeIndexSettingStoreIdSch;
    }
    
    @ValueField(column = "employee_index_setting_store_id")
    public Long getEmployeeIndexSettingStoreIdSch(){
        return this.employeeIndexSettingStoreIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setEmployeeIndexSettingIdSch(Long employeeIndexSettingIdSch){
        this.employeeIndexSettingIdSch = employeeIndexSettingIdSch;
    }
    
    @ValueField(column = "employee_index_setting_id")
    public Long getEmployeeIndexSettingIdSch(){
        return this.employeeIndexSettingIdSch;
    }

    public void setStoreIdSch(Long storeIdSch){
        this.storeIdSch = storeIdSch;
    }
    
    @ValueField(column = "store_id")
    public Long getStoreIdSch(){
        return this.storeIdSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}