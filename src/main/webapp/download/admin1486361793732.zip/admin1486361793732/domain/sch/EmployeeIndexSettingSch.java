package com.weimob.o2o.mgr.employee.domain.sch;

import java.util.Date;

import org.durcframework.core.SearchEntity;
import org.durcframework.core.expression.annotation.ValueField;

public class EmployeeIndexSettingSch extends SearchEntity{

    private Long employeeIndexSettingIdSch;
    private Long merchantIdSch;
    private Integer rewardStatusSch;
    private Integer rewardLeftSch;
    private Integer rewardTypeSch;
    private BigDecimal rewardValueSch;
    private Integer typeSch;
    private Integer statusSch;
    private Date createTimeSch;
    private Date updateTimeSch;

    public void setEmployeeIndexSettingIdSch(Long employeeIndexSettingIdSch){
        this.employeeIndexSettingIdSch = employeeIndexSettingIdSch;
    }
    
    @ValueField(column = "employee_index_setting_id")
    public Long getEmployeeIndexSettingIdSch(){
        return this.employeeIndexSettingIdSch;
    }

    public void setMerchantIdSch(Long merchantIdSch){
        this.merchantIdSch = merchantIdSch;
    }
    
    @ValueField(column = "merchant_id")
    public Long getMerchantIdSch(){
        return this.merchantIdSch;
    }

    public void setRewardStatusSch(Integer rewardStatusSch){
        this.rewardStatusSch = rewardStatusSch;
    }
    
    @ValueField(column = "reward_status")
    public Integer getRewardStatusSch(){
        return this.rewardStatusSch;
    }

    public void setRewardLeftSch(Integer rewardLeftSch){
        this.rewardLeftSch = rewardLeftSch;
    }
    
    @ValueField(column = "reward_left")
    public Integer getRewardLeftSch(){
        return this.rewardLeftSch;
    }

    public void setRewardTypeSch(Integer rewardTypeSch){
        this.rewardTypeSch = rewardTypeSch;
    }
    
    @ValueField(column = "reward_type")
    public Integer getRewardTypeSch(){
        return this.rewardTypeSch;
    }

    public void setRewardValueSch(BigDecimal rewardValueSch){
        this.rewardValueSch = rewardValueSch;
    }
    
    @ValueField(column = "reward_value")
    public BigDecimal getRewardValueSch(){
        return this.rewardValueSch;
    }

    public void setTypeSch(Integer typeSch){
        this.typeSch = typeSch;
    }
    
    @ValueField(column = "type")
    public Integer getTypeSch(){
        return this.typeSch;
    }

    public void setStatusSch(Integer statusSch){
        this.statusSch = statusSch;
    }
    
    @ValueField(column = "status")
    public Integer getStatusSch(){
        return this.statusSch;
    }

    public void setCreateTimeSch(Date createTimeSch){
        this.createTimeSch = createTimeSch;
    }
    
    @ValueField(column = "create_time")
    public Date getCreateTimeSch(){
        return this.createTimeSch;
    }

    public void setUpdateTimeSch(Date updateTimeSch){
        this.updateTimeSch = updateTimeSch;
    }
    
    @ValueField(column = "update_time")
    public Date getUpdateTimeSch(){
        return this.updateTimeSch;
    }


}