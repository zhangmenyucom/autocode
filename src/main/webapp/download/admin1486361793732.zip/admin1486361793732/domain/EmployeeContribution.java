package com.weimob.o2o.mgr.employee.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class EmployeeContribution implements Serializable {
	private Long employeeContributionId;
	private Long merchantId;
	private Long storeId;
	private Long employeeId;
	private Long businessId;
	private Integer businessType;
	private String customerOpenId;
	private String customerName;
	private Long employeeIndexSettingId;
	private BigDecimal planRewardValue;
	private Integer rewardStatus;
	private BigDecimal rewardValue;
	private Integer rewardValueType;
	private Integer status;
	private Date createTime;
	private Date updateTime;
}