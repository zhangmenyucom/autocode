package com.weimob.o2o.mgr.employee.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class EmployeeIndexSettingStore implements Serializable {
	private Long employeeIndexSettingStoreId;
	private Long merchantId;
	private Long employeeIndexSettingId;
	private Long storeId;
	private Date createTime;
	private Date updateTime;
}