package com.weimob.o2o.mgr.employee.domain;

import java.io.Serializable;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.Data;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class EmployeeIndexSetting implements Serializable {
	private Long employeeIndexSettingId;
	private Long merchantId;
	private Integer rewardStatus;
	private Integer rewardLeft;
	private Integer rewardType;
	private BigDecimal rewardValue;
	private Integer type;
	private Integer status;
	private Date createTime;
	private Date updateTime;
}