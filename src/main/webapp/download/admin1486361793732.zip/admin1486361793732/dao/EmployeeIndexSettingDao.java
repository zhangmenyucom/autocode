package com.weimob.o2o.mgr.employee.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.employee.domain.EmployeeIndexSetting;

public interface EmployeeIndexSettingDao extends BaseDao<EmployeeIndexSetting> {
}