package com.weimob.o2o.mgr.employee.dao;

import org.durcframework.core.dao.BaseDao;
import com.weimob.o2o.mgr.employee.domain.EmployeeIndexSettingStore;

public interface EmployeeIndexSettingStoreDao extends BaseDao<EmployeeIndexSettingStore> {
}