package com.weimob.o2o.mgr.employee.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.employee.domain.EmployeeContribution;
import com.weimob.o2o.mgr.employee.domain.sch.EmployeeContributionSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface EmployeeContributionService extends CrudServiceInterface<EmployeeContribution> {

    PageInfo<EmployeeContribution> findPage(EmployeeContributionSch sch);
}