package com.weimob.o2o.mgr.employee.service.impl;

import com.github.pagehelper.PageInfo;
import org.durcframework.core.expression.ExpressionQuery;
import org.durcframework.core.service.CrudService;
import com.weimob.o2o.mgr.employee.service.EmployeeContributionService;
import com.weimob.o2o.mgr.employee.dao.EmployeeContributionDao;
import com.weimob.o2o.mgr.employee.domain.EmployeeContribution;
import com.weimob.o2o.mgr.employee.domain.sch.EmployeeContributionSch;
import org.springframework.stereotype.Service;

import java.util.List;
    
@Service
public class EmployeeContributionServiceImpl 
        extends CrudService<EmployeeContribution, EmployeeContributionDao> 
        implements EmployeeContributionService {

    @Override
    public PageInfo<EmployeeContribution> findPage(EmployeeContributionSch sch) {
        ExpressionQuery query = new ExpressionQuery();
        query.addPaginationInfo(sch);
        query.addAnnotionExpression(sch);

        long total = this.getDao().findTotalCount(query);
        List<EmployeeContribution> list = this.getDao().find(query);

        PageInfo<EmployeeContribution> page = new PageInfo<EmployeeContribution>();
        page.setList(list);
        page.setPageNum(sch.getPageIndex()); // 设置当前页数
        page.setPageSize(sch.getPageSize()); // 设置每页的数量
        page.setSize(list.size()); // 设置当前页的数量
        page.setPages((int) ((total + sch.getPageSize() - 1) / sch.getPageSize())); // 设置总的页数
        page.setTotal(total); // 设置总的数量

        return page;
    }
}