package com.weimob.o2o.mgr.employee.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.employee.domain.EmployeeIndexSetting;
import com.weimob.o2o.mgr.employee.domain.sch.EmployeeIndexSettingSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface EmployeeIndexSettingService extends CrudServiceInterface<EmployeeIndexSetting> {

    PageInfo<EmployeeIndexSetting> findPage(EmployeeIndexSettingSch sch);
}