package com.weimob.o2o.mgr.employee.service;

import com.github.pagehelper.PageInfo;

import com.weimob.o2o.mgr.employee.domain.EmployeeIndexSettingStore;
import com.weimob.o2o.mgr.employee.domain.sch.EmployeeIndexSettingStoreSch;

import com.weimob.o2o.mgr.common.service.CrudServiceInterface;

public interface EmployeeIndexSettingStoreService extends CrudServiceInterface<EmployeeIndexSettingStore> {

    PageInfo<EmployeeIndexSettingStore> findPage(EmployeeIndexSettingStoreSch sch);
}